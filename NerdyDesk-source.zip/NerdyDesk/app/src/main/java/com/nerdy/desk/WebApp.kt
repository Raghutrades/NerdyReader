package com.nerdy.desk

import android.annotation.SuppressLint
import android.app.DownloadManager
import android.content.Context
import android.graphics.Bitmap
import android.net.Uri
import android.os.Environment
import android.util.Base64
import android.view.View
import android.webkit.ConsoleMessage
import android.webkit.CookieManager
import android.webkit.URLUtil
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import android.webkit.ValueCallback
import android.widget.FrameLayout

/** A built-in app whose screen is a page from assets/apps/<id>/ shown inside a desktop window. */
class WebApp(act: MainActivity, val kind: AppKind, private val arg: String?) : App(act) {
    override val title: String = kind.title
    override val icon: String = kind.icon
    lateinit var web: WebView
        private set

    private fun pageUrl(extra: String?): String {
        val sb = StringBuilder(Local.BASE)
        sb.append("/assets/apps/").append(kind.web).append("/index.html")
        sb.append("?theme=").append(if (Ui.light) "light" else "dark")
        sb.append("&accent=").append(Uri.encode(String.format("#%06X", Ui.accent and 0xFFFFFF)))
        if (extra != null) sb.append("&arg=").append(Uri.encode(extra))
        return sb.toString()
    }

    @SuppressLint("SetJavaScriptEnabled", "AddJavascriptInterface")
    override fun build(): View {
        val root = FrameLayout(act)
        web = WebView(act)
        val s = web.settings
        s.javaScriptEnabled = true
        s.domStorageEnabled = true
        s.databaseEnabled = true
        s.allowFileAccess = false
        s.allowContentAccess = false
        s.mediaPlaybackRequiresUserGesture = false
        s.loadWithOverviewMode = true
        s.setSupportZoom(false)
        s.mixedContentMode = WebSettings.MIXED_CONTENT_COMPATIBILITY_MODE
        s.cacheMode = WebSettings.LOAD_DEFAULT
        s.userAgentString = s.userAgentString + " NerdyDesk/2.0"
        web.setBackgroundColor(Ui.bgDark)
        web.isFocusable = true
        web.isFocusableInTouchMode = true
        web.addJavascriptInterface(DeskBridge(act, this), "Desk")
        CookieManager.getInstance().setAcceptCookie(true)

        web.webViewClient = object : WebViewClient() {
            override fun shouldInterceptRequest(view: WebView, request: WebResourceRequest): WebResourceResponse? =
                Local.handle(act, request.url, request.requestHeaders)

            override fun shouldOverrideUrlLoading(view: WebView, request: WebResourceRequest): Boolean {
                val u = request.url
                if (u.host == Local.HOST) return false
                val sch = u.scheme ?: ""
                if (sch == "http" || sch == "https") {
                    act.open(AppKind.BROWSER, u.toString())
                } else {
                    act.startSafely(android.content.Intent(android.content.Intent.ACTION_VIEW, u).addFlags(android.content.Intent.FLAG_ACTIVITY_NEW_TASK))
                }
                return true
            }
        }
        web.webChromeClient = object : WebChromeClient() {
            override fun onShowFileChooser(
                webView: WebView?,
                filePathCallback: ValueCallback<Array<Uri>>?,
                fileChooserParams: WebChromeClient.FileChooserParams?
            ): Boolean {
                act.filePathCallback?.onReceiveValue(null)
                act.filePathCallback = filePathCallback
                return try {
                    act.startActivityForResult(fileChooserParams!!.createIntent(), MainActivity.REQ_FILE)
                    true
                } catch (e: Exception) {
                    act.filePathCallback = null
                    false
                }
            }

            override fun onConsoleMessage(m: ConsoleMessage?): Boolean = true

            override fun onShowCustomView(view: View?, callback: WebChromeClient.CustomViewCallback?) {
                if (view == null) return
                act.showFullscreenView(view, callback)
            }

            override fun onHideCustomView() {
                act.hideFullscreenView()
            }
        }
        web.setDownloadListener { dlUrl, agent, disposition, mime, _ -> download(dlUrl, agent, disposition, mime) }
        root.addView(web, FrameLayout.LayoutParams(MATCH, MATCH))
        web.loadUrl(pageUrl(arg))
        return root
    }

    private fun download(url: String, agent: String?, disposition: String?, mime: String?) {
        try {
            if (url.startsWith("blob:")) {
                val name = URLUtil.guessFileName(url, disposition, mime)
                val js = "(async()=>{try{const r=await fetch('" + url + "');const b=await r.blob();const f=new FileReader();" +
                    "f.onloadend=()=>Desk.saveBase64(" + org.json.JSONObject.quote(name) + "," + org.json.JSONObject.quote(mime ?: b("")) +
                    ",String(f.result).split(',')[1]);f.readAsDataURL(b);}catch(e){Desk.toast('Download failed')}})()"
                web.evaluateJavascript(js, null)
            } else if (url.startsWith("data:")) {
                val head = url.substringBefore(',')
                val data = url.substringAfter(',')
                val m = head.removePrefix("data:").substringBefore(';')
                val name = URLUtil.guessFileName(url, disposition, m)
                val b64 = if (head.contains("base64")) data else Base64.encodeToString(Uri.decode(data).toByteArray(), Base64.NO_WRAP)
                DeskBridge(act, this).saveBase64(name, m, b64)
            } else {
                val req = DownloadManager.Request(Uri.parse(url))
                if (mime != null) req.setMimeType(mime)
                CookieManager.getInstance().getCookie(url)?.let { req.addRequestHeader("cookie", it) }
                if (agent != null) req.addRequestHeader("User-Agent", agent)
                val name = URLUtil.guessFileName(url, disposition, mime)
                req.setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED)
                req.setDestinationInExternalPublicDir(Environment.DIRECTORY_DOWNLOADS, name)
                (act.getSystemService(Context.DOWNLOAD_SERVICE) as DownloadManager).enqueue(req)
                act.toast("Downloading $name")
            }
        } catch (e: Exception) {
            act.toast("Download failed")
        }
    }

    private fun b(s: String): String = if (s.isEmpty()) "application/octet-stream" else s

    fun applyTheme() {
        val hex = String.format("#%06X", Ui.accent and 0xFFFFFF)
        web.setBackgroundColor(Ui.bgDark)
        web.evaluateJavascript("window.__setTheme&&window.__setTheme('" + (if (Ui.light) "light" else "dark") + "','" + hex + "')", null)
    }

    override fun onOpenArg(arg: String) {
        web.evaluateJavascript("window.__open&&window.__open(" + org.json.JSONObject.quote(arg) + ")", null)
    }

    override fun onResume() {
        web.onResume()
    }

    override fun onBack(): Boolean {
        // let the page handle Back first (close a dialog, step back inside the app)
        web.evaluateJavascript("(window.__back&&window.__back())===true", null)
        return true
    }

    override fun onClose() {
        try {
            web.loadUrl("about:blank")
            web.removeAllViews()
            web.destroy()
        } catch (e: Exception) {
        }
    }
}
