'use strict';
/* ===== NerdyReader · storage =====
   books : metadata, progress, bookmarks (small, kept in memory too)
   files : the actual file Blob, copied in when you add a book, so the book
           still opens offline after you delete or move the original. */
const DB = {
  db: null,
  open() {
    return new Promise((res, rej) => {
      const r = indexedDB.open('nerdyreader', 1);
      r.onupgradeneeded = () => {
        const d = r.result;
        d.createObjectStore('books', { keyPath: 'id' });
        d.createObjectStore('files');
      };
      r.onsuccess = () => { this.db = r.result; res(); };
      r.onerror = () => rej(r.error);
    });
  },
  _req(store, mode, fn) {
    return new Promise((res, rej) => {
      const t = this.db.transaction(store, mode);
      let out;
      const rq = fn(t);
      if (rq) rq.onsuccess = () => { out = rq.result; };
      t.oncomplete = () => res(out);
      t.onerror = () => rej(t.error);
      t.onabort = () => rej(t.error || new Error('Storage write failed'));
    });
  },
  allBooks() { return this._req('books', 'readonly', t => t.objectStore('books').getAll()); },
  putBook(b) { return this._req('books', 'readwrite', t => t.objectStore('books').put(b)); },
  getFile(id) { return this._req('files', 'readonly', t => t.objectStore('files').get(id)); },
  putBookAndFile(b, blob) {
    return this._req(['books', 'files'], 'readwrite', t => {
      t.objectStore('files').put(blob, b.id);
      return t.objectStore('books').put(b);
    });
  },
  delBook(id) {
    return this._req(['books', 'files'], 'readwrite', t => {
      t.objectStore('files').delete(id);
      return t.objectStore('books').delete(id);
    });
  },
  clearAll() {
    return this._req(['books', 'files'], 'readwrite', t => {
      t.objectStore('files').clear();
      return t.objectStore('books').clear();
    });
  },
};

/* in-memory copy of the library for fast rendering */
const S = { books: new Map(), view: 'home', params: {}, lib: { tab: 'all', fmt: 'all', sort: 'new' }, shelf: { tab: 'reading' }, q: '' };
async function loadLibrary() {
  S.books.clear();
  (await DB.allBooks()).forEach(b => {
    b.bookmarks = b.bookmarks || [];
    S.books.set(b.id, b);
  });
}
const bookList = () => [...S.books.values()];
let _saveT = {};
function saveBook(b, now = false) {
  clearTimeout(_saveT[b.id]);
  const go = () => DB.putBook(b).catch(e => console.warn('save failed', e));
  if (now) return go();
  _saveT[b.id] = setTimeout(go, 500);
}
