'use strict';
/* ===== NerdyReader · marking up books =====
   PDF pages: highlighter, pen, underline and eraser drawn on a transparent layer over each page.
              Strokes are stored per page, as fractions of the page size, so they stay put when you zoom or resize.
   Other books (EPUB, text, Word…): select text, pick a colour, and it is highlighted (stored as character offsets in the chapter). */
const HLC = { y: '#ffd43b', g: '#69db7c', b: '#4dabf7', p: '#f783ac', o: '#ff922b' };
const Ann = {
  on: false, tool: 'hand', size: 1, undo: [], redo: [], cv: new Set(), cur: null,
  cols: { hl: '#ffd43b', pen: '#e03131', ul: '#1971c2' },
  PAL: ['#ffd43b', '#69db7c', '#4dabf7', '#f783ac', '#ff922b', '#e03131', '#1f1f1f'],
  active() { return this.on && this.tool !== 'hand' && !!RD; },
  strokes(p) { const b = RD && RD.b; return (b && b.ann && b.ann[p]) || []; },

  /* ---- the transparent layer on a page ---- */
  attach(host, p, w, h, scale) {
    if (!RD || RD.kind !== 'pages' || !host) return;
    let cv = host.querySelector(':scope > canvas.annc');
    if (!cv) { cv = document.createElement('canvas'); cv.className = 'annc'; host.appendChild(cv); this.bind(cv); }
    cv._p = p; this.cv.add(cv);
    const dpr = Math.min(window.devicePixelRatio || 1, 2) * (scale || 1), k = Math.min(1, 4096 / Math.max(w * dpr, h * dpr, 1));
    cv.width = Math.max(1, Math.round(w * dpr * k)); cv.height = Math.max(1, Math.round(h * dpr * k));
    this.draw(cv);
  },
  draw(cv) {
    const g = cv.getContext('2d'), W = cv.width, H = cv.height; g.clearRect(0, 0, W, H);
    for (const s of this.strokes(cv._p)) this.paint(g, s, W, H);
    if (this.cur && this.cur.cv === cv && this.cur.k !== 'er') this.paint(g, this.cur, W, H);
  },
  paint(g, s, W, H) {
    const p = s.p; if (!p.length) return;
    g.save(); g.lineJoin = 'round'; g.lineCap = s.k === 'hl' ? 'square' : 'round';
    g.strokeStyle = g.fillStyle = s.c; g.globalAlpha = s.k === 'hl' ? 0.42 : 1; g.lineWidth = Math.max(1.2, s.w * W);
    if (p.length <= 2) { g.beginPath(); g.arc(p[0] * W, p[1] * H, g.lineWidth / 2, 0, 6.2832); g.fill(); }
    else {
      g.beginPath(); g.moveTo(p[0] * W, p[1] * H);
      for (let i = 2; i < p.length - 2; i += 2) g.quadraticCurveTo(p[i] * W, p[i + 1] * H, (p[i] + p[i + 2]) / 2 * W, (p[i + 1] + p[i + 3]) / 2 * H);
      g.lineTo(p[p.length - 2] * W, p[p.length - 1] * H); g.stroke();
    }
    g.restore();
  },
  refresh(page) { for (const cv of [...this.cv]) { if (!cv.isConnected) this.cv.delete(cv); else if (cv._p === page) this.draw(cv); } },
  save() { clearTimeout(this._t); this._t = setTimeout(() => RD && saveBook(RD.b), 500); },

  /* ---- drawing with a finger or a stylus ---- */
  bind(cv) {
    cv.addEventListener('pointerdown', e => {
      if (!Ann.active() || !e.isPrimary) return;
      e.preventDefault(); e.stopPropagation();
      try { cv.setPointerCapture(e.pointerId); } catch (er) { }
      Ann.begin(cv, e);
    });
    cv.addEventListener('pointermove', e => { if (Ann.cur && Ann.cur.id === e.pointerId) { e.stopPropagation(); Ann.move(e); } });
    const up = e => { if (Ann.cur && Ann.cur.id === e.pointerId) { e.stopPropagation(); Ann.end(); } };
    cv.addEventListener('pointerup', up); cv.addEventListener('pointercancel', () => Ann.cancel());
  },
  pt(e) { const r = this.cur.r; return { x: clamp((e.clientX - r.left) / r.width, 0, 1), y: clamp((e.clientY - r.top) / r.height, 0, 1) }; },
  begin(cv, e) {
    const k = this.tool, w = k === 'hl' ? 0.024 * this.size : k === 'ul' ? 0.0042 * this.size : 0.0036 * this.size;
    this.cur = { id: e.pointerId, cv, r: cv.getBoundingClientRect(), k, c: this.cols[k], w, p: [], removed: [] };
    const q = this.pt(e);
    if (k === 'er') this.erase(q); else { this.cur.p.push(q.x, q.y); this.draw(cv); }
    Track.touch();
  },
  move(e) {
    const c = this.cur, q = this.pt(e);
    if (c.k === 'er') return this.erase(q);
    if (c.k === 'ul') c.p = [c.p[0], c.p[1], q.x, c.p[1]];
    else { const n = c.p.length; if (Math.hypot(q.x - c.p[n - 2], (q.y - c.p[n - 1]) * c.r.height / c.r.width) > 0.003) c.p.push(q.x, q.y); }
    this.draw(c.cv);
  },
  cancel() { const c = this.cur; this.cur = null; if (c) this.refresh(c.cv._p); },
  end() {
    const c = this.cur; if (!c) return; this.cur = null;
    const page = c.cv._p;
    if (c.k === 'er') { if (c.removed.length) { this.undo.push({ t: 'del', page, items: c.removed }); this.redo = []; this.save(); this.syncBar(); } return this.refresh(page); }
    let p = c.p;
    if (c.k === 'hl' && p.length >= 4) {                               // a nearly level swipe becomes a neat straight highlight
      let lo = 1, hi = 0, sy = 0; for (let i = 1; i < p.length; i += 2) { lo = Math.min(lo, p[i]); hi = Math.max(hi, p[i]); sy += p[i]; }
      if ((hi - lo) * c.r.height < c.w * c.r.width * 0.8) p = [p[0], sy / (p.length / 2), p[p.length - 2], sy / (p.length / 2)];
    }
    if (p.length < 2) return this.draw(c.cv);
    const s = { k: c.k, c: c.c, w: c.w, p: p.map(v => Math.round(v * 10000) / 10000) }, b = RD.b;
    if (!b.ann) b.ann = {}; if (!b.ann[page]) b.ann[page] = [];
    b.ann[page].push(s); this.undo.push({ t: 'add', page, s }); this.redo = []; this.save(); this.syncBar(); this.refresh(page);
  },
  erase(q) {
    const c = this.cur, list = this.strokes(c.cv._p), asp = c.r.height / c.r.width, R = 0.026;
    const hit = s => {
      const p = s.p;
      for (let i = 0; i < p.length; i += 2) {
        let x = p[i], y = p[i + 1];
        if (Math.hypot(q.x - x, (q.y - y) * asp) < R + s.w / 2) return true;
        if (i + 2 < p.length) for (let t = 0.25; t < 1; t += 0.25) { x = p[i] + (p[i + 2] - p[i]) * t; y = p[i + 1] + (p[i + 3] - p[i + 1]) * t; if (Math.hypot(q.x - x, (q.y - y) * asp) < R + s.w / 2) return true; }
      }
      return false;
    };
    const gone = []; list.forEach((s, i) => { if (hit(s)) gone.push(i); });
    if (!gone.length) return;
    for (let k = gone.length - 1; k >= 0; k--) c.removed.unshift({ s: list.splice(gone[k], 1)[0], i: gone[k] });
    this.refresh(c.cv._p);
  },
  doUndo() {
    const o = this.undo.pop(); if (!o) return; const b = RD.b, l = (b.ann && b.ann[o.page]) || [];
    if (o.t === 'add') { const i = l.indexOf(o.s); if (i >= 0) l.splice(i, 1); } else o.items.slice().sort((a, b) => a.i - b.i).forEach(x => l.splice(x.i, 0, x.s));
    this.redo.push(o); this.save(); this.syncBar(); this.refresh(o.page);
  },
  doRedo() {
    const o = this.redo.pop(); if (!o) return; const b = RD.b;
    if (!b.ann) b.ann = {}; if (!b.ann[o.page]) b.ann[o.page] = [];
    const l = b.ann[o.page];
    if (o.t === 'add') l.push(o.s); else o.items.forEach(x => { const i = l.indexOf(x.s); if (i >= 0) l.splice(i, 1); });
    this.undo.push(o); this.save(); this.syncBar(); this.refresh(o.page);
  },

  /* ---- the toolbar ---- */
  barHTML() {
    const T = (t, i, l) => `<button class="dt ${this.tool === t ? 'on' : ''}" data-act="ann-tool" data-t="${t}" aria-label="${l}">${ic(i, 20)}</button>`;
    const col = this.cols[this.tool];
    return `<div class="dtools">${T('hand', 'hand', 'Move')}${T('hl', 'marker', 'Highlighter')}${T('pen', 'pen', 'Pen')}${T('ul', 'uline', 'Underline')}${T('er', 'eraser', 'Eraser')}<i class="dsep"></i>
      <button class="dt" data-act="ann-undo" id="dundo" aria-label="Undo" ${this.undo.length ? '' : 'disabled'}>${ic('undo', 19)}</button><button class="dt" data-act="ann-redo" id="dredo" aria-label="Redo" ${this.redo.length ? '' : 'disabled'}>${ic('redo', 19)}</button>
      <button class="dt done" data-act="ann-done" aria-label="Done">${ic('check', 20)}</button></div>
      ${this.tool === 'hand' || this.tool === 'er' ? `<div class="dopts hint">${this.tool === 'er' ? 'Drag over a mark to erase it' : 'Pick a tool, then draw on the page. Pinch to zoom.'}</div>` :
        `<div class="dopts">${this.PAL.map(c => `<button class="dc ${c === col ? 'on' : ''}" style="--c:${c}" data-act="ann-col" data-c="${c}" aria-label="Colour"></button>`).join('')}<i class="dsep"></i>${[[0.6, 8], [1, 13], [1.8, 19]].map(([v, d]) => `<button class="dz ${this.size === v ? 'on' : ''}" data-act="ann-size" data-v="${v}" aria-label="Size"><i style="width:${d}px;height:${d}px"></i></button>`).join('')}</div>`}`;
  },
  syncBar() { const b = $('#drawbar'); if (b && !b.hidden) b.innerHTML = this.barHTML(); },
  setOn(v) {
    if (v && (!RD || RD.kind !== 'pages')) return toast('Drawing works on PDF pages. In other books, select text to highlight it.', 3200);
    this.on = v; if (v && this.tool === 'hand') this.tool = 'hl';
    const bar = $('#drawbar'); bar.hidden = !v; $('#reader').classList.toggle('drawing', v);
    if (v) { RD.immersive = true; $('#reader').classList.add('imm'); this.syncBar(); }
    $('#rmark') && $('#rmark').classList.toggle('on', v);
  },
  reset() { this.on = false; this.tool = 'hand'; this.undo = []; this.redo = []; this.cv.clear(); this.cur = null; const b = $('#drawbar'); if (b) b.hidden = true; $('#reader') && $('#reader').classList.remove('drawing'); },
};
ACT['r-mark'] = () => Ann.setOn(!Ann.on);
ACT['ann-tool'] = el => { Ann.tool = el.dataset.t; Ann.syncBar(); };
ACT['ann-col'] = el => { Ann.cols[Ann.tool] = el.dataset.c; Ann.syncBar(); };
ACT['ann-size'] = el => { Ann.size = +el.dataset.v; Ann.syncBar(); };
ACT['ann-undo'] = () => Ann.doUndo();
ACT['ann-redo'] = () => Ann.doRedo();
ACT['ann-done'] = () => Ann.setOn(false);
document.addEventListener('touchstart', e => { if (e.touches.length > 1) Ann.cancel(); }, { passive: true });

/* ================= highlights in reflowed books ================= */
const Hl = {
  apply(root, ch) {
    const b = RD && RD.b; if (!b || !b.hl) return;
    for (const h of b.hl) if (h.ch === ch) this.wrap(root, h);
  },
  wrap(root, h) {
    const w = document.createTreeWalker(root, NodeFilter.SHOW_TEXT), parts = []; let pos = 0, n;
    while ((n = w.nextNode())) {
      const len = n.nodeValue.length, a = Math.max(h.s, pos), z = Math.min(h.e, pos + len);
      if (z > a) parts.push([n, a - pos, z - pos]);
      pos += len; if (pos >= h.e) break;
    }
    for (const [t, a, z] of parts.reverse()) {
      try { const r = document.createRange(); r.setStart(t, a); r.setEnd(t, z); const m = document.createElement('mark'); m.className = 'hl hl-' + h.c; m.dataset.id = h.id; r.surroundContents(m); } catch (e) { }
    }
  },
  add(c) {
    const sel = window.getSelection(), art = $('#rart');
    if (!sel || sel.isCollapsed || !art) return;
    const r = sel.getRangeAt(0); if (!art.contains(r.commonAncestorContainer)) return;
    const pre = document.createRange(); pre.selectNodeContents(art); pre.setEnd(r.startContainer, r.startOffset);
    const s = pre.toString().length, t = r.toString(), b = RD.b;
    if (!t.trim()) return;
    if (!b.hl) b.hl = [];
    b.hl.push({ id: 'h' + Date.now().toString(36), ch: RD.ch, s, e: s + t.length, c, t: t.replace(/\s+/g, ' ').trim().slice(0, 320) });
    saveBook(b); sel.removeAllRanges(); this.rerender();
  },
  rerender() { const el = $('#rtext'), r = el.scrollHeight > el.clientHeight ? el.scrollTop / (el.scrollHeight - el.clientHeight) : 0; rdShowChapter(RD.ch, r); },
  remove(id) { const b = RD.b; b.hl = (b.hl || []).filter(h => h.id !== id); saveBook(b); this.rerender(); },
};
ACT['hl-add'] = el => { Hl.add(el.dataset.c); $('#selbar').hidden = true; };
ACT['hl-del'] = el => { Hl.remove(el.dataset.id); Sheet.close(); };
document.addEventListener('click', e => {
  const m = e.target.closest && e.target.closest('mark.hl'); if (!m || !RD || !$('#rart').contains(m)) return;
  const h = (RD.b.hl || []).find(x => x.id === m.dataset.id); if (!h) return;
  Sheet.open(`<blockquote class="serif" style="margin:0 0 14px;border-left:3px solid ${HLC[h.c]};padding-left:12px">${esc(h.t)}</blockquote>
    <div class="row gap wrap"><button class="btn" data-act="hl-del" data-id="${h.id}">${ic('trash', 16)} Remove highlight</button><button class="btn" data-act="hl-quote" data-id="${h.id}">${ic('quote', 16)} Save as quote</button></div>`, { title: 'Highlight' });
});
ACT['hl-quote'] = el => { const h = (RD.b.hl || []).find(x => x.id === el.dataset.id); if (h) { Quotes.toggleFav({ t: h.t, bookId: RD.b.id, mine: true, ...readerPlace() }); Sheet.close(); toast('Quote saved'); } };

ACT['opt'] = el => {
  const k = el.dataset.k, v = el.dataset.v; ST[k] = v === 'true' ? true : v === 'false' ? false : v; saveST();
  if (k === 'ui') applyScale();
  if (k === 'dict') Dict.pc.clear();
  const sc = $('#main').scrollTop; render(); $('#main').scrollTop = sc;
};
