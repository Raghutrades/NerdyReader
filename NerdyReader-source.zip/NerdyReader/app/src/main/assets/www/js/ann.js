'use strict';
/* ===== NerdyReader · marking up books =====
   PDF pages: highlighter, pen, line, rectangle, text note, eraser, drawn on a transparent layer over each page.
              Marks are stored per page as fractions of the page size, so they stay put when you zoom or resize.
   Other books (EPUB, text, Word…): select text, pick a colour, and it is highlighted (stored as character offsets in the chapter). */
const HLC = { y: '#ffd43b', g: '#69db7c', b: '#4dabf7', p: '#f783ac', o: '#ff922b' };
const Ann = {
  on: false, tool: 'hand', size: 1, fill: false, pop: false, min: false, undo: [], redo: [], cv: new Set(), cur: null,
  cols: { hl: '#ffd43b', pen: '#e03131', line: '#e03131', rect: '#e03131', text: '#ffd43b' },
  PAL: ['#ffd43b', '#69db7c', '#4dabf7', '#f783ac', '#ff922b', '#e03131', '#1f1f1f'],
  ICON: { hand: 'hand', hl: 'marker', pen: 'pen', line: 'line', rect: 'rect', text: 'textnote', er: 'eraser' },
  active() { return this.on && this.tool !== 'hand' && !!RD; },
  strokes(p) { const b = RD && RD.b; return (b && b.ann && b.ann[p]) || []; },
  curPages() {
    if (Book.on && Book.src && Book.src.kind === 'pdf') { const f = Book.facesAt(Book.src, Book.cur.s); return [f.l, f.r].filter(x => x != null && x < Book.src.n).map(x => x + 1); }
    return [RD.page];
  },

  /* ---- the transparent layer on a page ---- */
  attach(host, p, w, h, scale) {
    if (!RD || RD.kind !== 'pages' || !host) return;
    let cv = host.querySelector(':scope > canvas.annc');
    if (!cv) { cv = document.createElement('canvas'); cv.className = 'annc'; host.appendChild(cv); this.bind(cv); }
    cv._p = p; this.cv.add(cv);
    const dpr = Math.min(window.devicePixelRatio || 1, 2) * (scale || 1), k = Math.min(1, 4096 / Math.max(w * dpr, h * dpr, 1));
    cv.width = Math.max(1, Math.round(w * dpr * k)); cv.height = Math.max(1, Math.round(h * dpr * k));
    this.draw(cv);
  },
  draw(cv) {
    const g = cv.getContext('2d'), W = cv.width, H = cv.height; g.clearRect(0, 0, W, H);
    for (const s of this.strokes(cv._p)) this.paint(g, s, W, H);
    if (this.cur && this.cur.cv === cv && !['er', 'text'].includes(this.cur.k)) this.paint(g, this.cur, W, H);
  },
  paint(g, s, W, H) {
    const p = s.p; if (!p || !p.length) return;
    g.save(); g.lineJoin = 'round'; g.lineCap = s.k === 'hl' ? 'square' : 'round';
    g.strokeStyle = g.fillStyle = s.c; g.lineWidth = Math.max(1.2, s.w * W);
    if (s.k === 'tx') { this.paintText(g, s, W, H); g.restore(); return; }
    g.globalAlpha = s.k === 'hl' ? 0.42 : 1;
    if (s.k === 'line') { g.beginPath(); g.moveTo(p[0] * W, p[1] * H); g.lineTo(p[2] * W, p[3] * H); g.stroke(); }
    else if (s.k === 'rect') {
      const x = Math.min(p[0], p[2]) * W, y = Math.min(p[1], p[3]) * H, w = Math.abs(p[2] - p[0]) * W, h = Math.abs(p[3] - p[1]) * H, r = Math.min(6, w / 4, h / 4);
      g.beginPath(); g.moveTo(x + r, y); g.arcTo(x + w, y, x + w, y + h, r); g.arcTo(x + w, y + h, x, y + h, r); g.arcTo(x, y + h, x, y, r); g.arcTo(x, y, x + w, y, r); g.closePath();
      if (s.f) { g.globalAlpha = 0.2; g.fill(); g.globalAlpha = 1; }
      g.stroke();
    } else if (p.length <= 2) { g.beginPath(); g.arc(p[0] * W, p[1] * H, g.lineWidth / 2, 0, 6.2832); g.fill(); }
    else {
      g.beginPath(); g.moveTo(p[0] * W, p[1] * H);
      for (let i = 2; i < p.length - 2; i += 2) g.quadraticCurveTo(p[i] * W, p[i + 1] * H, (p[i] + p[i + 2]) / 2 * W, (p[i + 1] + p[i + 3]) / 2 * H);
      g.lineTo(p[p.length - 2] * W, p[p.length - 1] * H); g.stroke();
    }
    g.restore();
  },
  paintText(g, s, W, H) {                                         // a small note: tinted box, dark text
    const fs = s.w * W, pad = fs * 0.5, maxw = (s.bw || 0.46) * W - pad * 2;
    g.font = '500 ' + fs + 'px system-ui,Roboto,sans-serif'; g.textBaseline = 'top';
    const lines = [];
    for (const para of String(s.t || '').split('\n')) {
      let line = '';
      for (const w of para.split(/\s+/).filter(Boolean)) { const t = line ? line + ' ' + w : w; if (g.measureText(t).width > maxw && line) { lines.push(line); line = w; } else line = t; }
      lines.push(line);
    }
    const bw = Math.min(maxw, Math.max(...lines.map(l => g.measureText(l).width), fs)) + pad * 2, bh = lines.length * fs * 1.3 + pad * 2;
    const x = clamp(s.p[0] * W, 0, Math.max(0, W - bw)), y = clamp(s.p[1] * H, 0, Math.max(0, H - bh));
    g.globalAlpha = 0.34; g.fillStyle = s.c; g.beginPath(); g.moveTo(x + 6, y); g.arcTo(x + bw, y, x + bw, y + bh, 6); g.arcTo(x + bw, y + bh, x, y + bh, 6); g.arcTo(x, y + bh, x, y, 6); g.arcTo(x, y, x + bw, y, 6); g.closePath(); g.fill();
    g.globalAlpha = 0.7; g.strokeStyle = s.c; g.lineWidth = 1.2; g.stroke();
    g.globalAlpha = 1; g.fillStyle = '#1d1d1d'; lines.forEach((l, i) => g.fillText(l, x + pad, y + pad + i * fs * 1.3));
    s._bb = [x / W, y / H, (x + bw) / W, (y + bh) / H];
  },
  refresh(page) { for (const cv of [...this.cv]) { if (!cv.isConnected) this.cv.delete(cv); else if (cv._p === page) this.draw(cv); } },
  refreshAll() { for (const cv of [...this.cv]) { if (!cv.isConnected) this.cv.delete(cv); else this.draw(cv); } },
  save() { clearTimeout(this._t); this._t = setTimeout(() => RD && saveBook(RD.b), 500); },

  /* ---- drawing with a finger or a stylus ---- */
  bind(cv) {
    cv.addEventListener('pointerdown', e => {
      if (!Ann.active() || !e.isPrimary) return;
      e.preventDefault(); e.stopPropagation();
      try { cv.setPointerCapture(e.pointerId); } catch (er) { }
      Ann.begin(cv, e);
    });
    cv.addEventListener('pointermove', e => { if (Ann.cur && Ann.cur.id === e.pointerId) { e.stopPropagation(); Ann.move(e); } });
    cv.addEventListener('pointerup', e => { if (Ann.cur && Ann.cur.id === e.pointerId) { e.stopPropagation(); Ann.end(); } });
    cv.addEventListener('pointercancel', () => Ann.cancel());
  },
  pt(e) { const r = this.cur.r; return { x: clamp((e.clientX - r.left) / r.width, 0, 1), y: clamp((e.clientY - r.top) / r.height, 0, 1) }; },
  begin(cv, e) {
    const k = this.tool, sz = this.size;
    const w = k === 'hl' ? 0.024 * sz : k === 'pen' ? 0.0036 * sz : k === 'text' ? 0.03 * sz : 0.0045 * sz;
    this.cur = { id: e.pointerId, cv, r: cv.getBoundingClientRect(), k, c: this.cols[k], w, p: [], removed: [], moved: false };
    const q = this.pt(e); this.cur.q0 = q;
    if (this.pop) { this.pop = false; this.syncBar(); }
    if (k === 'er') this.erase(q);
    else if (k === 'line' || k === 'rect') { this.cur.p = [q.x, q.y, q.x, q.y]; if (k === 'rect' && this.fill) this.cur.f = 1; }
    else if (k !== 'text') { this.cur.p.push(q.x, q.y); this.draw(cv); }
    Track.touch();
  },
  move(e) {
    const c = this.cur, q = this.pt(e), asp = c.r.height / c.r.width;
    if (Math.hypot(q.x - c.q0.x, (q.y - c.q0.y) * asp) > 0.012) c.moved = true;
    if (c.k === 'er') return this.erase(q);
    if (c.k === 'text') return;
    if (c.k === 'line') {
      let x = q.x, y = q.y;
      if (Math.abs(y - c.q0.y) * c.r.height < 9) y = c.q0.y;                      // level and upright lines click into place
      else if (Math.abs(x - c.q0.x) * c.r.width < 9) x = c.q0.x;
      c.p = [c.q0.x, c.q0.y, x, y];
    } else if (c.k === 'rect') c.p = [c.q0.x, c.q0.y, q.x, q.y];
    else { const n = c.p.length; if (Math.hypot(q.x - c.p[n - 2], (q.y - c.p[n - 1]) * asp) > 0.003) c.p.push(q.x, q.y); }
    this.draw(c.cv);
  },
  cancel() { const c = this.cur; this.cur = null; if (c) this.refresh(c.cv._p); },
  end() {
    const c = this.cur; if (!c) return; this.cur = null;
    const page = c.cv._p;
    if (c.k === 'er') { if (c.removed.length) { this.undo.push({ t: 'del', page, items: c.removed }); this.redo = []; this.save(); this.syncBar(); } return this.refresh(page); }
    if (c.k === 'text') { if (!c.moved) this.editText(c.cv, c.q0); return; }
    let p = c.p;
    if (c.k === 'hl' && p.length >= 4) {                               // a nearly level swipe becomes a neat straight highlight
      let lo = 1, hi = 0, sy = 0; for (let i = 1; i < p.length; i += 2) { lo = Math.min(lo, p[i]); hi = Math.max(hi, p[i]); sy += p[i]; }
      if ((hi - lo) * c.r.height < c.w * c.r.width * 0.8) p = [p[0], sy / (p.length / 2), p[p.length - 2], sy / (p.length / 2)];
    }
    if ((c.k === 'line' || c.k === 'rect') && Math.hypot(p[2] - p[0], (p[3] - p[1]) * c.r.height / c.r.width) < 0.012) return this.draw(c.cv);
    if (p.length < 2) return this.draw(c.cv);
    const s = { k: c.k, c: c.c, w: c.w, p: p.map(v => Math.round(v * 10000) / 10000) }; if (c.f) s.f = 1;
    this.addStroke(page, s); this.refresh(page);
  },
  addStroke(page, s) {
    const b = RD.b; if (!b.ann) b.ann = {}; if (!b.ann[page]) b.ann[page] = [];
    b.ann[page].push(s); this.undo.push({ t: 'add', page, s }); this.redo = []; this.save(); this.syncBar();
  },
  segs(s) {
    const p = s.p, o = [];
    if (s.k === 'line') o.push([p[0], p[1], p[2], p[3]]);
    else if (s.k === 'rect') { o.push([p[0], p[1], p[2], p[1]], [p[2], p[1], p[2], p[3]], [p[2], p[3], p[0], p[3]], [p[0], p[3], p[0], p[1]]); }
    else if (p.length <= 2) o.push([p[0], p[1], p[0], p[1]]);
    else for (let i = 0; i + 3 < p.length; i += 2) o.push([p[i], p[i + 1], p[i + 2], p[i + 3]]);
    return o;
  },
  hit(s, q, asp, R) {
    if (s.k === 'tx') { const b = s._bb; return !!b && q.x >= b[0] - 0.01 && q.x <= b[2] + 0.01 && q.y >= b[1] - 0.01 && q.y <= b[3] + 0.01; }
    if (s.k === 'rect' && s.f && q.x >= Math.min(s.p[0], s.p[2]) && q.x <= Math.max(s.p[0], s.p[2]) && q.y >= Math.min(s.p[1], s.p[3]) && q.y <= Math.max(s.p[1], s.p[3])) return true;
    for (const [ax, ay, bx, by] of this.segs(s)) {
      const dx = bx - ax, dy = (by - ay) * asp, l2 = dx * dx + dy * dy;
      let t = l2 ? ((q.x - ax) * dx + (q.y - ay) * asp * dy) / l2 : 0; t = clamp(t, 0, 1);
      if (Math.hypot(q.x - (ax + dx * t), (q.y - ay) * asp - dy * t) < R + s.w / 2) return true;
    }
    return false;
  },
  erase(q) {
    const c = this.cur, list = this.strokes(c.cv._p), asp = c.r.height / c.r.width, R = 0.024;
    const gone = []; list.forEach((s, i) => { if (this.hit(s, q, asp, R)) gone.push(i); });
    if (!gone.length) return;
    for (let k = gone.length - 1; k >= 0; k--) c.removed.unshift({ s: list.splice(gone[k], 1)[0], i: gone[k] });
    this.refresh(c.cv._p);
  },

  /* ---- text notes ---- */
  editText(cv, q) {
    const list = this.strokes(cv._p), asp = cv.height / cv.width, idx = list.findIndex(s => s.k === 'tx' && this.hit(s, q, asp, 0));
    this._ed = { cv, q, idx, page: cv._p };
    const old = idx >= 0 ? list[idx].t : '';
    Sheet.open(`<textarea id="annTx" class="annta" rows="4" placeholder="Write a note or a paragraph…" maxlength="1200">${esc(old)}</textarea>
      <div class="row gap" style="margin-top:12px"><button class="btn pri" data-act="ann-txsave">${ic('check', 16)} ${idx >= 0 ? 'Update' : 'Add note'}</button>${idx >= 0 ? `<button class="btn danger" data-act="ann-txdel">${ic('trash', 16)} Delete</button>` : ''}</div>`, { title: idx >= 0 ? 'Edit note' : 'New note' });
    setTimeout(() => { const t = $('#annTx'); t && t.focus(); }, 320);
  },
  saveText() {
    const e = this._ed, t = ($('#annTx').value || '').trim(); if (!e) return;
    const list = this.strokes(e.page);
    if (e.idx >= 0 && list[e.idx]) { if (t) list[e.idx].t = t; this.save(); }
    else if (t) { const sz = this.size; this.addStroke(e.page, { k: 'tx', c: this.cols.text, w: 0.03 * sz, bw: 0.46, p: [Math.round(e.q.x * 1e4) / 1e4, Math.round(e.q.y * 1e4) / 1e4], t }); }
    Sheet.close(); this.refresh(e.page);
  },
  delText() {
    const e = this._ed, list = this.strokes(e.page); if (!e || e.idx < 0 || !list[e.idx]) return;
    const s = list.splice(e.idx, 1)[0]; this.undo.push({ t: 'del', page: e.page, items: [{ s, i: e.idx }] }); this.redo = []; this.save(); this.syncBar();
    Sheet.close(); this.refresh(e.page);
  },

  /* ---- clear, undo, redo ---- */
  doClear(scope) {
    const b = RD.b; if (!b.ann) return toast('Nothing to clear');
    const pages = scope === 'all' ? Object.keys(b.ann).map(Number) : this.curPages(), snap = {};
    pages.forEach(p => { const l = b.ann[p]; if (l && l.length) { snap[p] = l.slice(); b.ann[p] = []; } });
    if (!Object.keys(snap).length) return toast('Nothing to clear');
    this.undo.push({ t: 'clr', snap }); this.redo = []; this.save(); this.syncBar(); this.refreshAll();
    toast(scope === 'all' ? 'All marks cleared' : 'Page cleared');
  },
  doUndo() {
    const o = this.undo.pop(); if (!o) return; const b = RD.b;
    if (o.t === 'clr') { if (!b.ann) b.ann = {}; Object.keys(o.snap).forEach(p => { b.ann[p] = o.snap[p].slice(); }); this.redo.push(o); this.save(); this.syncBar(); return this.refreshAll(); }
    const l = (b.ann && b.ann[o.page]) || [];
    if (o.t === 'add') { const i = l.indexOf(o.s); if (i >= 0) l.splice(i, 1); } else o.items.slice().sort((a, b) => a.i - b.i).forEach(x => l.splice(x.i, 0, x.s));
    this.redo.push(o); this.save(); this.syncBar(); this.refresh(o.page);
  },
  doRedo() {
    const o = this.redo.pop(); if (!o) return; const b = RD.b;
    if (o.t === 'clr') { Object.keys(o.snap).forEach(p => { b.ann[p] = []; }); this.undo.push(o); this.save(); this.syncBar(); return this.refreshAll(); }
    if (!b.ann) b.ann = {}; if (!b.ann[o.page]) b.ann[o.page] = [];
    const l = b.ann[o.page];
    if (o.t === 'add') l.push(o.s); else o.items.forEach(x => { const i = l.indexOf(x.s); if (i >= 0) l.splice(i, 1); });
    this.undo.push(o); this.save(); this.syncBar(); this.refresh(o.page);
  },

  /* ---- the tool rail: slim, on the right edge, out of the way of the page ---- */
  barHTML() {
    if (this.min) return `<button class="dt on" data-act="ann-min" aria-label="Show tools">${ic(this.ICON[this.tool], 20)}</button>`;
    const T = (t, l) => `<button class="dt ${this.tool === t ? 'on' : ''}" data-act="ann-tool" data-t="${t}" aria-label="${l}">${ic(this.ICON[t], 20)}</button>`;
    const styled = !['hand', 'er'].includes(this.tool), col = this.cols[this.tool] || '#ffd43b';
    return `<button class="dt done" data-act="ann-done" aria-label="Done">${ic('check', 20)}</button><i class="dsep"></i>
      ${T('hand', 'Move')}${T('hl', 'Highlighter')}${T('pen', 'Pen')}${T('line', 'Line')}${T('rect', 'Rectangle')}${T('text', 'Note')}${T('er', 'Eraser')}<i class="dsep"></i>
      <button class="dt" data-act="ann-style" ${styled ? '' : 'disabled'} aria-label="Colour and size"><span class="dsw" style="--c:${col}"></span></button>
      <button class="dt" data-act="ann-undo" aria-label="Undo" ${this.undo.length ? '' : 'disabled'}>${ic('undo', 19)}</button>
      <button class="dt" data-act="ann-redo" aria-label="Redo" ${this.redo.length ? '' : 'disabled'}>${ic('redo', 19)}</button>
      <button class="dt" data-act="ann-clear" aria-label="Clear">${ic('trash', 19)}</button>
      <button class="dt hide" data-act="ann-min" aria-label="Hide tools">${ic('right', 16)}</button>
      ${this.pop && styled ? `<div class="dpop">${this.PAL.map(c => `<button class="dc ${c === col ? 'on' : ''}" style="--c:${c}" data-act="ann-col" data-c="${c}" aria-label="Colour"></button>`).join('')}
        ${[[0.6, 8], [1, 13], [1.8, 19]].map(([v, d]) => `<button class="dz ${this.size === v ? 'on' : ''}" data-act="ann-size" data-v="${v}" aria-label="Size"><i style="width:${d}px;height:${d}px"></i></button>`).join('')}
        ${this.tool === 'rect' ? `<button class="dfill ${this.fill ? 'on' : ''}" data-act="ann-fill">Fill</button>` : ''}</div>` : ''}`;
  },
  syncBar() { const b = $('#drawbar'); if (b && !b.hidden) { b.innerHTML = this.barHTML(); b.classList.toggle('min', this.min); } },
  setOn(v) {
    if (v && (!RD || RD.kind !== 'pages')) return toast('Drawing works on PDF pages. In other books, select text to highlight it.', 3200);
    this.on = v; this.pop = false; this.min = false; if (v && this.tool === 'hand') this.tool = 'hl';
    const bar = $('#drawbar'); bar.hidden = !v; $('#reader').classList.toggle('drawing', v);
    if (v) { RD.immersive = true; $('#reader').classList.add('imm'); this.syncBar(); }
    $('#rmark') && $('#rmark').classList.toggle('on', v);
  },
  reset() { this.on = false; this.tool = 'hand'; this.undo = []; this.redo = []; this.cv.clear(); this.cur = null; this.pop = false; this.min = false; const b = $('#drawbar'); if (b) b.hidden = true; $('#reader') && $('#reader').classList.remove('drawing'); },
};
ACT['r-mark'] = () => Ann.setOn(!Ann.on);
ACT['ann-tool'] = el => { Ann.tool = el.dataset.t; Ann.pop = false; Ann.syncBar(); };
ACT['ann-col'] = el => { Ann.cols[Ann.tool] = el.dataset.c; Ann.pop = false; Ann.syncBar(); };
ACT['ann-size'] = el => { Ann.size = +el.dataset.v; Ann.syncBar(); };
ACT['ann-fill'] = () => { Ann.fill = !Ann.fill; Ann.syncBar(); };
ACT['ann-style'] = () => { Ann.pop = !Ann.pop; Ann.syncBar(); };
ACT['ann-min'] = () => { Ann.min = !Ann.min; Ann.pop = false; Ann.syncBar(); };
ACT['ann-undo'] = () => Ann.doUndo();
ACT['ann-redo'] = () => Ann.doRedo();
ACT['ann-done'] = () => Ann.setOn(false);
ACT['ann-clear'] = () => Sheet.open(`<div class="clrs"><button class="btn" data-act="ann-clr" data-s="page">${ic('trash', 16)} Clear this page</button><button class="btn danger" data-act="ann-clr" data-s="all">${ic('trash', 16)} Clear every mark in this book</button><button class="btn" data-act="sheet-close">Cancel</button></div>`, { title: 'Clear drawings' });
ACT['ann-clr'] = el => { Sheet.close(); Ann.doClear(el.dataset.s); };
ACT['ann-txsave'] = () => Ann.saveText();
ACT['ann-txdel'] = () => Ann.delText();
document.addEventListener('touchstart', e => { if (e.touches.length > 1) Ann.cancel(); }, { passive: true });

/* ================= highlights in reflowed books ================= */
const Hl = {
  apply(root, ch) {
    const b = RD && RD.b; if (!b || !b.hl) return;
    for (const h of b.hl) if (h.ch === ch) this.wrap(root, h);
  },
  wrap(root, h) {
    const w = document.createTreeWalker(root, NodeFilter.SHOW_TEXT), parts = []; let pos = 0, n;
    while ((n = w.nextNode())) {
      const len = n.nodeValue.length, a = Math.max(h.s, pos), z = Math.min(h.e, pos + len);
      if (z > a) parts.push([n, a - pos, z - pos]);
      pos += len; if (pos >= h.e) break;
    }
    for (const [t, a, z] of parts.reverse()) {
      try { const r = document.createRange(); r.setStart(t, a); r.setEnd(t, z); const m = document.createElement('mark'); m.className = 'hl hl-' + h.c; m.dataset.id = h.id; r.surroundContents(m); } catch (e) { }
    }
  },
  add(c) {
    const sel = window.getSelection(), art = $('#rart');
    if (!sel || sel.isCollapsed || !art) return;
    const r = sel.getRangeAt(0); if (!art.contains(r.commonAncestorContainer)) return;
    const pre = document.createRange(); pre.selectNodeContents(art); pre.setEnd(r.startContainer, r.startOffset);
    const s = pre.toString().length, t = r.toString(), b = RD.b;
    if (!t.trim()) return;
    if (!b.hl) b.hl = [];
    b.hl.push({ id: 'h' + Date.now().toString(36), ch: RD.ch, s, e: s + t.length, c, t: t.replace(/\s+/g, ' ').trim().slice(0, 320) });
    saveBook(b); sel.removeAllRanges(); this.rerender();
  },
  rerender() { const el = $('#rtext'), r = el.scrollHeight > el.clientHeight ? el.scrollTop / (el.scrollHeight - el.clientHeight) : 0; rdShowChapter(RD.ch, r); },
  remove(id) { const b = RD.b; b.hl = (b.hl || []).filter(h => h.id !== id); saveBook(b); this.rerender(); },
};
ACT['hl-add'] = el => { Hl.add(el.dataset.c); $('#selbar').hidden = true; };
ACT['hl-del'] = el => { Hl.remove(el.dataset.id); Sheet.close(); };
document.addEventListener('click', e => {
  const m = e.target.closest && e.target.closest('mark.hl'); if (!m || !RD || !$('#rart').contains(m)) return;
  const h = (RD.b.hl || []).find(x => x.id === m.dataset.id); if (!h) return;
  Sheet.open(`<blockquote class="serif" style="margin:0 0 14px;border-left:3px solid ${HLC[h.c]};padding-left:12px">${esc(h.t)}</blockquote>
    <div class="row gap wrap"><button class="btn" data-act="hl-del" data-id="${h.id}">${ic('trash', 16)} Remove highlight</button><button class="btn" data-act="hl-quote" data-id="${h.id}">${ic('quote', 16)} Save as quote</button></div>`, { title: 'Highlight' });
});
ACT['hl-quote'] = el => { const h = (RD.b.hl || []).find(x => x.id === el.dataset.id); if (h) { Quotes.toggleFav({ t: h.t, bookId: RD.b.id, mine: true, ...readerPlace() }); Sheet.close(); toast('Quote saved'); } };

ACT['opt'] = el => {
  const k = el.dataset.k, v = el.dataset.v; ST[k] = v === 'true' ? true : v === 'false' ? false : v; saveST();
  if (k === 'ui') applyScale();
  if (k === 'full') setFull(ST.full);
  if (k === 'dict') Dict.pc.clear();
  const sc = $('#main').scrollTop; render(); $('#main').scrollTop = sc;
};

ACT['wn-license'] = async () => { let t = ''; try { t = await fetch('data/WORDNET-LICENSE.txt').then(r => r.text()); } catch (e) { } Sheet.open(`<pre class="lic">${esc(t || 'WordNet 3.1 © 2011 Princeton University. See https://wordnet.princeton.edu/license-and-commercial-use')}</pre>`, { title: 'WordNet licence' }); };
