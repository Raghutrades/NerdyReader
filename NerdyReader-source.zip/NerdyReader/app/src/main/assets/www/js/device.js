'use strict';
/* ===== NerdyReader · the documents on this phone =====
   With the phone's "all files" permission the app lists every PDF, EPUB, Word, text, Markdown and web file it finds
   (names, sizes and dates only; nothing is read until you open one, and nothing ever leaves the phone).
   A document is copied into the library the first time you open it, so reading progress, stats and marks work as usual. */
const DEXT = { pdf: 'pdf', epub: 'epub', docx: 'docx', txt: 'txt', md: 'md', markdown: 'md', html: 'html', htm: 'html' };
const DLAB = { pdf: 'PDF', epub: 'EPUB', docx: 'Word', txt: 'Text', md: 'Markdown', html: 'Web' };
const DCOL = { pdf: ['#e8590c', '#c2255c'], epub: ['#2f9e44', '#0b7285'], docx: ['#1971c2', '#364fc7'], txt: ['#868e96', '#495057'], md: ['#7048e8', '#5f3dc4'], html: ['#f08c00', '#e8590c'] };
const SORTS = [['new', 'Newest'], ['old', 'Oldest'], ['az', 'Name A–Z'], ['za', 'Name Z–A'], ['big', 'Largest'], ['small', 'Smallest'], ['read', 'Last opened']];
const dFmtSize = n => !n ? '' : n < 1048576 ? Math.max(1, Math.round(n / 1024)) + ' KB' : n < 1073741824 ? (n / 1048576).toFixed(n < 10485760 ? 1 : 0) + ' MB' : (n / 1073741824).toFixed(1) + ' GB';
const dFmtDate = t => { if (!t) return ''; const d = new Date(t), n = new Date(); return d.toLocaleDateString(undefined, d.getFullYear() === n.getFullYear() ? { day: 'numeric', month: 'short' } : { day: 'numeric', month: 'short', year: 'numeric' }); };

const Dev = {
  items: [], access: null, scanning: false, last: 0, map: new Map(), thumbs: new Map(), tq: [], busyThumb: 0, io: null, _tmp: null,
  root: '/storage/emulated/0/',

  init() {
    S.lib = Object.assign({ f: 'all', sort: 'new', folder: '', n: 60, q: '', group: false }, S.lib || {});
    try { const c = JSON.parse(localStorage.getItem('nr-dev')); if (c && c.items) { this.items = c.items.map(a => this.norm(a)); this.last = c.t || 0; } } catch (e) { }
    this.check();
  },
  save() { try { localStorage.setItem('nr-dev', JSON.stringify({ t: this.last, items: this.items.map(x => [x.n, x.p, x.s, x.m]) })); } catch (e) { } },
  check() { this.access = AB && AB.hasFilesAccess ? !!AB.hasFilesAccess() : null; return this.access; },
  norm(a) {
    const o = Array.isArray(a) ? { n: a[0], p: a[1], s: a[2], m: a[3] } : a;
    o.ext = (o.n.split('.').pop() || '').toLowerCase(); o.fmt = DEXT[o.ext] || 'txt';
    o.title = o.n.replace(/\.[^.]+$/, '').replace(/[_]+/g, ' ').replace(/\s+/g, ' ').trim() || o.n;
    const rel = o.p.startsWith(this.root) ? o.p.slice(this.root.length) : o.p.replace(/^\/storage\//, '');
    o.rp = rel || 'Internal storage'; o.fo = o.rp.split('/').pop() || o.rp;
    return o;
  },
  b64(p) { return btoa(unescape(encodeURIComponent(p))).replace(/\+/g, '-').replace(/\//g, '_'); },

  /* ---------- scanning ---------- */
  scan(force) {
    if (!AB || !AB.scanDocs || this.scanning || !this.check()) return;
    if (!force && Date.now() - this.last < 90000) return;
    this.scanning = true; this._tmp = []; this.ui(); AB.scanDocs();
  },
  onBatch(list) { if (!this._tmp) this._tmp = []; list.forEach(x => this._tmp.push(this.norm(x))); this.ui(); },
  onDone() {
    this.items = this._tmp || []; this._tmp = null; this.scanning = false; this.last = Date.now(); this.save(); this.ui();
    if (S.view === 'library' || S.view === 'home' || S.view === 'search') { const sc = $('#main').scrollTop; render(); $('#main').scrollTop = sc; }
    const n = this.items.length; if (n && S.view !== 'library') toast(n + ' document' + (n === 1 ? '' : 's') + ' found on this phone', 2400);
  },
  ui() {
    const el = $('#dstat'); if (el) el.innerHTML = this.statText();
    const b = $('[data-act=dev-scan]'); if (b) b.classList.toggle('scanning', this.scanning);
  },
  statText() {
    const n = this._tmp && this.scanning ? this._tmp.length : this.items.length, fo = new Set((this._tmp && this.scanning ? this._tmp : this.items).map(x => x.rp)).size;
    return `${n} document${n === 1 ? '' : 's'} · ${fo} folder${fo === 1 ? '' : 's'}${this.scanning ? ' · scanning…' : ''}`;
  },

  /* ---------- the list ---------- */
  entries() {
    const books = bookList(), by = new Map(books.map(b => [b.fileName + '|' + b.size, b])), used = new Set(), out = [];
    for (const it of this.items) {
      const b = by.get(it.n + '|' + it.s); if (b) used.add(b.id);
      out.push({ k: it.p + '/' + it.n, it, b, title: b ? b.title : it.title, fmt: it.fmt, size: it.s, mod: it.m, rp: it.rp, fo: it.fo });
    }
    for (const b of books) if (!used.has(b.id)) out.push({ k: 'b:' + b.id, it: null, b, title: b.title, fmt: b.format, size: b.size || 0, mod: b.added, rp: 'In the app', fo: 'In the app' });
    this.map = new Map(out.map(e => [e.k, e]));
    return out;
  },
  match(e, f) {
    const b = e.b;
    switch (f) {
      case 'pdf': case 'epub': case 'docx': case 'txt': return e.fmt === f;
      case 'web': return e.fmt === 'md' || e.fmt === 'html';
      case 'recent': return !!(b && b.lastRead);
      case 'saved': return !!(b && b.saved);
      case 'done': return !!(b && b.progress >= 1);
      default: return true;
    }
  },
  view(all) {                                   // search + folder + type + sort
    const L = S.lib, w = (L.q || '').toLowerCase().split(/\s+/).filter(Boolean);
    let l = all.filter(e => (!L.folder || e.rp === L.folder) && (!w.length || w.every(x => (e.title + ' ' + (e.it ? e.it.n : '') + ' ' + e.rp + ' ' + ((e.b && e.b.author) || '')).toLowerCase().includes(x))));
    const counts = {}; for (const f of ['all', 'recent', 'pdf', 'epub', 'docx', 'txt', 'web', 'saved', 'done']) counts[f] = l.filter(e => this.match(e, f)).length;
    l = l.filter(e => this.match(e, L.f));
    const cmp = { new: (a, b) => b.mod - a.mod, old: (a, b) => a.mod - b.mod, az: (a, b) => a.title.localeCompare(b.title), za: (a, b) => b.title.localeCompare(a.title), big: (a, b) => b.size - a.size, small: (a, b) => a.size - b.size, read: (a, b) => ((b.b && b.b.lastRead) || 0) - ((a.b && a.b.lastRead) || 0) }[L.sort] || (() => 0);
    return { list: l.sort(cmp), counts };
  },

  /* ---------- cards ---------- */
  cover(e) {
    const th = this.thumbs.get(e.k);
    if (e.b && e.b.cover) return `<div class="dcv"><img src="${e.b.cover}" alt=""><span class="dcx">${DLAB[e.fmt]}</span></div>`;
    if (th) return `<div class="dcv"><img src="${th}" alt=""><span class="dcx">${DLAB[e.fmt]}</span></div>`;
    const [a, d] = DCOL[e.fmt] || DCOL.txt, L = (e.title.match(/[A-Za-z0-9]/) || ['N'])[0].toUpperCase();
    return `<div class="dcv gen" style="--c1:${a};--c2:${d}" ${e.fmt === 'pdf' && e.it && !e.b ? `data-th="${esc(e.k)}"` : ''}><i>${L}</i><b>${esc(shortStr(e.title, 40))}</b><span class="dcx">${DLAB[e.fmt]}</span></div>`;
  },
  card(e, small) {
    const pr = e.b && e.b.progress > 0 ? `<i class="dpr"><u style="width:${pct(e.b)}%"></u></i>` : '';
    return `<a class="dcard ${small ? 's' : ''}" data-act="dev-open" data-k="${esc(e.k)}">${this.cover(e)}${pr}<div class="dci"><b>${esc(e.title)}</b><small>${DLAB[e.fmt]}${e.size ? ' · ' + dFmtSize(e.size) : ''}${e.mod ? ' · ' + dFmtDate(e.mod) : ''}</small></div></a>`;
  },
  row(e) {
    const pr = e.b && e.b.progress > 0 ? `<i class="dpr"><u style="width:${pct(e.b)}%"></u></i><small>${pct(e.b)}% read</small>` : '';
    return `<div class="drow"><a class="drl" data-act="dev-open" data-k="${esc(e.k)}">${this.cover(e).replace('class="dcv', 'class="dcv rs')}<div class="dri"><b>${esc(e.title)}</b><small>${DLAB[e.fmt]}${e.size ? ' · ' + dFmtSize(e.size) : ''}${e.mod ? ' · ' + dFmtDate(e.mod) : ''}</small><small class="drp">${esc(e.rp)}</small>${pr}</div></a>${e.b ? `<button class="ib soft" data-act="open-book" data-id="${e.b.id}" aria-label="Details">${ic('right', 18)}</button>` : ''}</div>`;
  },
  items2html(list, limit) {
    const rows = ST.libview === 'list';
    const one = l => rows ? `<div class="drows">${l.map(e => this.row(e)).join('')}</div>` : `<div class="dgrid">${l.map(e => this.card(e)).join('')}</div>`;
    if (S.lib.group) {
      const g = new Map(); list.slice(0, Math.max(limit, 400)).forEach(e => { if (!g.has(e.rp)) g.set(e.rp, []); g.get(e.rp).push(e); });
      return [...g.entries()].sort((a, b) => a[0].localeCompare(b[0])).map(([rp, l]) => `<div class="dgh"><b>${esc(rp.split('/').pop())}</b><small>${esc(rp)} · ${l.length}</small></div>${one(l)}`).join('');
    }
    return one(list.slice(0, limit)) + (list.length > limit ? `<button class="btn wide" data-act="dev-more" style="margin-top:14px">Show more (${list.length - limit})</button>` : '');
  },
  gate() {
    if (!AB) return `<section class="card gate"><div class="gico">${ic('book', 28)}</div><h3>Open your documents</h3><p>Choose PDF, EPUB, Word, text, Markdown or web files from your device.</p><button class="btn pri" data-act="add">Choose files</button></section>`;
    if (this.access === false) return `<section class="card gate"><div class="gico">${ic('search', 28)}</div><h3>Find your books automatically</h3><p>Allow file access and NerdyReader lists every PDF, EPUB, Word and text file on this phone, neatly sorted. It only looks at file names, sizes and dates. Nothing ever leaves your phone.</p><button class="btn pri big" data-act="dev-allow">Allow access</button><button class="lnk" data-act="add">Or choose files by hand</button></section>`;
    return '';
  },

  /* ---------- opening ---------- */
  async fetchFile(it) {
    const r = await fetch(location.origin + '/phone/' + this.b64(it.p + '/' + it.n));
    if (!r.ok) throw new Error('Could not read ' + it.n + '. Is access still allowed?');
    return r.blob();
  },
  async open(e) {
    if (e.b) return openReader(e.b.id);
    if (!e.it) return;
    try {
      toast('Opening “' + shortStr(e.title, 28) + '”…', 4000);
      const blob = await this.fetchFile(e.it), r = await importFile(new File([blob], e.it.n, { type: '' }));
      openReader(r.book.id);
      if (!r.dup) setTimeout(() => Quotes.ensure(), 1500);
    } catch (er) { console.warn(er); toast(er.message || 'Could not open that file', 4200); }
  },

  /* ---------- lazy covers for PDFs that are not in the library yet ---------- */
  observe() {
    const els = [...document.querySelectorAll('.dcv[data-th]')]; if (!els.length || !window.IntersectionObserver) return;
    if (!this.io) this.io = new IntersectionObserver(es => es.forEach(x => { if (x.isIntersecting) { this.io.unobserve(x.target); this.thumbFor(x.target.dataset.th, x.target); } }), { rootMargin: '240px' });
    els.forEach(el => this.io.observe(el));
  },
  async thumbFor(k, el) {
    let d = this.thumbs.get(k) || null;
    if (!d) { try { const r = await DB.getThumb(k); d = r && r.d; } catch (e) { } }
    if (!d) d = await new Promise(res => { this.tq.push({ k, res }); this.pump(); });
    if (d) { this.thumbs.set(k, d); if (el.isConnected) { el.classList.remove('gen'); el.removeAttribute('data-th'); el.removeAttribute('style'); el.innerHTML = `<img src="${d}" alt=""><span class="dcx">PDF</span>`; } }
  },
  async pump() {
    if (this.busyThumb >= 1 || !this.tq.length) return;
    const t = this.tq.shift(); this.busyThumb++;
    try { t.res(await this.makeThumb(t.k)); } catch (e) { t.res(null); }
    this.busyThumb--; setTimeout(() => this.pump(), 40);
  },
  async makeThumb(k) {
    const e = this.map.get(k); if (!e || !e.it || e.it.s > 45 * 1048576 || (typeof RD !== 'undefined' && RD)) return null;
    const blob = await this.fetchFile(e.it), pdf = await pdfjsLib.getDocument({ data: new Uint8Array(await blob.arrayBuffer()) }).promise;
    try {
      const pg = await pdf.getPage(1), v0 = pg.getViewport({ scale: 1 }), vp = pg.getViewport({ scale: 260 / v0.width });
      const cv = document.createElement('canvas'); cv.width = Math.round(vp.width); cv.height = Math.round(vp.height);
      await pg.render({ canvasContext: cv.getContext('2d'), viewport: vp, background: '#ffffff' }).promise;
      const d = cv.toDataURL('image/jpeg', 0.72); try { await DB.putThumb(k, d); } catch (er) { } return d;
    } finally { try { pdf.destroy(); } catch (er) { } }
  },
};
NATIVE.scan = ev => Dev.onBatch(ev.items || []);
NATIVE.scandone = () => Dev.onDone();

/* ================= the Library screen ================= */
function vLibrary() {
  const L = S.lib, all = Dev.entries(), { list, counts } = Dev.view(all);
  const folders = new Set(all.map(e => e.rp)).size;
  const C = (v, t) => `<button class="pl2 sm ${L.f === v ? 'on' : ''}" data-act="dev-f" data-v="${v}">${t}${counts[v] ? `<em>${counts[v]}</em>` : ''}</button>`;
  return `<h1 class="pgt">Documents</h1><p class="sub" id="dstat">${Dev.statText()}</p>
  ${Dev.gate()}
  <label class="hsearch">${ic('search', 19)}<input id="dq" type="search" value="${esc(L.q)}" placeholder="Search by name, folder or author" autocomplete="off"></label>
  <div class="pstrip fl">${C('all', 'All')}${C('recent', 'Recent')}${C('pdf', 'PDF')}${C('epub', 'EPUB')}${C('docx', 'Word')}${C('txt', 'Text')}${C('web', 'Web')}${C('saved', 'Saved')}${C('done', 'Finished')}</div>
  <div class="dtool"><label class="sel">${ic('sort', 18)}<select id="dsort">${SORTS.map(([v, t]) => `<option value="${v}" ${L.sort === v ? 'selected' : ''}>${t}</option>`).join('')}</select>${ic('down', 16)}</label>
    <button class="pl2 sm ${L.folder ? 'on' : ''}" data-act="dev-folders">${ic('folder', 16)}<span>${L.folder ? esc(shortStr(L.folder.split('/').pop(), 14)) : 'Folders'}</span></button>
    <span class="grow"></span>
    <button class="ib soft ${L.group ? 'on' : ''}" data-act="dev-group" aria-label="Group by folder">${ic('layers', 18)}</button>
    <button class="ib soft" data-act="lib-view" aria-label="Grid or list">${ic(ST.libview === 'list' ? 'grid' : 'gridv', 18)}</button></div>
  <div id="dlist">${DevList(list, folders)}</div>`;
}
function DevList(list, folders) {
  if (!list.length) return `<div class="card empty"><p>${Dev.items.length || bookList().length ? 'Nothing matches these filters.' : Dev.access ? (Dev.scanning ? 'Looking for documents…' : 'No documents found yet.') : 'No documents yet.'}</p>${Dev.access ? `<button class="btn" data-act="dev-scan">${ic('refresh', 15)} Scan again</button>` : ''}</div>`;
  return `<div class="cnt" style="margin:2px 2px 10px">${list.length} file${list.length === 1 ? '' : 's'}</div>` + Dev.items2html(list, S.lib.n);
}
function searchResults(q) {
  q = q.trim();
  if (!q) return `<div class="card empty"><p>Type a title, author, file or folder name.</p></div>`;
  const w = q.toLowerCase().split(/\s+/), all = Dev.entries().filter(e => w.every(x => (e.title + ' ' + (e.it ? e.it.n : '') + ' ' + e.rp + ' ' + ((e.b && e.b.author) || '')).toLowerCase().includes(x)));
  return all.length ? `<div class="cnt" style="margin:6px 2px">${all.length} result${all.length === 1 ? '' : 's'}</div><div class="drows">${all.sort((a, b) => b.mod - a.mod).slice(0, 80).map(e => Dev.row(e)).join('')}</div>` : `<div class="card empty"><p>No document matches “${esc(q)}”.</p></div>`;
}

/* ---- actions ---- */
ACT['dev-open'] = el => { const e = Dev.map.get(el.dataset.k); if (e) Dev.open(e); };
ACT['dev-scan'] = () => { if (!AB) return pickFiles(); if (!Dev.check()) return ACT['dev-allow'](); toast('Scanning this phone…', 1800); Dev.scan(true); };
ACT['dev-allow'] = () => { if (AB && AB.requestFilesAccess) { toast('Turn on “Allow access to all files”, then come back', 4200); AB.requestFilesAccess(); } };
ACT['dev-f'] = el => { S.lib.f = el.dataset.v; S.lib.n = 60; const sc = $('#main').scrollTop; render(); $('#main').scrollTop = sc; };
ACT['dev-more'] = () => { S.lib.n += 60; const sc = $('#main').scrollTop; render(); $('#main').scrollTop = sc; };
ACT['dev-group'] = () => { S.lib.group = !S.lib.group; render(); };
ACT['dev-folders'] = () => {
  const c = new Map(); Dev.entries().forEach(e => c.set(e.rp, (c.get(e.rp) || 0) + 1));
  const rows = [...c.entries()].sort((a, b) => b[1] - a[1] || a[0].localeCompare(b[0]));
  Sheet.open(`<button class="frow ${S.lib.folder ? '' : 'on'}" data-act="dev-folder" data-v="">${ic('folder', 18)}<div><b>All folders</b><small>${rows.length} folders</small></div></button>${rows.map(([rp, n]) => `<button class="frow ${S.lib.folder === rp ? 'on' : ''}" data-act="dev-folder" data-v="${esc(rp)}">${ic('folder', 18)}<div><b>${esc(rp.split('/').pop())}</b><small>${esc(rp)}</small></div><em>${n}</em></button>`).join('')}`, { title: 'Folders' });
};
ACT['dev-folder'] = el => { S.lib.folder = el.dataset.v; S.lib.n = 60; Sheet.close(); render(); };
document.addEventListener('input', e => {
  if (e.target.id !== 'dq') return;
  S.lib.q = e.target.value; S.lib.n = 60;
  const { list, counts } = Dev.view(Dev.entries());
  $('#dlist').innerHTML = DevList(list); Dev.observe();
  $$('.pstrip.fl .pl2').forEach(b => { const v = b.dataset.v, em = b.querySelector('em'); if (em) em.textContent = counts[v] || ''; });
});
document.addEventListener('change', e => { if (e.target.id === 'dsort') { S.lib.sort = e.target.value; render(); } });
