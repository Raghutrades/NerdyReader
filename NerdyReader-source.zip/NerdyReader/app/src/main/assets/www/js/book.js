'use strict';
/* ===== NerdyReader · Book view =====
   Reads like a real book: two pages side by side (one page on a narrow screen), pages that turn
   with a swish, and an "all pages" grid to jump anywhere.
   Works for both engines:
     - PDF original pages   (each PDF page is one book page; page 1 sits alone on the right like a cover)
     - text books (EPUB, TXT, MD, HTML, DOCX, PDF text mode): a chapter is cut into real pages with CSS columns
   Turning: tap the left / right edge, swipe, or drag the corner of the page. Tap the middle for the bars.
   Pinch in (two fingers) opens the page overview. */

/* ---------- the sound of a page ---------- */
const FlipSound = {
  ctx: null, buf: null,
  ready() {
    if (this.ctx) return true;
    const AC = window.AudioContext || window.webkitAudioContext; if (!AC) return false;
    const c = this.ctx = new AC(), len = c.sampleRate * 1;
    this.buf = c.createBuffer(1, len, c.sampleRate);
    const d = this.buf.getChannelData(0); let last = 0;
    for (let i = 0; i < len; i++) { const w = Math.random() * 2 - 1; last = 0.55 * last + 0.45 * w; d[i] = last; }   // softened noise: paper, not static
    return true;
  },
  /* dur: seconds the turn takes; fast turns sound shorter and a bit brighter */
  play(dur = 0.5, vol = 0.9) {
    if (ST.flipsnd === false || !this.ready()) return;
    const c = this.ctx; try { if (c.state !== 'running') c.resume(); } catch (e) { }
    const t = c.currentTime + 0.01, d = clamp(dur * 0.9, 0.18, 0.7);
    // the swish: noise through a filter that sweeps upward as the page lifts
    const src = c.createBufferSource(); src.buffer = this.buf; src.playbackRate.value = rnd(0.9, 1.15);
    const hp = c.createBiquadFilter(); hp.type = 'highpass'; hp.frequency.value = 700;
    const bp = c.createBiquadFilter(); bp.type = 'bandpass'; bp.Q.value = 0.7;
    bp.frequency.setValueAtTime(1300, t); bp.frequency.exponentialRampToValueAtTime(3600, t + d * 0.65); bp.frequency.exponentialRampToValueAtTime(1800, t + d);
    const g = c.createGain();
    g.gain.setValueAtTime(0.0001, t);
    g.gain.linearRampToValueAtTime(0.5 * vol, t + d * 0.28);
    g.gain.exponentialRampToValueAtTime(0.0001, t + d);
    src.connect(hp); hp.connect(bp); bp.connect(g); g.connect(c.destination);
    src.start(t, rnd(0, 0.5)); src.stop(t + d + 0.05);
    // the soft landing "fup" when the page settles
    const s2 = c.createBufferSource(); s2.buffer = this.buf;
    const lp = c.createBiquadFilter(); lp.type = 'lowpass'; lp.frequency.value = 1500;
    const g2 = c.createGain(), t2 = t + d * 0.86;
    g2.gain.setValueAtTime(0.0001, t2); g2.gain.linearRampToValueAtTime(0.32 * vol, t2 + 0.012); g2.gain.exponentialRampToValueAtTime(0.0001, t2 + 0.13);
    s2.connect(lp); lp.connect(g2); g2.connect(c.destination); s2.start(t2, rnd(0, 0.6)); s2.stop(t2 + 0.16);
  },
};

const ease = t => t < 0.5 ? 4 * t * t * t : 1 - Math.pow(-2 * t + 2, 3) / 2;
const mk = (cls, tag = 'div') => { const e = document.createElement(tag); if (cls) e.className = cls; return e; };

const Book = {
  on: false, L: null, lk: '', cache: new Map(), pdfCache: new Map(), pdfJobs: new Map(),
  cur: { ch: 0, s: 0 }, src: null, busy: false, drag: null, tok: 0,
  get slow() { return { slow: 1.6, normal: 1, fast: 0.62 }[ST.animspd] || 1; },
  zoom: { z: 1, tx: 0, ty: 0 }, pinching: false, curlC: { y: 0 }, _hires: false,
  els: null,

  /* ================= layout ================= */
  layout() {
    const body = $('#rbody'), Ws = body.clientWidth, Hs = body.clientHeight;
    const W = Ws - 20, H = Hs - 26, isPdf = RD.kind === 'pages';
    const two = ST.spread === '2' || (ST.spread !== '1' && Ws >= 560 && Ws >= Hs * 1.1);
    let pw, ph;
    if (isPdf) { const r = RD.vp1.width / RD.vp1.height; ph = Math.min(H, (two ? W / 2 : W) / r); pw = ph * r; }
    else { pw = two ? W / 2 : W; ph = H; }
    pw = Math.floor(pw); ph = Math.floor(ph);
    const k = { snug: 0.05, normal: 0.075, roomy: 0.105 }[ST.mg] || 0.075;
    const pad = isPdf ? 0 : clamp(Math.round(pw * k), 10, 44), padY = isPdf ? 0 : clamp(Math.round(ph * 0.055), 10, 30), numH = isPdf ? 0 : 20;
    const L = { two, isPdf, pw, ph, pad, padY, numH, tw: pw - 2 * pad, th: ph - 2 * padY - numH, gap: 2 * pad, lead: two ? 1 : 0, W: two ? pw * 2 : pw };
    this.lk = [L.pw, L.ph, ST.bsize, ST.font, ST.lh, ST.mg, ST.ta, two, ST.cover !== false].join('|');
    return L;
  },
  facesAt(src, s) {          // which page indexes are shown on spread s: {l, r}
    const L = this.L;
    if (!L.two) return { l: null, r: s };
    if (ST.cover === false) return { l: s * 2, r: s * 2 + 1 };           // pages paired from the very first one
    return { l: s * 2 - 1 >= 0 ? s * 2 - 1 : null, r: s * 2 };           // first page alone on the right, like a cover
  },
  spreadsOf(src) { return this.L.two ? Math.ceil((src.n + (ST.cover === false ? 0 : 1)) / 2) : src.n; },
  spreadOfPage(i) { return this.L.two ? Math.floor((i + (ST.cover === false ? 0 : 1)) / 2) : i; },
  firstPage(src, s) { const f = this.facesAt(src, s); return f.l != null ? f.l : f.r; },

  /* ================= sources ================= */
  async source(ch) {
    if (RD.kind === 'pages') return this.src && this.src.kind === 'pdf' ? this.src : (this.src = { kind: 'pdf', n: RD.np, ch: 0 });
    let c = this.cache.get(ch);
    if (c && c.key === this.lk) return c;
    const L = this.L, tok = this.tok;
    const { html } = await RD.P.load(ch);
    if (tok !== this.tok) throw new Error('stale');
    const probe = mk('bkc'); probe.innerHTML = html; Hl.apply(probe, ch);
    Object.assign(probe.style, { width: L.tw + 'px', height: L.th + 'px', columnWidth: L.tw + 'px', columnGap: L.gap + 'px' });
    const host = $('#bkmeasure'); host.appendChild(probe);
    const imgs = [...probe.querySelectorAll('img')];
    if (imgs.length) await Promise.race([Promise.all(imgs.map(m => m.decode().catch(() => { }))), sleep(800)]);
    try { await document.fonts.ready; } catch (e) { }
    const total = probe.scrollWidth, n = Math.max(1, Math.round((total + L.gap) / (L.tw + L.gap)));
    probe.remove();
    c = { kind: 'chap', ch, n, tpl: probe, key: this.lk };
    this.cache.set(ch, c);
    if (this.cache.size > 4) { const k = [...this.cache.keys()].find(x => Math.abs(x - ch) > 1); if (k != null) this.cache.delete(k); }
    return c;
  },
  /* pdf page bitmaps, cached so that turning is instant */
  pdfBmp(i) {
    const key = i + '@' + this.L.pw;
    const hit = this.pdfCache.get(key);
    if (hit) { this.pdfCache.delete(key); this.pdfCache.set(key, hit); return Promise.resolve(hit); }
    if (this.pdfJobs.has(key)) return this.pdfJobs.get(key);
    const s = RD, L = this.L;
    const job = (async () => {
      const page = await s.pdf.getPage(i + 1);
      const q = Math.min(window.devicePixelRatio || 1, 2.2), scale = L.pw / s.vp1.width * q;
      const vp = page.getViewport({ scale });
      const cv = document.createElement('canvas'); cv.width = Math.floor(vp.width); cv.height = Math.floor(vp.height);
      await page.render({ canvasContext: cv.getContext('2d'), viewport: vp, background: '#ffffff' }).promise;
      page.cleanup();
      this.pdfCache.set(key, cv);
      if (this.pdfCache.size > 14) this.pdfCache.delete(this.pdfCache.keys().next().value);
      this.pdfJobs.delete(key);
      return cv;
    })().catch(e => { this.pdfJobs.delete(key); throw e; });
    this.pdfJobs.set(key, job);
    return job;
  },

  /* ================= building pages ================= */
  /* put page i of src into a .bkpage element */
  fill(el, src, i, side) {
    const L = this.L;
    el.replaceChildren(); el.classList.remove('blank'); el.dataset.p = '';
    if (i == null || i < 0 || i >= src.n) { el.classList.add('blank'); return Promise.resolve(); }
    el.dataset.p = i + 1;
    if (src.kind === 'pdf') {
      const cv = document.createElement('canvas'); el.appendChild(cv); el.classList.add('bkpdf');
      Ann.attach(el, i + 1, L.pw, L.ph, this.zoom.z > 1.05 ? this.zoom.z : 1);
      cv.width = Math.floor(L.pw * (window.devicePixelRatio > 1 ? 1.5 : 1)); cv.height = Math.floor(L.ph * (window.devicePixelRatio > 1 ? 1.5 : 1));
      return this.pdfBmp(i).then(bm => {
        if (el.dataset.p !== String(i + 1)) return;
        const g = cv.getContext('2d'), ar = bm.width / bm.height, car = cv.width / cv.height;
        let dw = cv.width, dh = cv.height; if (ar > car) dh = dw / ar; else dw = dh * ar;
        g.fillStyle = '#fff'; g.fillRect(0, 0, cv.width, cv.height); g.imageSmoothingQuality = 'high';
        g.drawImage(bm, 0, 0, bm.width, bm.height, (cv.width - dw) / 2, (cv.height - dh) / 2, dw, dh);
      }).catch(() => { });
    }
    el.classList.remove('bkpdf');
    el.style.padding = `${L.padY}px ${L.pad}px 0`;
    const win = mk('bkwin'); win.style.width = L.tw + 'px'; win.style.height = L.th + 'px';
    const c = src.tpl.cloneNode(true); c.style.transform = `translateX(${-i * (L.tw + L.gap)}px)`;
    win.appendChild(c); el.appendChild(win);
    const pn = mk('bkpn ' + side, 'span'); pn.textContent = i + 1; el.appendChild(pn);
    return Promise.resolve();
  },
  pageEl(side) { const e = mk('bkpage ' + side); e.style.width = this.L.pw + 'px'; e.style.height = this.L.ph + 'px'; return e; },

  build() {
    const L = this.L, stage = $('#bkstage'); stage.replaceChildren();
    const bk = mk('bk' + (L.two ? ' two' : ' one')); bk.style.width = L.W + 'px'; bk.style.height = L.ph + 'px';
    const pl = L.two ? this.pageEl('l') : null, pr = this.pageEl('r');
    if (pl) { pl.style.left = '0'; bk.appendChild(pl); }
    pr.style.left = (L.two ? L.pw : 0) + 'px'; bk.appendChild(pr);
    const castL = mk('bkcast cl'), castR = mk('bkcast cr');
    if (L.two) { castL.style.cssText = `left:0;width:${L.pw}px;height:${L.ph}px`; bk.appendChild(castL); }
    castR.style.cssText = `left:${L.two ? L.pw : 0}px;width:${L.pw}px;height:${L.ph}px`; bk.appendChild(castR);
    const leaf = mk('bkleaf'); leaf.style.cssText = `left:${L.two ? L.pw : 0}px;width:${L.pw}px;height:${L.ph}px;display:none`;
    const ff = this.pageEl('r face front'), fb = this.pageEl('l face back');
    ff.style.left = '0'; fb.style.left = '0';
    const shF = mk('shade'), shB = mk('shade'); ff.appendChild(shF); fb.appendChild(shB);
    leaf.append(ff, fb); bk.appendChild(leaf);
    stage.appendChild(bk);
    const curl = Curl.build(bk, L);
    this.els = { bk, pl, pr, leaf, ff, fb, shF, shB, castL, castR, curl };
  },

  /* ================= showing a spread ================= */
  async paint(src, s) {
    const e = this.els, f = this.facesAt(src, s), ps = [];
    if (e.pl) ps.push(this.fill(e.pl, src, f.l, 'l'));
    ps.push(this.fill(e.pr, src, f.r, 'r'));
    await Promise.all(ps);
  },
  async show(ch, s, animateIn) {
    const src = await this.source(ch), tok = this.tok;
    s = clamp(s, 0, this.spreadsOf(src) - 1);
    this.src = src; this.cur = { ch, s };
    await this.paint(src, s);
    if (tok !== this.tok) return;
    if (animateIn) { this.els.bk.classList.remove('fadein'); void this.els.bk.offsetWidth; this.els.bk.classList.add('fadein'); }
    this.update();
    this.prefetch();
  },
  async prefetch() {
    const tok = this.tok, { ch, s } = this.cur, src = this.src;
    try {
      if (src.kind === 'pdf') {
        for (const d of [1, -1, 2]) {
          const t = s + d; if (t < 0 || t >= this.spreadsOf(src)) continue;
          const f = this.facesAt(src, t); for (const p of [f.l, f.r]) if (p != null && p < src.n) await this.pdfBmp(p);
          if (tok !== this.tok) return;
        }
      } else if (s >= this.spreadsOf(src) - 2 && ch + 1 < RD.n) await this.source(ch + 1);
      else if (s <= 1 && ch > 0) await this.source(ch - 1);
    } catch (e) { }
  },

  /* progress, labels, bookmarks */
  update() {
    const { ch, s } = this.cur, src = this.src, L = this.L, f = this.facesAt(src, s);
    const first = f.l != null ? f.l : f.r, last = f.r != null && f.r < src.n ? f.r : f.l;
    const lab = first === last || last == null ? `${first + 1}` : `${first + 1}–${last + 1}`;
    let prog, pos;
    if (src.kind === 'pdf') {
      RD.page = first + 1; RD.pr = 0;
      const atEnd = last != null && last >= src.n - 1;
      prog = atEnd ? 1 : first / src.n; pos = { page: first + 1, r: 0 };
      $('#rpos').textContent = `Page ${lab} of ${src.n}`;
      const left = Math.max(0, src.n - 1 - (last == null ? first : last));
      $('#rmeta').textContent = `${Math.round(prog * 100)}% read · ${left} page${left === 1 ? '' : 's'} left · tap here for all pages`;
    } else {
      const r = first / src.n; RD.ch = ch; RD.r = r;
      const c = RD.P.chapters[ch], total = rdTotalWords();
      const atEnd = ch === RD.n - 1 && last != null && last >= src.n - 1;
      prog = atEnd ? 1 : (rdWeightBefore(ch) + r * c.words) / total; pos = { ch, r };
      const left = Math.max(0, Math.ceil(total * (1 - prog) / WPM));
      $('#rpos').textContent = (RD.b.format === 'pdf' ? c.title : `Chapter ${ch + 1} of ${RD.n}`) + ` · page ${lab} of ${src.n}`;
      $('#rmeta').textContent = `${Math.round(prog * 100)}% read · ${atEnd ? 'finished' : left + ' min left'} · tap here for all pages`;
    }
    rdMark(pos, prog);
    $('#rbm').classList.toggle('on', !!rdFindMark());
    const shown = [f.l, f.r].filter(x => x != null && x < src.n);
    Track.page(src.kind === 'pdf' ? shown.map(i => 'p' + (i + 1)) : shown.map(i => 'c' + ch + ':' + i));
    Track.deco();
  },

  /* ================= turning pages ================= */
  async target(dir) {            // where does a turn in this direction land? null = there is nothing further
    const { ch, s } = this.cur, src = this.src, last = this.spreadsOf(src) - 1;
    if (dir > 0) {
      if (s < last) return { src, ch, s: s + 1 };
      if (RD.kind === 'reflow' && ch + 1 < RD.n) { const n = await this.source(ch + 1); return { src: n, ch: ch + 1, s: 0 }; }
      return null;
    }
    if (s > 0) return { src, ch, s: s - 1 };
    if (RD.kind === 'reflow' && ch > 0) { const p = await this.source(ch - 1); return { src: p, ch: ch - 1, s: this.spreadsOf(p) - 1 }; }
    return null;
  },
  /* fill leaf and the pages under it for a turn; returns when everything is drawn */
  async prep(dir, tgt) {
    const e = this.els, L = this.L, cs = this.src, cf = this.facesAt(cs, this.cur.s), tf = this.facesAt(tgt.src, tgt.s), ps = [];
    if (L.two) {
      if (dir > 0) {      // static left stays, static right becomes the new right; leaf = old right (front) / new left (back)
        ps.push(this.fill(e.pr, tgt.src, tf.r, 'r'), this.fill(e.ff, cs, cf.r, 'r'), this.fill(e.fb, tgt.src, tf.l, 'l'));
      } else {            // static left becomes the new left; leaf = new right (front) / old left (back)
        ps.push(this.fill(e.pl, tgt.src, tf.l, 'l'), this.fill(e.ff, tgt.src, tf.r, 'r'), this.fill(e.fb, cs, cf.l, 'l'));
      }
    } else if (dir > 0) ps.push(this.fill(e.pr, tgt.src, tf.r, 'r'), this.fill(e.ff, cs, cf.r, 'r'), this.fill(e.fb, null, null, 'l'));
    else ps.push(this.fill(e.pr, cs, cf.r, 'r'), this.fill(e.ff, tgt.src, tf.r, 'r'), this.fill(e.fb, null, null, 'l'));
    await Promise.all(ps);
    if (this.mode() === 'curl') {          // the turning leaf is drawn by the curl layers
      Curl.mount(e); e.leaf.style.display = 'none'; e.curl.cu.style.display = 'block'; Curl.flat(e);
    } else {                                // classic flip: the shade overlays were wiped by fill(), put them back
      e.leaf.append(e.ff, e.fb);
      e.shF = mk('shade'); e.shB = mk('shade'); e.ff.appendChild(e.shF); e.fb.appendChild(e.shB);
      e.leaf.style.display = 'block'; e.curl.cu.style.display = 'none';
    }
  },
  mode() { return ['curl', 'flip', 'fade', 'none'].includes(ST.anim) ? ST.anim : 'curl'; },
  curlCorner(y) {                           // which corner lifts: 0 = top, page height = bottom
    const c = ST.curlcorner, H = this.L.ph;
    if (c === 'top') return 0; if (c === 'bottom' || y == null) return H;
    const r = $('#rbook').getBoundingClientRect();
    return (y - ((r.height - H) / 2 + r.top)) < H * 0.4 ? 0 : H;
  },
  curlPoint(P) {
    const L = this.L, W = L.pw, H = L.ph, cy = this.curlC.y;
    P = Curl.limit(P, W, H, cy);
    const p = Curl.pOf(P, W);
    Curl.set(this.els, L, P, [W, cy], !L.two ? clamp((1 - p) / 0.35, 0, 1) : 1, ST.curlfx !== false);
    return { P, p };
  },
  curlSet(p, off) {                         // p: 0 = flat on the right ... 1 = turned over to the left
    const L = this.L; let P = Curl.arcPoint(p, L.pw, L.ph, this.curlC.y);
    if (off) P = [P[0] + off[0], P[1] + off[1]];
    return this.curlPoint(P);
  },
  curlAnim(p0, p1, ms, off) {
    return new Promise(res => {
      const t0 = performance.now(); ms *= this.slow;
      const step = now => {
        const t = clamp((now - t0) / ms, 0, 1), p = p0 + (p1 - p0) * ease(t);
        this.curlSet(p, off ? [off[0] * (1 - t), off[1] * (1 - t)] : null);
        t < 1 ? requestAnimationFrame(step) : res();
      };
      requestAnimationFrame(step);
    });
  },
  setAngle(a) {                  // a: 0 (flat on the right) ... -180 (flat on the left)
    const e = this.els, s = Math.sin(Math.abs(a) * Math.PI / 180), overRight = a > -90;
    e.leaf.style.transform = `rotateY(${a}deg)`;
    e.shF.style.opacity = overRight ? (s * 0.34).toFixed(3) : 0;
    e.shB.style.opacity = overRight ? 0 : (s * 0.34).toFixed(3);
    e.castR.style.opacity = overRight ? (s * 0.32).toFixed(3) : 0;      // the page under the lifting leaf gets a soft shadow
    e.castL.style.opacity = overRight ? 0 : (s * 0.32).toFixed(3);
  },
  animate(from, to, ms) {
    return new Promise(res => {
      const t0 = performance.now(); ms *= this.slow;
      const step = now => {
        const p = clamp((now - t0) / ms, 0, 1);
        this.setAngle(from + (to - from) * ease(p));
        p < 1 ? requestAnimationFrame(step) : res();
      };
      requestAnimationFrame(step);
    });
  },
  async commit(dir, tgt) {        // after the leaf landed: make the target the real, flat spread
    this.els.leaf.style.display = 'none'; Curl.hide(this.els);
    this.els.castL.style.opacity = 0; this.els.castR.style.opacity = 0;
    this.src = tgt.src; this.cur = { ch: tgt.ch, s: tgt.s };
    await this.paint(tgt.src, tgt.s);
    this.update(); this.prefetch();
  },
  async restore() {               // a turn that was cancelled: put the old spread back
    this.els.leaf.style.display = 'none'; Curl.hide(this.els);
    this.els.castL.style.opacity = 0; this.els.castR.style.opacity = 0;
    await this.paint(this.src, this.cur.s);
  },
  async turn(dir) {               // tap / button / key
    if (this.busy || !this.on) return;
    if (this.zoom.z > 1.001) this.zReset(true);
    this.busy = true; const tok = this.tok;
    try {
      const tgt = await this.target(dir);
      if (!tgt) { this.bump(dir); return; }
      this._dir = dir;
      const m = this.mode();
      if (m === 'none' || m === 'fade') {
        FlipSound.play(0.32, 0.8);
        this.src = tgt.src; this.cur = { ch: tgt.ch, s: tgt.s };
        await this.paint(tgt.src, tgt.s);
        if (tok !== this.tok) return;
        if (m === 'fade') { const b = this.els.bk; b.classList.remove('fadein'); void b.offsetWidth; b.classList.add('fadein'); }
        this.update(); this.prefetch(); return;
      }
      await this.prep(dir, tgt);
      if (tok !== this.tok) return;
      const ms = m === 'curl' ? 780 : 640;
      FlipSound.play(ms * this.slow / 1000);
      if (m === 'curl') {
        this.curlC = { y: this.curlCorner() };
        const p0 = dir > 0 ? 0 : 1, p1 = dir > 0 ? 1 : 0;
        this.curlSet(p0);
        await this.curlAnim(p0, p1, ms);
      } else dir > 0 ? await this.animate(0, -180, ms) : await this.animate(-180, 0, ms);
      if (tok !== this.tok) return;
      await this.commit(dir, tgt);
    } catch (e) { if (e.message !== 'stale') console.warn(e); }
    finally { this.busy = false; }
  },
  bump(dir) {
    const b = this.els.bk; b.classList.remove('bump', 'bumpl'); void b.offsetWidth; b.classList.add(dir > 0 ? 'bump' : 'bumpl');
    toast(dir > 0 ? 'That is the last page' : 'This is the first page', 1500);
  },

  /* ----- dragging a page with the finger ----- */
  async dragStart(dir, x0, y0) {
    const m = this.mode();
    if (m === 'none' || m === 'fade' || this.busy) return false;
    this.busy = true; const tok = this.tok;
    try {
      const tgt = await this.target(dir);
      if (!tgt) { this.busy = false; this.bump(dir); return false; }
      this.drag = { dir, tgt, p: 0, ready: false, x0, y0 }; this._dir = dir;
      await this.prep(dir, tgt);
      if (tok !== this.tok) return false;
      this.drag.ready = true;
      if (m === 'curl') {
        const W = this.L.pw, cy = this.curlCorner(y0); this.curlC = { y: cy };
        this.drag.cy = cy; this.drag.base = dir > 0 ? [W, cy] : [-W, cy];
        const r = this.curlPoint(this.drag.base); this.drag.P = r.P; this.drag.p = r.p;
      } else this.setAngle(dir > 0 ? -0.01 : -179.99);
      return true;
    } catch (e) { this.busy = false; this.drag = null; return false; }
  },
  dragMove(x, y) {
    const d = this.drag; if (!d || !d.ready) return;
    if (this.mode() === 'curl') {          // the corner follows the finger
      const r = this.curlPoint([d.base[0] + (x - d.x0), d.base[1] + (y - d.y0)]);
      d.P = r.P; d.p = r.p; return;
    }
    const dx = x - d.x0, p = clamp(Math.abs(dx) / (this.L.pw * 0.9), 0, 1);
    d.p = d.dir * dx < 0 ? p : 0;
    this.setAngle(d.dir > 0 ? -d.p * 180 : -(1 - d.p) * 180);
  },
  async dragEnd(vx) {
    const d = this.drag; if (!d) return;
    if (!d.ready) { this.drag = null; this.busy = false; return; }
    const tok = this.tok, curl = this.mode() === 'curl', p = d.p;
    let complete;
    if (curl) {
      complete = d.dir > 0 ? (p > 0.2 || (vx < -0.45 && p > 0.03)) : (p < 0.8 || (vx > 0.45 && p < 0.97));
      const goal = complete ? (d.dir > 0 ? 1 : 0) : (d.dir > 0 ? 0 : 1);
      const A = Curl.arcPoint(p, this.L.pw, this.L.ph, d.cy), off = d.P ? [d.P[0] - A[0], d.P[1] - A[1]] : null;
      const ms = 220 + 460 * Math.abs(goal - p);
      if (complete) FlipSound.play(ms * this.slow / 1000 + 0.2, 0.8);
      await this.curlAnim(p, goal, ms, off);
    } else {
      complete = p > 0.3 || (d.dir * vx < -0.45 && p > 0.04);
      const cur = d.dir > 0 ? -p * 180 : -(1 - p) * 180;
      const goal = complete ? (d.dir > 0 ? -180 : 0) : (d.dir > 0 ? 0 : -180);
      const ms = 160 + 420 * Math.abs(goal - cur) / 180;
      if (complete) FlipSound.play(ms * this.slow / 1000 + 0.2, 0.8);
      await this.animate(cur, goal, ms);
    }
    if (tok !== this.tok) return;
    this.drag = null;
    if (complete) await this.commit(d.dir, d.tgt); else await this.restore();
    this.busy = false;
  },

  /* ----- jumping ----- */
  async jump(ch, pageIdx, quiet) {         // go to page pageIdx (0-based) of chapter ch
    if (this.busy) return; this.busy = true; const tok = this.tok;
    try {
      const src = await this.source(ch);
      await this.show(ch, this.spreadOfPage(clamp(pageIdx, 0, src.n - 1)), true);
      if (!quiet) FlipSound.play(0.35, 0.7);
    } catch (e) { if (e.message !== 'stale') console.warn(e); }
    finally { if (tok === this.tok) this.busy = false; }
  },
  goPage(p1) { return this.jump(0, p1 - 1); },                         // PDF page number (1-based)
  async showChapter(ch, r = 0, frag = null) {                         // from contents / links
    const src = await this.source(ch); let pg = Math.floor(clamp(r, 0, 0.9999) * src.n);
    if (frag) {
      const host = $('#bkmeasure'), c = src.tpl.cloneNode(true); host.appendChild(c);
      const t = c.querySelector('[id="x-' + (window.CSS && CSS.escape ? CSS.escape(frag) : frag) + '"]');
      if (t) pg = clamp(Math.floor((t.getBoundingClientRect().left - c.getBoundingClientRect().left) / (this.L.tw + this.L.gap)), 0, src.n - 1);
      c.remove();
    }
    return this.jump(ch, pg);
  },

  /* ================= entering / leaving ================= */
  async enter() {
    if (!RD || this.on || !RD.kind) return;
    const s = RD; this.zoom = { z: 1, tx: 0, ty: 0 }; this.on = true; this.tok++; this.cache.clear(); this.pdfCache.clear(); this.pdfJobs.clear(); this.src = null; this.busy = false; this.drag = null;
    $('#rtext').hidden = true; $('#rpdf').hidden = true; $('#rbook').hidden = false;
    $('#reader').classList.add('bookmode');
    RD.immersive = true; $('#reader').classList.add('imm');
    $('#rbook').style.setProperty('--fs', ST.bsize + 'px');
    $('#rload').classList.remove('off'); $('#rloadt').textContent = 'Opening as a book…';
    this.L = this.layout(); this._built = this.lk; this.build(); this.bind();
    try {
      if (RD.kind === 'pages') { RD.zoom = RD.zoom || 1; await this.show(0, this.spreadOfPage(clamp((RD.page || 1) - 1, 0, RD.np - 1))); }
      else { const ch = clamp(RD.ch || 0, 0, RD.n - 1), src = await this.source(ch); await this.show(ch, this.spreadOfPage(Math.floor(clamp(RD.r || 0, 0, 0.9999) * src.n))); }
    } catch (e) { console.warn(e); }
    if (RD === s) $('#rload').classList.add('off');
  },
  async exit(quiet) {
    if (!this.on) return;
    this.on = false; this.tok++; this.busy = false; this.drag = null; this.zoom = { z: 1, tx: 0, ty: 0 };
    const zb = $('#bkzoom'); if (zb) zb.hidden = true;
    $('#rbook').hidden = true; $('#reader').classList.remove('bookmode'); this.closeGrid();
    this.cache.clear(); this.pdfCache.clear(); this.pdfJobs.clear();
    $('#bkstage').replaceChildren();
    if (!RD) return;
    RD.immersive = false; $('#reader').classList.remove('imm');
    if (RD.kind === 'pages') { $('#rpdf').hidden = false; pdfBuild(); await sleep(30); pdfScrollTo(clamp(RD.page || 1, 1, RD.np), 0); pdfUpdate(true); }
    else { $('#rtext').hidden = false; await rdShowChapter(RD.ch, RD.r || 0); }
  },
  async relayout() {              // screen turned, font changed …: build again and stay on the same page
    if (!this.on || !RD) return;
    const L = this.layout();
    if (this.lk === this._built) return;
    this._built = this.lk; this.tok++; this.busy = false; this.drag = null; this.L = L; this.zoom = { z: 1, tx: 0, ty: 0 };
    this.cache.clear(); this.pdfCache.clear(); this.pdfJobs.clear();
    $('#rbook').style.setProperty('--fs', ST.bsize + 'px');
    const keep = RD.kind === 'pages' ? { page: RD.page } : { ch: RD.ch, r: RD.r };
    this.build();
    try {
      if (RD.kind === 'pages') await this.show(0, this.spreadOfPage(clamp(keep.page - 1, 0, RD.np - 1)));
      else { const src = await this.source(keep.ch); await this.show(keep.ch, this.spreadOfPage(Math.floor(clamp(keep.r, 0, 0.9999) * src.n))); }
    } catch (e) { if (e.message !== 'stale') console.warn(e); }
  },
  reset() {                       // the reader closed: put the book view away without touching the reader
    this.on = false; this.tok++; this.busy = false; this.drag = null; this.zoom = { z: 1, tx: 0, ty: 0 };
    const zb = $('#bkzoom'); if (zb) zb.hidden = true;
    const b = $('#rbook'); if (b) b.hidden = true;
    $('#reader').classList.remove('bookmode'); this.closeGrid();
    this.cache.clear(); this.pdfCache.clear(); this.pdfJobs.clear();
    const st = $('#bkstage'); if (st) st.replaceChildren();
  },
  restyle() { clearTimeout(this._rt); this._rt = setTimeout(() => this.relayout(), 140); },

  /* ================= the "all pages" grid ================= */
  async overview() {
    if (!this.on) return;
    const g = $('#bkgrid'); g.hidden = false;
    this.ov = { ch: this.cur.ch, mode: 'pic' };
    await this.drawGrid();
  },
  closeGrid() { const g = $('#bkgrid'); if (g) g.hidden = true; if (this._thumbObs) { this._thumbObs.disconnect(); this._thumbObs = null; } },
  async drawGrid() {
    const g = $('#bkgrid'), ov = this.ov;
    let src; try { src = await this.source(ov.ch); } catch (e) { return; }
    const f = this.facesAt(this.src, this.cur.s), isCur = ov.ch === this.cur.ch ? new Set([f.l, f.r].filter(x => x != null)) : new Set();
    const first = this.firstPage(this.src, this.cur.s);
    const tiles = [];
    for (let i = 0; i < src.n; i++) {
      const cls = (isCur.has(i) ? 'cur ' : '') + ((ov.ch < this.cur.ch || (ov.ch === this.cur.ch && i < first)) ? 'read' : '');
      tiles.push(`<button class="ptile ${cls}" data-act="bk-go" data-p="${i}">${ov.mode === 'pic' && src.kind === 'pdf' ? '<canvas></canvas>' : ''}<span>${i + 1}</span></button>`);
    }
    const isPdf = src.kind === 'pdf';
    g.innerHTML = `<header class="bkg-h"><button class="rb" data-act="bk-gclose" aria-label="Close">${ic('x', 20)}</button>
      <div class="bkg-t"><b>All pages</b><small>${isPdf ? `${src.n} pages` : `Chapter ${ov.ch + 1} of ${RD.n} · ${src.n} page${src.n === 1 ? '' : 's'}`}</small></div>
      ${isPdf ? ''         : `<div class="bkg-c"><button class="rb" data-act="bk-gch" data-d="-1" ${ov.ch <= 0 ? 'disabled' : ''}>${ic('left', 20)}</button><button class="rb" data-act="bk-gch" data-d="1" ${ov.ch >= RD.n - 1 ? 'disabled' : ''}>${ic('right', 20)}</button></div>`}</header>
      ${isPdf ? '' : `<div class="bkg-s">${esc(shortStr(RD.P.chapters[ov.ch].title, 60))}</div>`}
      <div class="bkg-b"><div class="pgrid">${tiles.join('')}</div></div>`;
    const cur = g.querySelector('.ptile.cur'); if (cur) cur.scrollIntoView({ block: 'center' });
    if (ov.mode === 'pic' && isPdf) this.thumbs(g);
  },
  thumbs(g) {
    if (this._thumbObs) this._thumbObs.disconnect();
    const s = RD, obs = this._thumbObs = new IntersectionObserver(async es => {
      for (const e of es) {
        if (!e.isIntersecting) continue; const t = e.target; obs.unobserve(t);
        try {
          const i = +t.dataset.p, page = await s.pdf.getPage(i + 1), cv = t.querySelector('canvas'); if (!cv) continue;
          const vp0 = page.getViewport({ scale: 1 }), sc = 150 / vp0.width, vp = page.getViewport({ scale: sc * 1.5 });
          cv.width = vp.width; cv.height = vp.height;
          await page.render({ canvasContext: cv.getContext('2d'), viewport: vp, background: '#ffffff' }).promise; page.cleanup();
        } catch (er) { }
      }
    }, { root: g.querySelector('.bkg-b'), rootMargin: '200px' });
    g.querySelectorAll('.ptile').forEach(t => obs.observe(t));
  },

  /* ================= zoom (works with one page and with two) ================= */
  zApply(anim) {
    const e = this.els; if (!e) return; const Z = this.zoom, bk = e.bk;
    bk.style.transformOrigin = '0 0';
    bk.style.transition = anim ? 'transform .22s ease' : 'none';
    bk.style.transform = Z.z <= 1.001 ? '' : `translate(${Z.tx.toFixed(1)}px,${Z.ty.toFixed(1)}px) scale(${Z.z.toFixed(3)})`;
    const zb = $('#bkzoom');
    if (zb) { zb.hidden = Z.z <= 1.001; const b = zb.querySelector('b'); if (b) b.textContent = Math.round(Z.z * 100) + '%'; zb.classList.add('show'); clearTimeout(this._zt); this._zt = setTimeout(() => zb.classList.remove('show'), 1100); }
    const r = $('#bk-zoomr'); if (r) r.value = Math.round(Z.z * 100);
    const l = $('#bkzl'); if (l) l.textContent = 'ZOOM · ' + Math.round(Z.z * 100) + '%';
  },
  zClamp() {
    const root = $('#rbook'), RW = root.clientWidth, RH = root.clientHeight, L = this.L, Z = this.zoom;
    const bx = (RW - L.W) / 2, by = (RH - L.ph) / 2;
    const cl = (t, R, size, b) => size * Z.z <= R ? (R - size * Z.z) / 2 - b : clamp(t, R - size * Z.z - b - 24, -b + 24);
    Z.tx = cl(Z.tx, RW, L.W, bx); Z.ty = cl(Z.ty, RH, L.ph, by);
  },
  zAt(z1, cx, cy, anim) {                 // zoom to z1, keeping the point under (cx, cy) in place
    const root = $('#rbook'), r = root.getBoundingClientRect(), L = this.L, Z = this.zoom;
    const bx = (r.width - L.W) / 2, by = (r.height - L.ph) / 2, fx = cx - r.left, fy = cy - r.top;
    const lx = (fx - bx - Z.tx) / Z.z, ly = (fy - by - Z.ty) / Z.z;
    z1 = clamp(z1, 1, 5);
    Z.z = z1; Z.tx = fx - bx - z1 * lx; Z.ty = fy - by - z1 * ly;
    if (z1 <= 1.001) { Z.tx = 0; Z.ty = 0; }
    this.zClamp(); this.zApply(anim);
  },
  zReset(anim) {
    this.zoom = { z: 1, tx: 0, ty: 0 }; this.zApply(anim);
    if (this._hires && this.src) { this._hires = false; setTimeout(() => this.on && this.src && this.paint(this.src, this.cur.s), anim ? 230 : 0); }
  },
  zToggle(cx, cy) { if (this.zoom.z > 1.001) this.zReset(true); else { this.zAt(2.6, cx, cy, true); this.refine(); } },
  zCenter(z) { const r = $('#rbook').getBoundingClientRect(); this.zAt(z, r.left + r.width / 2, r.top + r.height / 2, false); },
  refine() {                              // after zooming in: draw the visible PDF pages again, sharp
    clearTimeout(this._rf);
    this._rf = setTimeout(async () => {
      const Z = this.zoom; if (!this.on || Z.z < 1.15 || !this.src || this.src.kind !== 'pdf') return;
      const s = RD, tok = this.tok, L = this.L, z = Z.z;
      for (const el of [this.els.pl, this.els.pr]) {
        if (!el || !el.dataset.p || !el.classList.contains('bkpdf')) continue;
        const i = +el.dataset.p;
        try {
          const page = await s.pdf.getPage(i);
          if (tok !== this.tok || this.zoom.z !== z || RD !== s) return;
          const v0 = page.getViewport({ scale: 1 }), ar = v0.width / v0.height;
          let w = L.pw, h = L.pw / ar; if (h > L.ph) { h = L.ph; w = h * ar; }
          let q = Math.min((window.devicePixelRatio || 1) * z, 6); if (w * h * q * q > 14e6) q = Math.sqrt(14e6 / (w * h));
          const vp = page.getViewport({ scale: (w / v0.width) * q });
          const cv = document.createElement('canvas'); cv.width = Math.floor(vp.width); cv.height = Math.floor(vp.height);
          cv.style.cssText = `position:absolute;left:${(L.pw - w) / 2}px;top:${(L.ph - h) / 2}px;width:${w}px;height:${h}px`;
          await page.render({ canvasContext: cv.getContext('2d'), viewport: vp, background: '#ffffff' }).promise; page.cleanup();
          if (tok !== this.tok || this.zoom.z !== z || el.dataset.p !== String(i)) return;
          el.replaceChildren(cv); this._hires = true; Ann.attach(el, i, L.pw, L.ph, z);
        } catch (e) { }
      }
    }, 240);
  },

  /* ================= settings block for the Aa sheet ================= */
  settingsHTML() {
    const seg = (k, opts, act) => `<div class="seg3">${opts.map(([v, t]) => `<button class="${String(ST[k]) === v ? 'on' : ''}" data-act="${act}" data-k="${k}" data-v="${v}">${t}</button>`).join('')}</div>`;
    const isBook = this.on, zp = Math.round(this.zoom.z * 100);
    return `<div class="lbl">READING VIEW</div>${seg('view', [['scroll', 'Scroll'], ['book', 'Book']], 'bk-view')}
      ${isBook ? `<div class="lbl">PAGES SHOWN</div>${seg('spread', [['auto', 'Auto'], ['2', 'Two pages'], ['1', 'One page']], 'bk-spread')}
      <div class="lbl">FIRST PAGE (TWO PAGES)</div>${seg('cover', [['true', 'Alone, like a cover'], ['false', 'Paired']], 'bk-opt')}
      <div class="lbl" id="bkzl">ZOOM · ${zp}%</div>
      <div class="slr"><button class="btn sq" data-act="bk-zstep" data-d="-0.25">${ic('minus', 18)}</button><input type="range" id="bk-zoomr" min="100" max="400" step="5" value="${zp}"><button class="btn sq" data-act="bk-zstep" data-d="0.25">${ic('plus', 18)}</button></div>
      <p class="xs mute" style="margin:6px 2px 0">Works with one page or two. You can also pinch with two fingers, or double-tap the middle of the page. Drag to move around while zoomed.</p>
      <div class="lbl">PAGE-TURN STYLE</div>${seg('anim', [['curl', 'Curl'], ['flip', 'Flip'], ['fade', 'Fade'], ['none', 'None']], 'bk-opt')}
      <div class="lbl">TURN SPEED</div>${seg('animspd', [['slow', 'Slow'], ['normal', 'Normal'], ['fast', 'Fast']], 'bk-opt')}
      <div class="lbl">CURL SHADOWS</div>${seg('curlfx', [['true', 'Realistic'], ['false', 'Light (faster)']], 'bk-opt')}
      <div class="lbl">CURL LIFTS THE</div>${seg('curlcorner', [['auto', 'Corner you touch'], ['bottom', 'Bottom'], ['top', 'Top']], 'bk-opt')}
      <div class="lbl">PAGE-TURN SOUND</div>${seg('flipsnd', [['true', 'On'], ['false', 'Off']], 'bk-snd')}
      <div class="lbl">TAP THE EDGES TO TURN</div>${seg('tapturn', [['true', 'On'], ['false', 'Off']], 'bk-opt')}
      <div class="lbl">PAPER</div>${seg('texture', [['false', 'Smooth'], ['true', 'Textured']], 'bk-opt')}
      <div class="row gap" style="margin-top:12px"><button class="btn" data-act="bk-grid">${ic('grid', 16)} All pages</button></div>` : ''}`;
  },
  bindSettings() {
    const r = $('#bk-zoomr'); if (!r) return;
    r.oninput = () => this.zCenter(+r.value / 100);
    r.onchange = () => this.refine();
  },

  bind() {
    const root = $('#rbook'); if (root._b) return; root._b = true;
    let d = null, t2 = null;
    const Zs = () => this.zoom;
    root.addEventListener('pointerdown', e => {
      if (!this.on || !e.isPrimary || e.target.closest('button') || this.ovOpen() || Ann.active()) return;
      d = { x: e.clientX, y: e.clientY, t: performance.now(), lx: e.clientX, lt: performance.now(), vx: 0, drag: false, id: e.pointerId, px: e.clientX, py: e.clientY, pan: false };
      try { root.setPointerCapture(e.pointerId); } catch (er) { }
    });
    root.addEventListener('pointermove', async e => {
      if (!d || e.pointerId !== d.id || this.pinching) return;
      const dx = e.clientX - d.x, dy = e.clientY - d.y, now = performance.now();
      d.vx = (e.clientX - d.lx) / Math.max(1, now - d.lt); d.lx = e.clientX; d.lt = now;
      if (Zs().z > 1.001) {                                   // zoomed in: one finger moves the page around
        if (Math.hypot(dx, dy) > 6) d.pan = true;
        if (d.pan) { Zs().tx += e.clientX - d.px; Zs().ty += e.clientY - d.py; this.zClamp(); this.zApply(); }
        d.px = e.clientX; d.py = e.clientY; return;
      }
      if (!d.drag && !d.starting && !d.swipe && Math.abs(dx) > 10 && Math.abs(dx) > Math.abs(dy) * 1.3) {
        const m = this.mode();
        if (m === 'none' || m === 'fade') d.swipe = dx < 0 ? 1 : -1;
        else { d.starting = true; const ok = await this.dragStart(dx < 0 ? 1 : -1, d.x, d.y); d.drag = ok; d.starting = false; d.failed = !ok; }
      }
      if (d.drag) this.dragMove(e.clientX, e.clientY);
    });
    const up = async e => {
      if (!d || e.pointerId !== d.id) return; const s = d; d = null;
      if (s.starting) { for (let i = 0; i < 40 && s.starting; i++) await sleep(25); }
      if (this.drag) { await this.dragEnd(s.vx); return; }
      if (s.pan) { this.refine(); return; }
      if (s.swipe) { if (Math.abs(e.clientX - s.x) > 36) this.turn(s.swipe); return; }
      if (s.failed) return;
      if (Math.hypot(e.clientX - s.x, e.clientY - s.y) < 10 && performance.now() - s.t < 450) this.tapAt(e);
    };
    root.addEventListener('pointerup', up);
    root.addEventListener('pointercancel', () => { if (this.drag) this.dragEnd(0); d = null; });
    // two fingers: pinch OUT zooms into the page, pinch IN (when not zoomed) shows all pages
    const dist = t => Math.hypot(t[0].clientX - t[1].clientX, t[0].clientY - t[1].clientY);
    const mid = t => [(t[0].clientX + t[1].clientX) / 2, (t[0].clientY + t[1].clientY) / 2];
    root.addEventListener('touchstart', e => {
      if (e.touches.length !== 2 || !this.on || this.ovOpen()) return;
      this.pinching = true; if (this.drag) this.dragEnd(0); d = null;
      const m = mid(e.touches), r = root.getBoundingClientRect(), L = this.L, Z = Zs();
      t2 = { d0: dist(e.touches), z0: Z.z, r, bx: (r.width - L.W) / 2, by: (r.height - L.ph) / 2, done: false, zoomed: false };
      t2.lx = (m[0] - r.left - t2.bx - Z.tx) / Z.z; t2.ly = (m[1] - r.top - t2.by - Z.ty) / Z.z;
    }, { passive: true });
    root.addEventListener('touchmove', e => {
      if (!t2 || e.touches.length !== 2 || t2.done) return;
      const ratio = dist(e.touches) / t2.d0, m = mid(e.touches), Z = Zs();
      if (t2.z0 <= 1.001 && !t2.zoomed && ratio < 0.68) { t2.done = true; this.overview(); return; }
      if (ratio > 1.04 || t2.zoomed || t2.z0 > 1.001) {
        t2.zoomed = true; const z1 = clamp(t2.z0 * ratio, 1, 5);
        Z.z = z1; Z.tx = m[0] - t2.r.left - t2.bx - z1 * t2.lx; Z.ty = m[1] - t2.r.top - t2.by - z1 * t2.ly;
        this.zClamp(); this.zApply();
      }
    }, { passive: true });
    const tend = e => {
      if (e.touches.length >= 2 || !t2) return;
      const was = t2; t2 = null; setTimeout(() => { this.pinching = false; }, 80);
      if (was.zoomed) { if (Zs().z < 1.04) this.zReset(true); else this.refine(); }
    };
    root.addEventListener('touchend', tend, { passive: true }); root.addEventListener('touchcancel', tend, { passive: true });
    document.addEventListener('keydown', e => {
      if (!this.on || this.ovOpen()) return;
      if (e.key === 'ArrowRight' || e.key === 'PageDown' || e.key === ' ') this.turn(1);
      else if (e.key === 'ArrowLeft' || e.key === 'PageUp') this.turn(-1);
      else if (e.key === '+' || e.key === '=') { this.zCenter(Zs().z + 0.25); this.refine(); }
      else if (e.key === '-') { this.zCenter(Zs().z - 0.25); this.refine(); }
    });
    let rt; window.addEventListener('resize', () => { clearTimeout(rt); rt = setTimeout(() => this.relayout(), 220); });
  },
  tapAt(e) {
    const root = $('#rbook'), r = root.getBoundingClientRect(), fx = (e.clientX - r.left) / r.width, now = performance.now();
    const zoomed = this.zoom.z > 1.001, edge = fx < 0.28 ? -1 : fx > 0.72 ? 1 : 0;
    const bars = () => { if (!RD) return; RD.immersive = !RD.immersive; $('#reader').classList.toggle('imm', RD.immersive); };
    if (edge) {
      this._tap = null; clearTimeout(this._tapTm);
      if (zoomed) return;
      return ST.tapturn !== false ? this.turn(edge) : bars();
    }
    if (ST.dict === 'tap' && !zoomed && !Ann.active()) { const y = (e.clientY - r.top) / r.height; if (y > 0.1 && y < 0.9) return Dict.at(e.clientX, e.clientY).then(h => h ? Dict.show(h.word, h.ctx) : bars()); }
    // middle: one tap = bars, two quick taps = zoom (the bars wait a moment to see which one it is)
    if (this._tap && now - this._tap.t < 320 && Math.hypot(e.clientX - this._tap.x, e.clientY - this._tap.y) < 48) {
      clearTimeout(this._tapTm); this._tap = null; return this.zToggle(e.clientX, e.clientY);
    }
    this._tap = { t: now, x: e.clientX, y: e.clientY };
    clearTimeout(this._tapTm); this._tapTm = setTimeout(() => { this._tap = null; bars(); }, 300);
  },
  ovOpen() { const g = $('#bkgrid'); return g && !g.hidden; },
};
/* ---------- actions ---------- */
ACT['bk-view'] = async el => {
  ST.view = el.dataset.v; saveST();
  $$('[data-act=bk-view]').forEach(x => x.classList.toggle('on', x.dataset.v === ST.view));
  if (!RD) return;
  Sheet.close();
  if (ST.view === 'book') await Book.enter(); else await Book.exit();
};
ACT['bk-spread'] = el => { ST.spread = el.dataset.v; saveST(); $$('[data-act=bk-spread]').forEach(x => x.classList.toggle('on', x.dataset.v === ST.spread)); Book.relayout(); };
ACT['bk-snd'] = el => { ST.flipsnd = el.dataset.v === 'true'; saveST(); $$('[data-act=bk-snd]').forEach(x => x.classList.toggle('on', x.dataset.v === String(ST.flipsnd))); if (ST.flipsnd) FlipSound.play(0.45); };
ACT['bk-opt'] = el => {
  const k = el.dataset.k, v = el.dataset.v, val = v === 'true' ? true : v === 'false' ? false : v;
  ST[k] = val; saveST();
  $$('[data-act=bk-opt]').filter(x => x.dataset.k === k).forEach(x => x.classList.toggle('on', x.dataset.v === String(val)));
  if (k === 'cover') Book.relayout();
  if (k === 'texture') applyReaderStyle();
};
ACT['bk-zstep'] = el => { Book.zCenter(Book.zoom.z + +el.dataset.d); Book.refine(); };
ACT['bk-zreset'] = () => Book.zReset(true);
ACT['bk-grid'] = () => { Sheet.close(); Book.overview(); };
ACT['bk-gclose'] = () => Book.closeGrid();
ACT['bk-gmode'] = el => { Book.ov.mode = el.dataset.v; Book.drawGrid(); };
ACT['bk-gch'] = async el => { const n = Book.ov.ch + +el.dataset.d; if (n < 0 || n >= RD.n) return; Book.ov.ch = n; await Book.drawGrid(); };
ACT['bk-go'] = el => { const ch = Book.ov.ch, p = +el.dataset.p; Book.closeGrid(); Book.jump(ch, p); };
document.addEventListener('input', e => {
  if (e.target.id === 'bk-size') { ST.bsize = +e.target.value; saveST(); const l = $('#bksl'); if (l) l.textContent = 'TEXT SIZE IN BOOK VIEW · ' + ST.bsize + ' PX'; Book.restyle(); }
});
