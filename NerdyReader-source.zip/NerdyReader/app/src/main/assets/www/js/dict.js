'use strict';
/* ===== NerdyReader · look a word up, fully offline =====
   Long-press a word (or tap it, if you switch that on) to see its meaning. The dictionary is WordNet 3.1 (Princeton University),
   stored inside the app, so nothing ever goes online.
   Words you save are kept on the phone (a small vocabulary list, in the Quotes tab). */
const WORD = /[\p{L}\p{M}'’\-]/u;
const Dict = {
  words: [], pc: new Map(), _ate: 0,
  load() { try { this.words = JSON.parse(localStorage.getItem('nr-words')) || []; } catch (e) { this.words = []; } },
  save() { try { localStorage.setItem('nr-words', JSON.stringify(this.words)); } catch (e) { } },
  clean(w) { return (w || '').replace(/^[^\p{L}]+|[^\p{L}]+$/gu, '').replace(/['’]s$/i, ''); },
  ext(url) { if (AB && AB.openUrl) AB.openUrl(url); else window.open(url, '_blank'); },

  /* ----- find the word under a point ----- */
  async at(x, y) {
    if (!RD) return null;
    const el = document.elementFromPoint(x, y);
    if (el && el.closest('#rart, .bkwin')) {                          // real text: ask the browser where the caret would be
      let r = null;
      if (document.caretRangeFromPoint) r = document.caretRangeFromPoint(x, y);
      else if (document.caretPositionFromPoint) { const c = document.caretPositionFromPoint(x, y); if (c) { r = document.createRange(); r.setStart(c.offsetNode, c.offset); } }
      if (!r || r.startContainer.nodeType !== 3) return null;
      const t = r.startContainer.nodeValue; let a = r.startOffset, z = a;
      while (a > 0 && WORD.test(t[a - 1])) a--; while (z < t.length && WORD.test(t[z])) z++;
      const w = this.clean(t.slice(a, z)); if (!w) return null;
      const par = r.startContainer.parentElement, blk = (par && par.closest('p,li,blockquote,div,h1,h2,h3')) || par;
      return { word: w, ctx: this.sentence((blk && blk.textContent) || t, w) };
    }
    const host = el && el.closest('.bkpdf[data-p], .pg[data-i]');     // PDF page: find the word in the page's text
    if (!host || !RD.pdf) return null;
    const p = +(host.dataset.p || host.dataset.i), rc = host.getBoundingClientRect();
    return this.pdfWord(p, (x - rc.left) / rc.width, (y - rc.top) / rc.height);
  },
  async pdfWord(p, nx, ny) {
    let c = this.pc.get(p);
    if (!c) {
      const page = await RD.pdf.getPage(p), vp = page.getViewport({ scale: 1 }), tc = await page.getTextContent();
      c = { vp, items: tc.items.filter(i => i.str && i.str.trim()) }; page.cleanup(); this.pc.set(p, c); if (this.pc.size > 12) this.pc.delete(this.pc.keys().next().value);
    }
    const px = nx * c.vp.width, py = ny * c.vp.height, g = (this._cv || (this._cv = document.createElement('canvas'))).getContext('2d');
    for (const it of c.items) {
      const m = pdfjsLib.Util.transform(c.vp.transform, it.transform), fh = Math.hypot(m[2], m[3]) || 10, w = it.width * c.vp.scale;
      if (px < m[4] - 2 || px > m[4] + w + 2 || py < m[5] - fh * 0.95 || py > m[5] + fh * 0.3) continue;
      g.font = fh + 'px serif'; const tot = g.measureText(it.str).width || 1, k = w / tot;
      let i = 0; while (i < it.str.length - 1 && m[4] + g.measureText(it.str.slice(0, i + 1)).width * k < px) i++;
      let a = i, z = i + 1; while (a > 0 && WORD.test(it.str[a - 1])) a--; while (z < it.str.length && WORD.test(it.str[z])) z++;
      const word = this.clean(it.str.slice(a, z)); if (!word) return null;
      return { word, ctx: this.sentence(c.items.map(x => x.str).join(' ').replace(/\s+/g, ' '), word) };
    }
    return null;
  },
  sentence(text, w) {
    text = (text || '').replace(/\s+/g, ' '); const i = text.toLowerCase().indexOf(w.toLowerCase()); if (i < 0) return text.slice(0, 160);
    let a = Math.max(text.lastIndexOf('. ', i), text.lastIndexOf('? ', i), text.lastIndexOf('! ', i)); a = a < 0 ? Math.max(0, i - 80) : a + 2;
    let z = text.slice(i).search(/[.!?]\s|$/); z = i + (z < 0 ? 0 : z) + 1; z = Math.min(z, a + 220);
    return text.slice(a, z).trim();
  },

  /* ----- the offline dictionary (WordNet 3.1, stored in the app, in one file per first letter) ----- */
  sh: {}, exc: null, PN: { n: 'noun', v: 'verb', a: 'adjective', r: 'adverb', f: 'small word' },
  async shard(c) {
    c = /[a-z]/.test(c) ? c : '_';
    if (!this.sh[c]) this.sh[c] = fetch('data/dict/' + c + '.json').then(r => r.json()).catch(() => ({}));
    return this.sh[c];
  },
  async forms(w) {                                    // the word, then the base forms it could come from (running → run, went → go)
    if (!this.exc) this.exc = await fetch('data/exc.json').then(r => r.json()).catch(() => ({ n: {}, v: {}, a: {}, r: {} }));
    const out = [w], add = x => { if (x && x.length > 1 && !out.includes(x)) out.push(x); };
    for (const p of 'nvar') if (this.exc[p][w]) add(this.exc[p][w]);
    const R = [['ies', 'y'], ['ves', 'f'], ['ves', 'fe'], ['sses', 'ss'], ['ches', 'ch'], ['shes', 'sh'], ['xes', 'x'], ['zes', 'z'], ['ses', 's'], ['s', ''], ['men', 'man'],
      ['ied', 'y'], ['ed', ''], ['ed', 'e'], ['ing', ''], ['ing', 'e'], ['er', ''], ['er', 'e'], ['est', ''], ['est', 'e'], ['ly', ''], ['ily', 'y']];
    for (const [a, b] of R) if (w.length > a.length + 1 && w.endsWith(a)) { const base = w.slice(0, -a.length) + b; add(base); if (a === 'ed' || a === 'ing' || a === 'er' || a === 'est') { const x = base; if (x.length > 2 && x[x.length - 1] === x[x.length - 2]) add(x.slice(0, -1)); } }
    return out;
  },
  async define(word) {
    const w = word.toLowerCase().replace(/’/g, "'"), found = [];
    for (const f of await this.forms(w)) {
      const s = await this.shard(f[0]);
      if (s[f] && s[f].length) { found.push({ form: f, senses: s[f] }); if (found.length === 2) break; }
    }
    if (!found.length) return null;
    // "running", "walked", "went": the verb behind the word is what people mean, so it goes first
    const base = (/(ing|ed)$/.test(w) || (this.exc && 'nvar'.split('').some(p => this.exc[p][w]))) && found.length > 1 && found[0].form === w;
    return base ? [found[1], found[0]] : found;
  },
  meaningHTML(rs, word) {
    if (!rs) return `<p class="dnone">No meaning stored for “${esc(word)}”. The built-in dictionary covers about 70,000 English words; names, slang and other languages may be missing.</p><button class="lnk" data-act="dict-go" data-u="https://www.google.com/search?q=define+${encodeURIComponent(word)}">Search online instead (opens your browser)</button>`;
    const order = /(ing|ed)$/.test(word.toLowerCase()) ? ['f', 'v', 'n', 'a', 'r'] : ['f', 'n', 'v', 'a', 'r'];
    return rs.map(r => {
      const by = {}; r.senses.forEach(x => (by[x[0]] = by[x[0]] || []).push(x));
      const head = rs.length > 1 || r.form !== word.toLowerCase() ? `<div class="dform">${r.form !== word.toLowerCase() && rs.length === 1 ? 'from ' : ''}<b>${esc(r.form)}</b></div>` : '';
      return head + order.filter(p => by[p]).map(p => `<div class="dpos">${this.PN[p]}</div><ol class="dsen">${by[p].slice(0, 5).map(x => `<li>${esc(x[1])}${x[2] ? `<em>“${esc(x[2])}”</em>` : ''}${x[3] && x[3].length ? `<small>Similar: ${x[3].map(esc).join(', ')}</small>` : ''}</li>`).join('')}</ol>`).join('');
    }).join('<hr class="dhr">');
  },

  /* ----- the meaning sheet ----- */
  show(word, ctx) {
    word = this.clean(word); if (!word) return;
    const saved = this.words.some(x => x.w.toLowerCase() === word.toLowerCase());
    this._cur = { word, ctx };
    Sheet.open(`<div class="dword"><b>${esc(word)}</b><button class="btn sm dsv" data-act="dict-save">${ic('star', 15)} ${saved ? 'Saved' : 'Save'}</button></div>
      ${ctx ? `<p class="dctx serif">“${esc(shortStr(ctx, 200))}”</p>` : ''}<div id="dmean" class="dmean"><p class="mute sm">Looking up…</p></div>`, { title: 'Meaning' });
    this.define(word).then(r => {
      if (!this._cur || this._cur.word !== word) return;
      this._cur.def = r && r[0].senses[0] ? r[0].senses[0][1] : '';
      const el = $('#dmean'); if (el) el.innerHTML = this.meaningHTML(r, word);
    });
  },
};
ACT['dict-go'] = el => Dict.ext(el.dataset.u);
ACT['dict-save'] = el => {
  const c = Dict._cur; if (!c) return;
  const i = Dict.words.findIndex(x => x.w.toLowerCase() === c.word.toLowerCase());
  if (i >= 0) { Dict.words.splice(i, 1); el.innerHTML = ic('star', 15) + ' Save'; toast('Removed from your words'); }
  else { Dict.words.unshift({ w: c.word, def: shortStr(c.def || '', 160), ctx: shortStr(c.ctx || '', 200), b: RD ? RD.b.id : '', t: RD ? RD.b.title : '', ts: Date.now() }); el.innerHTML = ic('star', 15) + ' Saved'; toast('Word saved'); }
  Dict.save();
};
ACT['dict-sel'] = () => {
  const sel = window.getSelection(), t = sel ? sel.toString().trim() : ''; if (!t) return;
  const w = t.split(/\s+/)[0], n = sel.anchorNode, blk = n && (n.nodeType === 1 ? n : n.parentElement).closest('p,li,blockquote,div');
  $('#selbar').hidden = true; Dict.show(w, Dict.sentence((blk && blk.textContent) || t, Dict.clean(w)));
};
ACT['w-look'] = el => { const w = Dict.words[+el.dataset.i]; if (w) Dict.show(w.w, w.ctx); };
ACT['w-del'] = el => { Dict.words.splice(+el.dataset.i, 1); Dict.save(); const sc = $('#main').scrollTop; render(); $('#main').scrollTop = sc; };
function vocabCard() {
  if (!Dict.words.length) return `<section class="card"><h3>Saved words</h3><p class="sm mute" style="margin:0">Long-press any word while reading, then tap <b>Save word</b>. They collect here.</p></section>`;
  return `<section class="card"><h3>Saved words <small class="mute">${Dict.words.length}</small></h3>${Dict.words.slice(0, 40).map((w, i) => `<div class="dyrow"><div style="flex:1;min-width:0"><b>${esc(w.w)}</b><small>${esc(shortStr(w.def || w.ctx || w.t || '', 110))}</small></div><button class="ib soft" data-act="w-look" data-i="${i}" aria-label="Look up">${ic('define', 17)}</button><button class="ib soft" data-act="w-del" data-i="${i}" aria-label="Delete">${ic('trash', 17)}</button></div>`).join('')}</section>`;
}
/* long-press a word */
(() => {
  let t = null, d = null;
  const stop = () => { clearTimeout(t); t = null; d = null; };
  document.addEventListener('pointerdown', e => {
    if (!RD || ST.dict !== 'press' || !e.isPrimary || Ann.active() || e.target.closest('button,a,input,#drawbar,#selbar')) return;
    if (!e.target.closest('#rbook, #rpdf')) return;                   // in the scroll view of text books, the phone's own selection is used
    d = { x: e.clientX, y: e.clientY };
    t = setTimeout(async () => { const p = d; stop(); if (!p) return; const h = await Dict.at(p.x, p.y); if (h) { if (navigator.vibrate) navigator.vibrate(12); Dict.show(h.word, h.ctx); } }, 480);
  }, true);
  document.addEventListener('pointermove', e => { if (d && Math.hypot(e.clientX - d.x, e.clientY - d.y) > 9) stop(); }, true);
  ['pointerup', 'pointercancel'].forEach(ev => document.addEventListener(ev, stop, true));
})();
