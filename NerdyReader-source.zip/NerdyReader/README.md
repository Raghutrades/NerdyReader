# NerdyReader

An offline reader for **PDF, EPUB, TXT, Markdown, HTML and Word (.docx)** files on Android, styled after the BDeBooks screens, with an About page like the one in NeuroOrbitSynapse. Personal use. No internet permission, no account, no tracking.

## Get the APK (phone only, no computer)
1. Create a GitHub repo, e.g. `NerdyReader`.
2. **Add file → Create new file**, name it `.github/workflows/build-apk.yml` (typing the slashes makes the folders) and paste the contents of that file from this project. Commit.
3. **Add file → Upload files** and upload `NerdyReader-source.zip` (the zip you downloaded, as-is). Commit.
4. Open the **Actions** tab. The *Build NerdyReader APK* run takes ~3–5 minutes.
5. Download from **Releases → NerdyReader (latest build) → NerdyReader.apk** (or the run's *Artifacts*). Open it on your phone and allow "install unknown apps" for your browser.

If you have a computer, just push the unzipped folder instead. The workflow handles both.

Every build is signed with the key in `keystore/`, so a new APK installs over the old one and **keeps your library**.

## Using it
- **Add books** (top right, or the menu) opens the system file picker. Files are copied into the app, so they open offline even if you delete the original.
- In any file manager: long-press a book → **Open with → NerdyReader** (or Share → NerdyReader).
- Reader: tap the page to hide the bars; **Aa** = size, font, spacing, Light/Sepia/Night; middle of the bottom bar = contents and bookmarks.
- PDFs open as original pages (pinch to zoom). **Aa → Read as reflowable text** reflows them with your font. Scanned PDFs have no text, so use page view.

## Make it yours
- **About page:** `app/src/main/assets/www/js/about.js` (text, skills, story, books).
- **Your photo:** add `raghu.jpg` to `app/src/main/assets/www/`.
- **Your books:** put PDFs in `app/src/main/assets/www/books/` with the names in `about.js`; *About → My books → Add to library* imports them.
- **Colours:** `css/app.css`, the `:root` block.
- **Version:** `app/build.gradle` (`versionCode`, `versionName`).

## Layout
```
app/src/main/java/.../MainActivity.java   WebView shell: file picker, Open with, bars
app/src/main/assets/www/                  the whole app (HTML, CSS, JS)
  js/parsers.js   EPUB, TXT, MD, HTML, DOCX, PDF-text
  js/reader.js    reflow reader + PDF page viewer
  js/views.js     home, library, search, shelf, book page
  lib/            pdf.js 3.11 and JSZip 3.10 (bundled, no CDN)
keystore/         fixed signing key (personal use)
```
Not supported yet: MOBI/AZW, DRM books, text-to-speech.
