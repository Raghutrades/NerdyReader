# NerdyReader

An offline reader for **PDF, EPUB, TXT, Markdown, HTML and Word (.docx)** files on Android, styled after the BDeBooks screens, with an About page like the one in NeuroOrbitSynapse. Personal use. No internet permission, no account, no tracking.

## Get the APK (phone only, no computer)
1. Create a GitHub repo, e.g. `NerdyReader`.
2. **Add file → Create new file**, name it `.github/workflows/build-apk.yml` (typing the slashes makes the folders) and paste the contents of that file from this project. Commit.
3. **Add file → Upload files** and upload `NerdyReader-source.zip` (the zip you downloaded, as-is). Commit.
4. Open the **Actions** tab. The *Build NerdyReader APK* run takes ~3–5 minutes.
5. Download from **Releases → NerdyReader (latest build) → NerdyReader.apk** (or the run's *Artifacts*). Open it on your phone and allow "install unknown apps" for your browser.

If you have a computer, just push the unzipped folder instead. The workflow handles both.

Every build is signed with the key in `keystore/`, so a new APK installs over the old one and **keeps your library**.

## Using it
- **Add books** (top right, or the menu) opens the system file picker. Files are copied into the app, so they open offline even if you delete the original.
- In any file manager: long-press a book → **Open with → NerdyReader** (or Share → NerdyReader).
- Reader: tap the page to hide the bars; **Aa** = size, font, spacing, margins, alignment and page colour; the headphones button reads aloud; middle of the bottom bar = contents and bookmarks.
- PDFs open as original pages (pinch to zoom). **Aa → Read as reflowable text** reflows them with your font. Scanned PDFs have no text, so use page view.

## New in 1.2: Book view
Reads like a real book. Open any book and it shows as an open book with **two pages side by side** (one page on a narrow screen), and pages that **turn with a swish**:
- Turn by **tapping the left or right edge**, **swiping**, or **dragging the page** with your finger. Tap the middle to show or hide the bars.
- PDFs show their **original pages** as spreads (page 1 sits alone on the right, like a cover). EPUB, Word, text and Markdown are cut into real pages.
- **Pinch in with two fingers**, or tap the page counter at the bottom, to see **all pages** as a grid of numbers (the current page is circled) or as small pictures.
- **Aa** has *Reading view* (Scroll or Book), *Pages shown* (Auto, Two, One), the *page-turn sound* and a separate text size for book view. Listening (read aloud) switches back to scroll view so it can read along.

## New in 1.1
- **Welcome animation** (a book opening, sparkles) and **calm music** made live on the phone: Calm Garden, Happy Morning, Deep Focus, Soft Rain, Sleepy Library. The music button is in the top bar.
- **Themes** under **Menu → Themes & sound**: six bright ones (Sunrise, Meadow, Ocean, Lavender, Blossom, Sunny) plus two dark ones, **Midnight** (soft dark violet) and **Black** (pure black for OLED). The reader also has Night and Black page colours.
- **Read aloud** with the phone's own voice: speed, voice, sleep timer, the current sentence is highlighted and the next chapter carries on by itself.
- **Convert** any book (PDF text, EPUB, Word, TXT, Markdown, HTML) to PDF, Word, EPUB, text, Markdown or a web page, or **save as audio** (.wav) to play anywhere. Text only, pictures are not carried over. Hindi and other non-Latin PDFs are saved as page pictures so every letter shows correctly.

## Your photo and books
Upload them to the repo **next to the zip** (repo root). The build copies them into the app:
- your photo named `raghu.jpg` (or `.png`, `.webp`) goes on the About page,
- any `.pdf` / `.epub` files go into the About page's book shelf. The names in `about.js` (for example `the-false-green.pdf`) are what its *Add to library* buttons look for. Any other book is simply added with **Add books** in the app.

## Make it yours
- **About page:** `app/src/main/assets/www/js/about.js` (text, skills, story, books).
- **Your photo:** add `raghu.jpg` to `app/src/main/assets/www/`.
- **Your books:** put PDFs in `app/src/main/assets/www/books/` with the names in `about.js`; *About → My books → Add to library* imports them.
- **Colours and themes:** `css/extra.css` (one block per theme) and `js/theme.js`.
- **Music:** `js/music.js` (the `MOODS` table at the top).
- **Version:** `app/build.gradle` (`versionCode`, `versionName`).

## Layout
```
app/src/main/java/.../MainActivity.java   WebView shell: file picker, Open with, bars, text-to-speech, Save as
app/src/main/assets/www/                  the whole app (HTML, CSS, JS)
  js/parsers.js   EPUB, TXT, MD, HTML, DOCX, PDF-text
  js/reader.js    reflow reader + PDF page viewer
  js/views.js     home, library, search, shelf, book page
  js/theme.js     themes and reading styles
  js/music.js     the generated calm music
  js/splash.js    welcome animation
  js/convert.js   book to PDF / Word / EPUB / text / Markdown / HTML
  js/listen.js    read aloud and save as audio
  lib/            pdf.js 3.11 and JSZip 3.10 (bundled, no CDN)
keystore/         fixed signing key (personal use)
```
Not supported yet: MOBI/AZW, DRM books. Audio files are .wav (large); choose only the chapters you need.
