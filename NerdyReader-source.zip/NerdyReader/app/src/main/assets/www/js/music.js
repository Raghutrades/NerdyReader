'use strict';
/* ===== NerdyReader · calm music =====
   Made live with WebAudio: soft pads, bells, plucks and rain. No audio files, so the app
   stays small, works offline, and the music never repeats exactly the same way twice.
   Everything is tuned to a gentle C-major / A-minor world, so any note sounds friendly. */

const MOODS = {
  calm:  { name: 'Calm Garden',    note: 'Warm slow pads with soft bells',        len: 12,  pad: 0.052, cut: 1100, gap: [2.2, 5.0], vel: 0.085, wet: 0.9,
           chords: [[48, 55, 59, 64], [45, 52, 55, 60], [41, 48, 52, 57], [43, 50, 55, 59, 64]], scale: [60, 62, 64, 67, 69, 72, 74, 76, 79] },
  joy:   { name: 'Happy Morning',  note: 'Bright, light and a little bouncy',      len: 6.4, pad: 0.034, cut: 1900, step: 0.4, vel: 0.07, wet: 0.7, arp: true,
           chords: [[48, 52, 55, 60], [43, 50, 55, 59], [45, 52, 57, 60], [41, 48, 53, 57]] },
  focus: { name: 'Deep Focus',     note: 'Steady and quiet, nothing to distract', len: 16,  pad: 0.058, cut: 700,  gap: [6, 12], vel: 0.05, wet: 0.8,
           chords: [[36, 43, 50, 55], [41, 48, 55, 60], [36, 43, 50, 55], [43, 50, 57, 62]], scale: [60, 62, 64, 67, 69] },
  rain:  { name: 'Soft Rain',      note: 'Gentle rain with a warm hum',            len: 14,  pad: 0.03,  cut: 900,  gap: [4, 9], vel: 0.045, wet: 0.9, rain: true,
           chords: [[48, 55, 59, 64], [41, 48, 52, 57]], scale: [67, 69, 72, 74, 76] },
  dream: { name: 'Sleepy Library', note: 'Low, slow and dreamy',                   len: 18,  pad: 0.058, cut: 800,  gap: [3.5, 7], vel: 0.07, wet: 1.25,
           chords: [[45, 52, 55, 60, 64], [41, 48, 52, 57, 60], [48, 55, 59, 62], [43, 50, 55, 59, 62]], scale: [57, 60, 62, 64, 67, 69, 72] },
};
const mtof = m => 440 * Math.pow(2, (m - 69) / 12);
const rnd = (a, b) => a + Math.random() * (b - a);

const Music = {
  ctx: null, out: null, bus: null, wet: null, rainG: null, rainSrc: null,
  on: true, mood: 'calm', vol: 0.35, duck: 1,
  timer: null, t0: 0, k: 0, nextNote: 0, ai: 0, token: 0,

  load() {
    try {
      const s = JSON.parse(localStorage.getItem('nr-music') || '{}');
      if (typeof s.on === 'boolean') this.on = s.on;
      if (MOODS[s.mood]) this.mood = s.mood;
      if (typeof s.vol === 'number') this.vol = clamp(s.vol, 0, 1);
    } catch (e) { }
  },
  save() { try { localStorage.setItem('nr-music', JSON.stringify({ on: this.on, mood: this.mood, vol: this.vol })); } catch (e) { } },

  ensure() {
    if (this.ctx) return true;
    const AC = window.AudioContext || window.webkitAudioContext;
    if (!AC) return false;
    const c = this.ctx = new AC();
    const comp = c.createDynamicsCompressor();
    comp.threshold.value = -20; comp.ratio.value = 3; comp.attack.value = 0.05; comp.release.value = 0.4;
    this.out = c.createGain(); this.out.gain.value = 0;
    this.out.connect(comp); comp.connect(c.destination);
    this.bus = c.createGain();                       // every voice goes in here
    const dry = c.createGain(); dry.gain.value = 0.85;
    this.bus.connect(dry); dry.connect(this.out);
    const conv = c.createConvolver();                // a soft "room" made from decaying noise
    const len = Math.floor(c.sampleRate * 3.4), ir = c.createBuffer(2, len, c.sampleRate);
    for (let ch = 0; ch < 2; ch++) { const d = ir.getChannelData(ch); for (let i = 0; i < len; i++) d[i] = (Math.random() * 2 - 1) * Math.pow(1 - i / len, 2.6); }
    conv.buffer = ir;
    this.wet = c.createGain(); this.wet.gain.value = 0.9;
    this.bus.connect(conv); conv.connect(this.wet); this.wet.connect(this.out);
    return true;
  },

  level() {
    if (!this.ctx) return;
    const target = this.on ? this.vol * this.duck * 1.35 : 0;
    this.out.gain.setTargetAtTime(target, this.ctx.currentTime, 0.45);
  },

  /* ----- sound makers ----- */
  voice(freq, t, dur, peak, cut) {
    const c = this.ctx, g = c.createGain(), f = c.createBiquadFilter();
    f.type = 'lowpass'; f.frequency.value = cut; f.Q.value = 0.3;
    const att = Math.min(3.5, dur * 0.35), rel = Math.min(5, dur * 0.5);
    g.gain.setValueAtTime(0.0001, t);
    g.gain.linearRampToValueAtTime(peak, t + att);
    g.gain.setTargetAtTime(0, t + dur - rel, rel / 3);
    g.connect(f); f.connect(this.bus);
    [['sine', 1, 1], ['triangle', 1.003, 0.45]].forEach(([type, mul, lvl]) => {
      const o = c.createOscillator(), og = c.createGain();
      o.type = type; o.frequency.value = freq * mul; og.gain.value = lvl;
      o.connect(og); og.connect(g);
      o.start(t); o.stop(t + dur + 0.5);
    });
  },
  bell(t, midi, vel, decay = 3.4) {
    const c = this.ctx, f = mtof(midi), g = c.createGain();
    g.gain.setValueAtTime(0.0001, t);
    g.gain.linearRampToValueAtTime(vel, t + 0.012);
    g.gain.exponentialRampToValueAtTime(0.0001, t + decay);
    g.connect(this.bus);
    [[1, 1], [2, 0.26], [3.01, 0.07]].forEach(([m, l]) => {
      const o = c.createOscillator(), og = c.createGain();
      o.type = 'sine'; o.frequency.value = f * m; og.gain.value = l;
      o.connect(og); og.connect(g); o.start(t); o.stop(t + decay + 0.1);
    });
  },
  pluck(t, midi, vel) {
    const c = this.ctx, g = c.createGain(), f = c.createBiquadFilter(), o = c.createOscillator();
    o.type = 'triangle'; o.frequency.value = mtof(midi);
    f.type = 'lowpass'; f.frequency.value = 2400;
    g.gain.setValueAtTime(0.0001, t);
    g.gain.linearRampToValueAtTime(vel, t + 0.006);
    g.gain.exponentialRampToValueAtTime(0.0001, t + 0.95);
    o.connect(f); f.connect(g); g.connect(this.bus);
    o.start(t); o.stop(t + 1);
  },
  drop(t) {
    const c = this.ctx, o = c.createOscillator(), g = c.createGain();
    o.type = 'sine'; o.frequency.value = rnd(2200, 5200);
    g.gain.setValueAtTime(0.0001, t);
    g.gain.linearRampToValueAtTime(rnd(0.008, 0.022), t + 0.003);
    g.gain.exponentialRampToValueAtTime(0.0001, t + 0.07);
    o.connect(g); g.connect(this.bus); o.start(t); o.stop(t + 0.1);
  },

  /* ----- rain layer ----- */
  rainOn() {
    if (this.rainSrc || !this.ctx) return;
    const c = this.ctx, len = c.sampleRate * 4, buf = c.createBuffer(1, len, c.sampleRate), d = buf.getChannelData(0);
    for (let i = 0; i < len; i++) d[i] = Math.random() * 2 - 1;
    const src = c.createBufferSource(); src.buffer = buf; src.loop = true;
    const bp = c.createBiquadFilter(); bp.type = 'bandpass'; bp.frequency.value = 1600; bp.Q.value = 0.5;
    const lp = c.createBiquadFilter(); lp.type = 'lowpass'; lp.frequency.value = 520;
    const g = this.rainG = c.createGain(); g.gain.value = 0;
    const g2 = c.createGain(); g2.gain.value = 0.5;
    src.connect(bp); bp.connect(g); src.connect(lp); lp.connect(g2); g2.connect(g);
    g.connect(this.out);
    src.start();
    g.gain.setTargetAtTime(0.1, c.currentTime, 1.2);
    this.rainSrc = src;
  },
  rainOff() {
    if (!this.rainSrc) return;
    const src = this.rainSrc, g = this.rainG;
    this.rainSrc = null; this.rainG = null;
    g.gain.setTargetAtTime(0, this.ctx.currentTime, 0.6);
    setTimeout(() => { try { src.stop(); } catch (e) { } }, 3500);
  },

  /* ----- the little conductor ----- */
  tick() {
    if (!this.ctx || !this.on) return;
    const M = MOODS[this.mood], now = this.ctx.currentTime;
    while (this.t0 + this.k * M.len < now + 1.2) {          // pads, one chord after another
      const ch = M.chords[this.k % M.chords.length], t = this.t0 + this.k * M.len;
      ch.forEach((m, i) => this.voice(mtof(m), t + i * 0.12, M.len + 4, M.pad * (i === 0 ? 1.3 : 1), M.cut));
      this.k++;
    }
    while (this.nextNote < now + 1.2) {                      // notes on top
      const t = this.nextNote;
      if (M.arp) {
        const ci = Math.floor(Math.max(0, t - this.t0) / M.len) % M.chords.length, ch = M.chords[ci];
        const pat = [0, 2, 1, 3, 2, 1, 3, 2], idx = pat[this.ai++ % pat.length];
        if (Math.random() > 0.14) this.pluck(t, ch[idx] + (Math.random() < 0.2 ? 24 : 12), M.vel);
        this.nextNote += M.step;
      } else {
        const m = M.scale[Math.floor(Math.random() * M.scale.length)];
        this.bell(t, m, M.vel * rnd(0.7, 1.15));
        this.nextNote += rnd(M.gap[0], M.gap[1]);
      }
    }
    if (M.rain && this.rainSrc && Math.random() < 0.8) this.drop(now + rnd(0.05, 0.3));
  },
  rebase() {
    const t = this.ctx.currentTime + 0.15;
    this.t0 = t; this.k = 0; this.nextNote = t + 1.2; this.ai = 0;
  },

  /* ----- public controls ----- */
  async start(withChime) {
    if (!this.ensure()) return false;
    this.on = true; this.save(); this.token++;
    try { await this.ctx.resume(); } catch (e) { }
    this.wet.gain.value = MOODS[this.mood].wet;
    this.rebase();
    if (!this.timer) this.timer = setInterval(() => this.tick(), 250);
    if (MOODS[this.mood].rain) this.rainOn(); else this.rainOff();
    this.level();
    if (withChime) [72, 76, 79, 84].forEach((m, i) => this.bell(this.ctx.currentTime + 0.1 + i * 0.2, m, 0.1, 3));
    this.refresh();
    return true;
  },
  stop() {
    this.on = false; this.save();
    const tk = ++this.token;
    this.level(); this.rainOff();
    setTimeout(() => {
      if (tk !== this.token) return;
      clearInterval(this.timer); this.timer = null;
      try { this.ctx && this.ctx.suspend(); } catch (e) { }
    }, 2200);
    this.refresh();
  },
  toggle() { return this.on ? this.stop() : this.start(); },
  setMood(m) {
    if (!MOODS[m]) return;
    this.mood = m; this.save();
    if (this.on && this.ctx) {
      this.wet.gain.setTargetAtTime(MOODS[m].wet, this.ctx.currentTime, 0.5);
      this.rebase();
      if (MOODS[m].rain) this.rainOn(); else this.rainOff();
    } else if (!this.on) this.start();
    this.refresh();
  },
  setVol(v) { this.vol = clamp(v, 0, 1); this.save(); this.level(); },
  setDuck(d) { this.duck = d; this.level(); },
  suspend() { try { this.ctx && this.on && this.ctx.suspend(); } catch (e) { } },
  resume() { try { this.ctx && this.on && this.ctx.resume(); } catch (e) { } },
  boot() { this.load(); if (this.on) this.start(true); this.refresh(); },

  /* ----- UI ----- */
  panelHTML() {
    const moods = Object.entries(MOODS).map(([k, m]) => `<button class="mood ${this.mood === k ? 'on' : ''}" data-act="mu-mood" data-v="${k}"><b>${m.name}</b><small>${m.note}</small></button>`).join('');
    return `<button class="mplay ${this.on ? 'on' : ''}" data-act="mu-toggle">${ic(this.on ? 'pause' : 'play', 22)}<span>${this.on ? 'Music is playing' : 'Music is off'}</span><em>${this.on ? 'Tap to pause' : 'Tap to play'}</em></button>
    <div class="lbl">MOOD</div><div class="moods">${moods}</div>
    <div class="lbl" id="mvl">VOLUME · ${Math.round(this.vol * 100)}%</div>
    <div class="slr">${ic('vol', 20)}<input type="range" id="mu-vol" min="0" max="100" value="${Math.round(this.vol * 100)}"></div>`;
  },
  refresh() {
    $$('.mpanel').forEach(p => { p.innerHTML = this.panelHTML(); });
    const b = $('#musicbtn'); if (b) b.classList.toggle('playing', this.on);
  },
  sheet() { Sheet.open(`<div class="mpanel">${this.panelHTML()}</div>`, { title: 'Music' }); },
};

ACT['mu-toggle'] = () => Music.toggle();
ACT['mu-mood'] = el => Music.setMood(el.dataset.v);
ACT['music'] = () => Music.sheet();
document.addEventListener('input', e => {
  if (e.target.id === 'mu-vol') { Music.setVol(+e.target.value / 100); const l = $('#mvl'); if (l) l.textContent = 'VOLUME · ' + e.target.value + '%'; }
});
// Browsers may hold audio back until the first touch: pick it up then.
document.addEventListener('pointerdown', () => { if (Music.on && Music.ctx && Music.ctx.state !== 'running') Music.ctx.resume().catch(() => { }); }, { passive: true });
