'use strict';
/* ===== NerdyReader · adding books ===== */
pdfjsLib.GlobalWorkerOptions.workerSrc = 'lib/pdf.worker.min.js';

const EXT2FMT = { pdf: 'pdf', epub: 'epub', txt: 'txt', text: 'txt', md: 'md', markdown: 'md', html: 'html', htm: 'html', xhtml: 'html', docx: 'docx' };
function detectFormat(file) {
  const ext = (file.name.split('.').pop() || '').toLowerCase();
  if (EXT2FMT[ext]) return EXT2FMT[ext];
  const t = file.type || '';
  if (t === 'application/pdf') return 'pdf';
  if (t === 'application/epub+zip') return 'epub';
  if (t.startsWith('text/')) return 'txt';
  return null;
}
function cleanName(n) {
  return n.replace(/\.[^.]+$/, '').replace(/[_]+/g, ' ').replace(/\s*[-–]\s*(z-?lib|libgen|pdfdrive).*$/i, '').replace(/\s+/g, ' ').trim() || 'Untitled';
}

/* downscale any image blob to a small JPEG data-URL used as the book cover */
function blobToCover(blob, w = 260) {
  return new Promise(res => {
    const url = URL.createObjectURL(blob), im = new Image();
    im.onload = () => {
      try {
        const sc = Math.min(1, w / im.naturalWidth), c = document.createElement('canvas');
        c.width = Math.max(1, Math.round(im.naturalWidth * sc)); c.height = Math.max(1, Math.round(im.naturalHeight * sc));
        const x = c.getContext('2d'); x.fillStyle = '#fff'; x.fillRect(0, 0, c.width, c.height); x.drawImage(im, 0, 0, c.width, c.height);
        res(c.toDataURL('image/jpeg', 0.72));
      } catch (e) { res(null); } finally { URL.revokeObjectURL(url); }
    };
    im.onerror = () => { URL.revokeObjectURL(url); res(null); };
    im.src = url;
  });
}

async function pdfCover(pdf) {
  try {
    const page = await pdf.getPage(1), v1 = page.getViewport({ scale: 1 }), sc = 260 / v1.width;
    const c = document.createElement('canvas'), vp = page.getViewport({ scale: sc });
    c.width = Math.round(vp.width); c.height = Math.round(vp.height);
    await page.render({ canvasContext: c.getContext('2d'), viewport: vp, background: '#fff' }).promise;
    page.cleanup();
    return c.toDataURL('image/jpeg', 0.7);
  } catch (e) { return null; }
}

const junkTitle = t => !t || t.length < 3 || /^(untitled|microsoft word|document\d*|slide \d+|\w*\.(docx?|pdf|tex|indd))/i.test(t.trim());

async function importFile(file) {
  const fmt = detectFormat(file);
  if (!fmt) throw new Error('Can’t read “' + file.name + '” yet. Supported: PDF, EPUB, TXT, MD, HTML, DOCX.');
  const dup = bookList().find(b => b.fileName === file.name && b.size === file.size);
  if (dup) return { book: dup, dup: true };

  const rec = { id: uid(), title: '', author: '', format: fmt, fileName: file.name, size: file.size, added: Date.now(), lastRead: 0, progress: 0, pos: null, saved: false, cover: null, desc: '', bookmarks: [], count: 0, words: 0 };
  const base = cleanName(file.name);
  const blob = file instanceof Blob ? file : new Blob([file]);

  if (fmt === 'pdf') {
    const pdf = await pdfjsLib.getDocument({ data: new Uint8Array(await blob.arrayBuffer()) }).promise;
    rec.count = pdf.numPages;
    try {
      const m = await pdf.getMetadata();
      if (!junkTitle(m.info?.Title)) rec.title = m.info.Title.trim();
      rec.author = (m.info?.Author || '').trim();
    } catch (e) { }
    rec.cover = await pdfCover(pdf);
    rec.words = rec.count * 320;
    pdf.destroy();
  } else if (fmt === 'epub') {
    const P = await parseEpub(blob);
    rec.title = P.meta.title; rec.author = P.meta.author; rec.desc = P.meta.desc;
    rec.count = P.chapters.length; rec.words = P.chapters.reduce((a, c) => a + c.words, 0);
    if (P.meta.cover) rec.cover = await blobToCover(P.meta.cover);
  } else {
    let P;
    if (fmt === 'docx') P = await parseDocx(blob);
    else {
      const txt = await decodeText(await blob.arrayBuffer());
      P = fmt === 'md' ? parseMd(txt, { title: base }) : fmt === 'html' ? parseHtml(txt, { title: base }) : parseTxt(txt, { title: base });
    }
    rec.title = P.meta.title; rec.author = P.meta.author;
    rec.count = P.chapters.length; rec.words = P.chapters.reduce((a, c) => a + c.words, 0);
  }
  rec.title = (rec.title || '').trim() || base;
  rec.author = (rec.author || '').trim();
  await DB.putBookAndFile(rec, blob);
  S.books.set(rec.id, rec);
  return { book: rec, dup: false };
}

async function importMany(files) {
  files = [...files];
  if (!files.length) return [];
  const done = [];
  let ok = 0, dups = 0, fails = [];
  for (let i = 0; i < files.length; i++) {
    toast(files.length > 1 ? `Adding ${i + 1} of ${files.length}…` : 'Adding book…', 60000);
    try {
      const r = await importFile(files[i]);
      done.push(r.book);
      r.dup ? dups++ : ok++;
    } catch (e) { console.warn(e); fails.push(e.message || String(e)); }
  }
  const parts = [];
  if (ok) parts.push(ok === 1 ? 'Added “' + shortStr(done[done.length - 1].title, 32) + '”' : `Added ${ok} books`);
  if (dups) parts.push(dups === 1 ? 'already in your library' : dups + ' already in your library');
  if (fails.length) parts.push(fails[0]);
  toast(parts.join(' · ') || 'Nothing added', fails.length ? 5000 : 2600);
  render();
  return done;
}

/* open the system file picker (WebView hands it to Android) */
function pickFiles() {
  const p = $('#picker');
  p.value = '';
  p.click();
}
