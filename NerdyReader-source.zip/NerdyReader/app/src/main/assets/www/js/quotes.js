'use strict';
/* ===== NerdyReader · quotes from your own books =====
   Every book you add is read once (on the phone, in the background) and its best sentences are kept
   as a small quote bank. The Home screen shows them one after another, picking a different book each time,
   with the title, the chapter and the page. You can also save your own: select text while reading, or pick a
   sentence from the current PDF page. Favourites live in localStorage ("nr-qfav"). */
const QX_VER = 1;

/* ---------- reading text out of a PDF page ---------- */
const LIG = { 'ﬁ': 'fi', 'ﬂ': 'fl', 'ﬀ': 'ff', 'ﬃ': 'ffi', 'ﬄ': 'ffl', '\u00AD': '' };
function pdfItemsText(items) {
  let out = '', line = '', lastY = null;
  const push = () => {
    line = line.trim(); if (!line) return;
    if (!out) out = line;
    else if (/[A-Za-z\u00C0-\u024F]-$/.test(out) && /^[a-z]/.test(line)) out = out.slice(0, -1) + line;
    else out += ' ' + line;
    line = '';
  };
  for (const it of items) {
    const y = it.transform ? it.transform[5] : 0;
    if (lastY !== null && Math.abs(y - lastY) > 3) push();
    line += it.str; lastY = y;
    if (it.hasEOL) push();
  }
  push();
  return out.replace(/[ﬁﬂﬀﬃﬄ\u00AD]/g, c => LIG[c]).replace(/\s+/g, ' ').trim();
}
function splitSentences(text) {
  text = text.replace(/\s+/g, ' ').replace(/\b(Mr|Mrs|Ms|Dr|Prof|Sr|Jr|St|vs|etc|No|Fig|Vol|e\.g|i\.e)\./g, m => m.replace(/\./g, '\u0001'));
  const out = [];
  for (const chunk of text.split(/(?<=।)\s+/u)) {
    for (const s of chunk.split(/(?<=[.!?…]["”’)\]]?)\s+(?=["“‘'(\[]?\p{Lu})/u)) out.push(s.replace(/\u0001/g, '.').trim());
  }
  return out;
}
const CUES = /\b(always|never|life|love|truth|time|mind|heart|world|fear|hope|courage|wisdom|learn|dream|dreams|freedom|happiness|success|change|nothing|everything|believe|power|soul|silence|knowledge|death|joy|pain|human|struggle|purpose|meaning|habit|habits|discipline|mistakes?|failure|patience|kindness|truly|yourself|ourselves)\b/gi;
function quoteScore(s) {
  const len = s.length; if (len < 55 || len > 230) return -1;
  if (!/^["“‘'(\[]?\p{Lu}/u.test(s)) return -1;
  if (!/[.!?…।]["”’)\]]?$/u.test(s)) return -1;
  const words = s.split(/\s+/).length; if (words < 9 || words > 38) return -1;
  const letters = (s.match(/\p{L}/gu) || []).length; if (letters / len < 0.78) return -1;
  if ((s.match(/\d/g) || []).length > 3) return -1;
  if (/(https?:|www\.|@|©|ISBN|copyright|all rights reserved|\.{4,}|chapter \d|table of contents|figure \d|\bpage \d|\bvol\.)/i.test(s)) return -1;
  const upper = (s.match(/\p{Lu}/gu) || []).length; if (upper / letters > 0.3) return -1;
  const q = (s.match(/["“”]/g) || []).length; if (q % 2) return -1;
  let sc = 10 - Math.abs(words - 20) * 0.25;
  if (/^(He|She|It|They|This|That|These|Those|His|Her|Their|And|But|So|Then|However|Yet|Also|There|Or|Because|Which|When|After|Before)\b/.test(s)) sc -= 2.6;
  if (/\b(said|asked|replied|whispered|shouted|muttered|cried|exclaimed)\b/i.test(s)) sc -= 2.2;
  sc += Math.min((s.match(CUES) || []).length, 3) * 1.2;
  const commas = (s.match(/,/g) || []).length; if (commas > 3) sc -= (commas - 3) * 1.2;
  if (/\b(is|are|was|were|can|will|does|do)\b.{0,40}\b(not|no|only|never|always|more than|nothing|everything)\b/i.test(s)) sc += 1;
  if (/[:;]/.test(s)) sc -= 0.5;
  return sc;
}
function pickQuotes(c) {
  if (!c.length) return [];
  const B = 12, PER = 4, bk = Array.from({ length: B }, () => []);
  c.forEach(x => bk[Math.min(B - 1, Math.floor(x.pos * B))].push(x));
  const out = [];
  for (const a of bk) {
    a.sort((x, y) => y.sc - x.sc);
    const took = [];
    for (const x of a) { if (took.length >= PER) break; if (took.some(t => t.t.slice(0, 28) === x.t.slice(0, 28))) continue; took.push(x); }
    out.push(...took);
  }
  out.sort((a, b) => a.pos - b.pos);
  return out.map(x => ({ t: x.t, p: x.p, c: x.c, ch: x.ch, r: x.r }));
}
async function pdfChapters(pdf) {
  try {
    const ol = await pdf.getOutline(); if (!ol) return [];
    const flat = []; (function walk(a, d) { (a || []).forEach(n => { flat.push({ t: n.title, d, dest: n.dest }); walk(n.items, d + 1); }); })(ol, 0);
    const out = [];
    for (const n of flat.slice(0, 500)) {
      try {
        let dest = n.dest; if (typeof dest === 'string') dest = await pdf.getDestination(dest);
        const ref = dest && dest[0], pg = typeof ref === 'object' ? (await pdf.getPageIndex(ref)) + 1 : (ref | 0) + 1;
        if (pg > 0) out.push({ p: pg, t: (n.t || '').trim(), d: n.d });
      } catch (e) { }
    }
    return out.sort((a, b) => a.p - b.p || a.d - b.d);
  } catch (e) { return []; }
}
const chapterAt = (ch, p) => { let r = ''; for (const c of ch) { if (c.p <= p) r = c.t; else break; } return r; };
function htmlParas(html) {
  const doc = new DOMParser().parseFromString(html, 'text/html'), out = [];
  doc.querySelectorAll('p,li,blockquote,div').forEach(n => { if (n.querySelector('p,li,blockquote,div')) return; const t = (n.textContent || '').replace(/\s+/g, ' ').trim(); if (t) out.push(t); });
  return out;
}

const Quotes = {
  bank: [], fav: [], recent: [], hist: [], hi: -1, cur: null, tm: null, busy: false, prog: null, firstShown: false,
  q2: { f: 'all', q: '', n: 40 },

  loadFav() { try { this.fav = JSON.parse(localStorage.getItem('nr-qfav')) || []; } catch (e) { this.fav = []; } },
  saveFav() { try { localStorage.setItem('nr-qfav', JSON.stringify(this.fav)); } catch (e) { } },
  qid: t => 'q' + hashStr(t),
  isFav(q) { const id = this.qid(q.t); return this.fav.some(f => f.id === id); },
  toggleFav(q) {
    const id = this.qid(q.t), i = this.fav.findIndex(f => f.id === id);
    if (i >= 0) { this.fav.splice(i, 1); this.saveFav(); return false; }
    const b = S.books.get(q.bookId);
    this.fav.unshift({ id, t: q.t, bookId: q.bookId, title: b ? b.title : q.title || '', c: q.c, p: q.p, ch: q.ch, r: q.r, mine: !!q.mine, ts: Date.now() });
    this.saveFav(); return true;
  },
  async load() {
    let recs = []; try { recs = await DB.allQuotes(); } catch (e) { }
    this.bank = [];
    for (const r of recs) {
      if (!S.books.has(r.bookId)) continue;
      r.list.forEach((q, i) => this.bank.push({ id: r.bookId + ':' + i, bookId: r.bookId, t: q.t, p: q.p, c: q.c, ch: q.ch, r: q.r }));
    }
    try { // a few short ones for the welcome screen next time
      const short = this.bank.filter(q => q.t.length <= 125).sort(() => Math.random() - .5).slice(0, 12).map(q => ({ t: q.t, b: (S.books.get(q.bookId) || {}).title || '' }));
      if (short.length) localStorage.setItem('nr-qsp', JSON.stringify(short));
    } catch (e) { }
  },

  /* ---------- building the bank ---------- */
  async ensure(force) {
    if (this.busy) return;
    let have = new Map();
    try { (await DB.allQuotes()).forEach(r => have.set(r.bookId, r)); } catch (e) { return; }
    const todo = bookList().filter(b => force || !have.has(b.id) || have.get(b.id).v !== QX_VER);
    if (!todo.length) return;
    this.busy = true; this.prog = { done: 0, total: todo.length, name: '' }; this.ui();
    for (const b of todo) {
      if (!S.books.has(b.id)) { this.prog.done++; continue; }
      while (typeof RD !== 'undefined' && RD) await sleep(2500);        // never compete with reading
      this.prog.name = b.title; this.ui();
      let list = [];
      try { list = await this.extract(b); } catch (e) { console.warn('quotes', b.title, e); }
      try { await DB.putQuotes({ bookId: b.id, v: QX_VER, ts: Date.now(), list }); } catch (e) { }
      this.prog.done++;
      await this.load(); this.ui();
    }
    this.busy = false; this.prog = null;
    await this.load(); this.ui();
    if (S.view === 'home' && !this.cur) this.mount();
  },
  async extract(b) {
    const blob = await DB.getFile(b.id); if (!blob) return [];
    const cands = [];
    if (b.format === 'pdf') {
      const pdf = await pdfjsLib.getDocument({ data: new Uint8Array(await blob.arrayBuffer()) }).promise;
      try {
        const chap = await pdfChapters(pdf), n = pdf.numPages;
        for (let i = 1; i <= n; i++) {
          if (typeof RD !== 'undefined' && RD) await sleep(1500);
          const page = await pdf.getPage(i);
          const text = pdfItemsText((await page.getTextContent()).items); page.cleanup();
          for (const s of splitSentences(text)) { const sc = quoteScore(s); if (sc > 0) cands.push({ t: s, sc, p: i, c: chapterAt(chap, i), pos: i / n }); }
          if (i % 6 === 0) await sleep(0);
        }
      } finally { try { pdf.destroy(); } catch (e) { } }
    } else {
      let P;
      if (b.format === 'epub') P = await parseEpub(blob);
      else if (b.format === 'docx') P = await parseDocx(blob);
      else { const txt = await decodeText(await blob.arrayBuffer()); P = b.format === 'md' ? parseMd(txt, b) : b.format === 'html' ? parseHtml(txt, b) : parseTxt(txt, b); }
      const N = P.chapters.length;
      try {
        for (let ci = 0; ci < N; ci++) {
          const { html } = await P.load(ci), paras = htmlParas(html), title = (P.chapters[ci].title || '').trim();
          paras.forEach((para, pi) => {
            for (const s of splitSentences(para)) { const sc = quoteScore(s); if (sc > 0) cands.push({ t: s, sc, ch: ci, r: pi / Math.max(1, paras.length), c: title, pos: (ci + pi / Math.max(1, paras.length)) / N }); }
          });
          if (ci % 3 === 2) await sleep(0);
        }
      } finally { try { P.revoke && P.revoke(); } catch (e) { } }
    }
    return pickQuotes(cands);
  },
  ui() {
    const el = $('#qstatus'); if (el) el.innerHTML = this.statusHTML();
    const h = $('#qhome'); if (h && !this.cur) h.innerHTML = this.emptyHTML();
  },
  statusHTML() {
    const nb = new Set(this.bank.map(q => q.bookId)).size;
    if (this.busy && this.prog) return `<div class="note">${ic('spark', 14)} Reading your books for quotes… ${this.prog.done} of ${this.prog.total}${this.prog.name ? ' · ' + esc(shortStr(this.prog.name, 28)) : ''}</div>`;
    return `<p class="sm mute" style="margin:0 0 10px"><b>${this.bank.length}</b> quote${this.bank.length === 1 ? '' : 's'} from <b>${nb}</b> book${nb === 1 ? '' : 's'}${this.fav.length ? ` · <b>${this.fav.length}</b> saved` : ''}</p>`;
  },

  /* ---------- picking ---------- */
  pick() {
    const by = new Map(); this.bank.forEach(q => { if (!by.has(q.bookId)) by.set(q.bookId, []); by.get(q.bookId).push(q); });
    if (!by.size) return null;
    let ids = [...by.keys()];
    if (ids.length > 1 && this.cur) ids = ids.filter(i => i !== this.cur.bookId);            // a different book each time
    const list = by.get(ids[Math.floor(Math.random() * ids.length)]);
    let pool = list.filter(q => !this.recent.includes(q.id)); if (!pool.length) pool = list;
    const q = pool[Math.floor(Math.random() * pool.length)];
    this.recent.push(q.id); if (this.recent.length > 30) this.recent.shift();
    return q;
  },
  daily() {                                          // the same quote all day, new one tomorrow
    if (!this.bank.length) return null;
    const ids = [...new Set(this.bank.map(q => q.bookId))].sort(), seed = hashStr(dkey(Date.now()));
    const list = this.bank.filter(q => q.bookId === ids[seed % ids.length]);
    return list[(seed >> 3) % list.length];
  },
  titleOf(q) { const b = S.books.get(q.bookId); return b ? b.title : (q.title || ''); },
  where(q) {
    const bits = []; if (q.c) bits.push(shortStr(q.c, 46));
    if (q.p) bits.push('page ' + q.p); else if (!q.c && q.ch != null) bits.push('chapter ' + (q.ch + 1));
    return bits.join(' · ');
  },

  /* ---------- the Home card ---------- */
  emptyHTML() {
    return `<div class="qmark">${ic('quote', 26)}</div><p class="qtext sm">${this.busy ? 'Finding the best lines in your books…' : bookList().length ? 'Quotes from your books will appear here. Scanned PDFs have no text to pull from.' : 'Add a few books and their best lines will appear here, a new one every few seconds.'}</p><div id="qstatus">${this.statusHTML()}</div>`;
  },
  cardHTML() {
    return `<div class="qcard" id="qcard"><div id="qhome">${this.cur ? this.bodyHTML(this.cur) : this.emptyHTML()}</div>${ST.qsec > 0 && this.cur ? `<div class="qbar"><i style="animation-duration:${ST.qsec}s"></i></div>` : ''}</div>`;
  },
  bodyHTML(q) {
    const L = q.t.length, sz = L < 90 ? 'l' : L < 150 ? 'm' : 's';
    return `<div class="qmark">${ic('quote', 26)}</div><blockquote class="qtext ${sz}">${esc(q.t)}</blockquote>
      <div class="qsrc"><b>${esc(shortStr(this.titleOf(q), 54))}</b>${this.where(q) ? `<small>${esc(this.where(q))}</small>` : ''}</div>
      <div class="qacts"><button data-act="q-prev" aria-label="Previous">${ic('left', 18)}</button><button data-act="q-fav" class="${this.isFav(q) ? 'on' : ''}" aria-label="Favourite">${icFill('heart', 18).replace('fill="currentColor"', this.isFav(q) ? 'fill="currentColor"' : 'fill="none"')}</button><button data-act="q-copy" aria-label="Copy">${ic('copy', 18)}</button><button data-act="q-open" aria-label="Open in book">${ic('book', 18)}</button><button data-act="q-next" aria-label="Next quote">${ic('right', 18)}</button></div>`;
  },
  mount() {                                          // called after Home renders
    clearTimeout(this.tm);
    if (!$('#qcard') || !this.bank.length) return;
    if (!this.cur || !S.books.has(this.cur.bookId)) {
      this.cur = !this.firstShown ? this.daily() : this.pick(); this.firstShown = true;
      if (this.cur) { this.hist = [this.cur]; this.hi = 0; }
    }
    $('#qhome').innerHTML = this.cur ? this.bodyHTML(this.cur) : this.emptyHTML();
    const c = $('#qcard'); if (c && !c.querySelector('.qbar') && ST.qsec > 0) c.insertAdjacentHTML('beforeend', `<div class="qbar"><i style="animation-duration:${ST.qsec}s"></i></div>`);
    this.sched();
  },
  sched() {
    clearTimeout(this.tm);
    if (!(ST.qsec > 0)) return;
    this.tm = setTimeout(() => {
      if (!$('#qcard')) return;                       // left the Home screen
      if (document.hidden || (typeof RD !== 'undefined' && RD)) return this.sched();
      this.go(1);
    }, ST.qsec * 1000);
  },
  go(dir) {
    if (!this.bank.length) return;
    let q;
    if (dir < 0) { if (this.hi <= 0) return toast('This is where you started'); q = this.hist[--this.hi]; }
    else if (this.hi < this.hist.length - 1) q = this.hist[++this.hi];
    else { q = this.pick(); if (!q) return; this.hist.push(q); if (this.hist.length > 60) this.hist.shift(); this.hi = this.hist.length - 1; }
    this.show(q);
  },
  show(q) {
    this.cur = q;
    const box = $('#qhome'); if (!box) return;
    box.classList.add('out');
    setTimeout(() => {
      const b = $('#qhome'); if (!b) return;
      b.innerHTML = this.bodyHTML(q); b.classList.remove('out');
      const bar = $('#qcard .qbar i'); if (bar) { const p = bar.parentNode; p.innerHTML = `<i style="animation-duration:${ST.qsec}s"></i>`; }
      this.sched();
    }, 260);
  },
  copy(q) {
    const s = `“${q.t}”\n— ${this.titleOf(q)}${this.where(q) ? ', ' + this.where(q) : ''}`;
    try { navigator.clipboard.writeText(s); toast('Quote copied'); } catch (e) { toast('Could not copy'); }
  },
  open(q) {
    if (!S.books.has(q.bookId)) return toast('That book is no longer in your library');
    openReader(q.bookId, q.p ? { page: q.p, r: 0 } : { ch: q.ch || 0, r: q.r || 0 });
  },
};

/* ---------- the Quotes screen ---------- */
function quoteRow(q, i) {
  const fav = Quotes.isFav(q);
  return `<article class="qrw"><blockquote class="serif">${esc(q.t)}</blockquote><div class="qrs"><div><b>${esc(shortStr(Quotes.titleOf(q), 44))}</b><small>${esc(Quotes.where(q))}${q.mine ? (Quotes.where(q) ? ' · ' : '') + 'saved by you' : ''}</small></div>
    <div class="qacts sm"><button data-act="qr-fav" data-i="${i}" class="${fav ? 'on' : ''}" aria-label="Favourite">${icFill('heart', 17).replace('fill="currentColor"', fav ? 'fill="currentColor"' : 'fill="none"')}</button><button data-act="qr-copy" data-i="${i}" aria-label="Copy">${ic('copy', 17)}</button><button data-act="qr-open" data-i="${i}" aria-label="Open">${ic('book', 17)}</button></div></div></article>`;
}
function quoteList() {
  const f = Quotes.q2, favs = f.f === 'fav';
  let l = favs ? Quotes.fav.map(x => ({ ...x })) : Quotes.bank.slice();
  if (!favs && f.f !== 'all') l = l.filter(q => q.bookId === f.f);
  const w = f.q.trim().toLowerCase().split(/\s+/).filter(Boolean);
  if (w.length) l = l.filter(q => { const h = (q.t + ' ' + Quotes.titleOf(q)).toLowerCase(); return w.every(x => h.includes(x)); });
  if (!favs && !w.length) { // shuffled once per visit, so every visit shows different ones
    if (!Quotes._order || Quotes._order.n !== Quotes.bank.length) { Quotes._order = { n: Quotes.bank.length, k: new Map(Quotes.bank.map(q => [q.id, Math.random()])) }; }
    l.sort((a, b) => Quotes._order.k.get(a.id) - Quotes._order.k.get(b.id));
  }
  Quotes._shown = l;
  if (!l.length) return `<div class="card empty"><p>${favs ? 'Tap the heart on a quote to keep it here.' : w.length ? 'No quote matches.' : Quotes.busy ? 'Still reading your books…' : 'No quotes yet. Add a book with real text (not a scan).'}</p></div>`;
  return `<div class="cnt" style="margin:4px 2px 10px">${l.length} quote${l.length === 1 ? '' : 's'}</div>${l.slice(0, f.n).map((q, i) => quoteRow(q, i)).join('')}${l.length > f.n ? `<button class="btn wide" data-act="qr-more" style="margin-top:6px">Show more</button>` : ''}`;
}
function vQuotes() {
  const f = Quotes.q2, withQ = [...new Set(Quotes.bank.map(q => q.bookId))].map(id => S.books.get(id)).filter(Boolean).sort((a, b) => a.title.localeCompare(b.title));
  return `<h1 class="pgt">Quotes</h1><p class="sub">The best lines from the books on your shelf.</p>
  <div id="qstatus">${Quotes.statusHTML()}</div>
  <div class="seg"><button class="${f.f === 'all' ? 'on' : ''}" data-act="qr-f" data-v="all">All</button><button class="${f.f === 'fav' ? 'on' : ''}" data-act="qr-f" data-v="fav">Saved ${Quotes.fav.length ? `<small>${Quotes.fav.length}</small>` : ''}</button></div>
  ${withQ.length ? `<label class="sel wide" style="margin-bottom:12px">${ic('book', 18)}<select id="qbook"><option value="all" ${f.f === 'all' || f.f === 'fav' ? 'selected' : ''}>Every book</option>${withQ.map(b => `<option value="${b.id}" ${f.f === b.id ? 'selected' : ''}>${esc(shortStr(b.title, 44))}</option>`).join('')}</select>${ic('down', 16)}</label>` : ''}
  <div class="sbox big" style="margin-top:0">${ic('search', 20)}<input id="qsearch" type="search" value="${esc(f.q)}" placeholder="Search quotes" autocomplete="off"></div>
  <div id="qlist">${quoteList()}</div>
  <div class="row gap" style="margin-top:14px"><button class="btn" data-act="q-rebuild" ${Quotes.busy ? 'disabled' : ''}>${ic('refresh', 16)} Find quotes again</button></div>
  <section class="card"><h3>Home screen quotes</h3><div class="lbl" style="margin-top:6px">CHANGE EVERY</div><div class="seg3">${[[8, '8 s'], [14, '14 s'], [30, '30 s'], [60, '1 min'], [0, 'Manual']].map(([v, t]) => `<button class="${ST.qsec === v ? 'on' : ''}" data-act="q-sec" data-v="${v}">${t}</button>`).join('')}</div>
    <p class="sm mute" style="margin:12px 0 0">While reading, select text and tap <b>Save quote</b>, or open <b>Aa → Save a quote from this page</b> in a PDF.</p></section>`;
}

ACT['q-next'] = () => Quotes.go(1);
ACT['q-prev'] = () => Quotes.go(-1);
ACT['q-fav'] = el => { const q = Quotes.cur; if (!q) return; const on = Quotes.toggleFav(q); el.classList.toggle('on', on); el.innerHTML = icFill('heart', 18).replace('fill="currentColor"', on ? 'fill="currentColor"' : 'fill="none"'); toast(on ? 'Saved to your quotes' : 'Removed from saved'); Quotes.sched(); };
ACT['q-copy'] = () => Quotes.cur && Quotes.copy(Quotes.cur);
ACT['q-open'] = () => Quotes.cur && Quotes.open(Quotes.cur);
ACT['q-rebuild'] = async () => { toast('Looking for quotes…'); Quotes.ensure(true); setTimeout(() => S.view === 'quotes' && render(), 100); };
ACT['q-sec'] = el => { ST.qsec = +el.dataset.v; saveST(); const sc = $('#main').scrollTop; render(); $('#main').scrollTop = sc; };
ACT['qr-f'] = el => { Quotes.q2.f = el.dataset.v; Quotes.q2.n = 40; render(); };
ACT['qr-more'] = () => { Quotes.q2.n += 40; $('#qlist').innerHTML = quoteList(); };
ACT['qr-fav'] = el => { const q = Quotes._shown[+el.dataset.i]; if (!q) return; const on = Quotes.toggleFav(q); if (Quotes.q2.f === 'fav') { $('#qlist').innerHTML = quoteList(); } else { el.classList.toggle('on', on); el.innerHTML = icFill('heart', 17).replace('fill="currentColor"', on ? 'fill="currentColor"' : 'fill="none"'); } };
ACT['qr-copy'] = el => { const q = Quotes._shown[+el.dataset.i]; q && Quotes.copy(q); };
ACT['qr-open'] = el => { const q = Quotes._shown[+el.dataset.i]; q && Quotes.open(q); };
document.addEventListener('input', e => { if (e.target.id === 'qsearch') { Quotes.q2.q = e.target.value; Quotes.q2.n = 40; $('#qlist').innerHTML = quoteList(); } });
document.addEventListener('change', e => { if (e.target.id === 'qbook') { Quotes.q2.f = e.target.value; Quotes.q2.n = 40; const sc = $('#main').scrollTop; render(); $('#main').scrollTop = sc; } });

/* ---------- saving your own quotes while reading ---------- */
function readerPlace() {
  if (!RD) return {};
  if (RD.kind === 'pages' || (Book.on && RD.b.format === 'pdf' && RD.kind === 'pages')) return { p: RD.page };
  const c = RD.P && RD.P.chapters[RD.ch];
  return RD.b.format === 'pdf' ? { ch: RD.ch, c: c ? c.title : '', r: RD.r } : { ch: RD.ch, c: c ? c.title : '', r: RD.r };
}
function selectedQuote() {
  if (!RD) return '';
  const sel = window.getSelection && window.getSelection(); if (!sel || sel.isCollapsed) return '';
  const n = sel.anchorNode && (sel.anchorNode.nodeType === 1 ? sel.anchorNode : sel.anchorNode.parentElement);
  if (!n || !n.closest('#rart')) return '';
  return sel.toString().replace(/\s+/g, ' ').trim();
}
document.addEventListener('selectionchange', () => {
  const b = $('#qsave'); if (!b) return;
  const t = selectedQuote();
  b.hidden = !(t.length >= 12 && t.length <= 700);
});
ACT['q-saveSel'] = () => {
  const t = selectedQuote(); if (!t) return;
  Quotes.toggleFav({ t, bookId: RD.b.id, mine: true, ...readerPlace() });
  try { window.getSelection().removeAllRanges(); } catch (e) { }
  $('#qsave').hidden = true; toast('Quote saved');
};
ACT['q-pick'] = async () => {
  if (!RD || RD.b.format !== 'pdf' || RD.kind !== 'pages') return toast('Select text in Scroll view to save a quote');
  Sheet.close();
  const pages = Book.on && Book.src ? (() => { const f = Book.facesAt(Book.src, Book.cur.s); return [f.l, f.r].filter(x => x != null && x < RD.np).map(x => x + 1); })() : [RD.page];
  let list = [];
  for (const pn of pages) {
    try { const pg = await RD.pdf.getPage(pn); const tx = pdfItemsText((await pg.getTextContent()).items); pg.cleanup(); splitSentences(tx).forEach(s => { if (s.length >= 25 && s.length <= 400) list.push({ t: s, p: pn }); }); } catch (e) { }
  }
  Quotes._pick = list;
  setTimeout(() => Sheet.open(list.length ? `<p class="sm mute" style="margin:0 0 8px">Tap a sentence to save it.</p>${list.map((q, i) => `<button class="pickq" data-act="q-pickone" data-i="${i}">${esc(q.t)}</button>`).join('')}` : `<p class="sm mute">No selectable text on this page. It may be a scan.</p>`, { title: 'Save a quote' }), 260);
};
ACT['q-pickone'] = el => {
  const q = Quotes._pick[+el.dataset.i]; if (!q) return;
  const ol = RD.outline, chap = ''; // chapter name is filled in later if the PDF has contents
  Quotes.toggleFav({ t: q.t, bookId: RD.b.id, mine: true, p: q.p, c: chap });
  Sheet.close(); toast('Quote saved');
};
