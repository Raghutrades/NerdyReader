'use strict';
/* ===== NerdyReader · helpers ===== */
const $ = (s, r = document) => r.querySelector(s);
const $$ = (s, r = document) => [...r.querySelectorAll(s)];
const esc = s => String(s ?? '').replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
const sleep = ms => new Promise(r => setTimeout(r, ms));
const uid = () => Date.now().toString(36) + Math.random().toString(36).slice(2, 8);
const clamp = (v, a, b) => Math.min(b, Math.max(a, v));
const AB = window.NerdyBridge || null; // Android bridge (null in a normal browser)

const IC = {
  menu: '<path d="M4 6h16M4 12h16M4 18h16"/>',
  home: '<path d="M3 11l9-8 9 8"/><path d="M5 10v10h14V10"/><path d="M10 20v-6h4v6"/>',
  grid: '<rect x="3" y="3" width="7" height="7" rx="1.5"/><rect x="14" y="3" width="7" height="7" rx="1.5"/><rect x="3" y="14" width="7" height="7" rx="1.5"/><rect x="14" y="14" width="7" height="7" rx="1.5"/>',
  search: '<circle cx="11" cy="11" r="7"/><path d="M21 21l-4.3-4.3"/>',
  book: '<path d="M2 4h6a4 4 0 014 4v13a3 3 0 00-3-3H2z"/><path d="M22 4h-6a4 4 0 00-4 4v13a3 3 0 013-3h7z"/>',
  shelf: '<path d="M3 5h4v15H3zM9 5h4v15H9z"/><path d="M15.5 6.5l3.8-1 3 14-3.8 1z"/>',
  user: '<circle cx="12" cy="8" r="4"/><path d="M4 21c0-4 3.5-6 8-6s8 2 8 6"/>',
  plus: '<path d="M12 5v14M5 12h14"/>',
  minus: '<path d="M5 12h14"/>',
  left: '<path d="M15 18l-6-6 6-6"/>',
  right: '<path d="M9 18l6-6-6-6"/>',
  down: '<path d="M6 9l6 6 6-6"/>',
  list: '<path d="M8 6h13M8 12h13M8 18h13"/><circle cx="3.5" cy="6" r="1"/><circle cx="3.5" cy="12" r="1"/><circle cx="3.5" cy="18" r="1"/>',
  bookmark: '<path d="M6 3h12v18l-6-4-6 4z"/>',
  x: '<path d="M6 6l12 12M18 6L6 18"/>',
  check: '<path d="M5 12l5 5L20 7"/>',
  trash: '<path d="M4 7h16M10 11v6M14 11v6M6 7l1 13h10l1-13M9 7V4h6v3"/>',
  star: '<path d="M12 3l2.7 5.6 6.1.9-4.4 4.3 1 6.1L12 17l-5.4 2.9 1-6.1L3.2 9.5l6.1-.9z"/>',
  edit: '<path d="M4 20h4L19 9l-4-4L4 16z"/><path d="M13.5 6.5l4 4"/>',
  file: '<path d="M14 3H6a1 1 0 00-1 1v16a1 1 0 001 1h12a1 1 0 001-1V8z"/><path d="M14 3v5h5"/>',
  folder: '<path d="M3 6a1 1 0 011-1h5l2 2h9a1 1 0 011 1v10a1 1 0 01-1 1H4a1 1 0 01-1-1z"/>',
  heart: '<path d="M12 20s-7-4.4-9-9a5 5 0 019-3 5 5 0 019 3c-2 4.6-9 9-9 9z"/>',
  ext: '<path d="M14 4h6v6M20 4l-9 9M18 14v6H4V6h6"/>',
  copy: '<rect x="9" y="9" width="11" height="11" rx="2"/><path d="M5 15V6a2 2 0 012-2h9"/>',
  fit: '<path d="M4 9V4h5M20 9V4h-5M4 15v5h5M20 15v5h-5"/>',
  lock: '<rect x="5" y="11" width="14" height="10" rx="2"/><path d="M8 11V8a4 4 0 018 0v3"/>',
  info: '<circle cx="12" cy="12" r="9"/><path d="M12 11v6M12 7.5v.5"/>',
  sort: '<path d="M7 4v16M3 8l4-4 4 4M17 20V4M13 16l4 4 4-4"/>',
  clock: '<circle cx="12" cy="12" r="9"/><path d="M12 7v5l3 2"/>',
  pdf: '<path d="M14 3H6a1 1 0 00-1 1v16a1 1 0 001 1h12a1 1 0 001-1V8z"/><path d="M14 3v5h5M8 14h8M8 17.5h5"/>',
  target: '<circle cx="12" cy="12" r="9"/><circle cx="12" cy="12" r="4.5"/><circle cx="12" cy="12" r=".6"/>',
  play: '<path d="M7 4l13 8-13 8z"/>',
  pause: '<rect x="6" y="4" width="4" height="16" rx="1"/><rect x="14" y="4" width="4" height="16" rx="1"/>',
  skipn: '<path d="M5 4l10 8-10 8z"/><path d="M19 5v14"/>',
  skipp: '<path d="M19 4L9 12l10 8z"/><path d="M5 5v14"/>',
  phones: '<path d="M4 15v-3a8 8 0 0116 0v3"/><rect x="3" y="14" width="4" height="7" rx="1.5"/><rect x="17" y="14" width="4" height="7" rx="1.5"/>',
  wifi: '<path d="M2 9a15 15 0 0120 0M5.5 12.5a10 10 0 0113 0M9 16a5 5 0 016 0"/><circle cx="12" cy="19.5" r=".7"/><path d="M4 4l16 16"/>',
};
const ic = (n, s = 20) => `<svg class="ic" width="${s}" height="${s}" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">${IC[n] || ''}</svg>`;
const icFill = (n, s = 20) => ic(n, s).replace('fill="none"', 'fill="currentColor"');

const FMT = { pdf: 'PDF', epub: 'EPUB', txt: 'TXT', md: 'MD', html: 'HTML', docx: 'DOCX' };
const sizeStr = b => b < 1024 ? b + ' B' : b < 1048576 ? (b / 1024).toFixed(0) + ' KB' : (b / 1048576).toFixed(b < 10485760 ? 1 : 0) + ' MB';
const shortStr = (s, n) => s.length > n ? s.slice(0, n - 1).trimEnd() + '…' : s;
const dateStr = t => t ? new Date(t).toLocaleDateString(undefined, { day: 'numeric', month: 'short', year: 'numeric' }) : '—';
function ago(t) {
  if (!t) return '';
  const m = Math.round((Date.now() - t) / 60000);
  if (m < 1) return 'just now';
  if (m < 60) return m + ' min ago';
  const h = Math.round(m / 60);
  if (h < 24) return h + ' h ago';
  const d = Math.round(h / 24);
  return d < 30 ? d + ' d ago' : dateStr(t);
}

/* ---- toast ---- */
let toastT;
function toast(msg, ms = 2400) {
  const t = $('#toast');
  t.textContent = msg;
  t.classList.add('on');
  clearTimeout(toastT);
  toastT = setTimeout(() => t.classList.remove('on'), ms);
}

/* ---- bottom sheet ---- */
const Sheet = {
  open(html, { title = '', onMount, cls = '' } = {}) {
    const w = $('#sheetwrap'), s = $('#sheet');
    s.className = 'sheet ' + cls;
    s.innerHTML = `<div class="grab"></div><div class="sh"><b>${esc(title)}</b><button class="ib soft" data-act="sheet-close" aria-label="Close">${ic('x', 18)}</button></div><div class="sb">${html}</div>`;
    w.hidden = false;
    requestAnimationFrame(() => w.classList.add('on'));
    this.onClose = null;
    onMount && onMount(s);
  },
  close() {
    const w = $('#sheetwrap');
    if (w.hidden) return false;
    w.classList.remove('on');
    setTimeout(() => { if (!w.classList.contains('on')) w.hidden = true; }, 200);
    const f = this.onClose; this.onClose = null; f && f();
    return true;
  },
  isOpen() { return !$('#sheetwrap').hidden && $('#sheetwrap').classList.contains('on'); },
  onClose: null,
};
function confirmBox(msg, okLabel = 'Yes', danger = false) {
  return new Promise(res => {
    let done = false;
    Sheet.open(`<p class="sm">${esc(msg)}</p><div class="row gap" style="margin-top:16px"><button class="btn" data-act="cf-no">Cancel</button><button class="btn ${danger ? 'danger' : 'pri'}" data-act="cf-yes">${esc(okLabel)}</button></div>`, {
      title: 'Please confirm',
      onMount: s => {
        s.addEventListener('click', e => {
          const b = e.target.closest('[data-act^=cf-]'); if (!b) return;
          done = true; res(b.dataset.act === 'cf-yes'); Sheet.close();
        });
      },
    });
    Sheet.onClose = () => { if (!done) res(false); };
  });
}

/* ---- generated covers (like the colourful letter covers on the shelf) ---- */
const COVERS = [['#8e2c4f', '#6d1f3d'], ['#8a6a14', '#6b4f08'], ['#5b49b8', '#3f2f94'], ['#146b4b', '#0d523a'], ['#b5472a', '#92341c'], ['#3a2d66', '#241a4a'], ['#1f6b6b', '#154f52'], ['#7a2b5c', '#5a1c44']];
function hashStr(s) { let h = 0; for (const c of s) h = (h * 31 + c.charCodeAt(0)) | 0; return Math.abs(h); }
function coverHTML(b, cls = '') {
  if (b.cover) return `<div class="cv img ${cls}"><img src="${b.cover}" alt=""></div>`;
  const [a, d] = COVERS[hashStr(b.title || 'x') % COVERS.length];
  const L = ((b.title || '').match(/[A-Za-z0-9]/) || ['N'])[0].toUpperCase();
  return `<div class="cv gen ${cls}" style="--c1:${a};--c2:${d}"><i class="cvl">${L}</i><span class="cvi">${ic('book', 22)}</span><b class="cvt">${esc(shortStr(b.title || 'Untitled', 46))}</b><em class="cva">${esc(shortStr(b.author || '', 28))}</em></div>`;
}

/* ---- settings ---- */
const ST = Object.assign({ size: 21, font: 'sans', lh: 'normal', theme: 'night' },
  (() => { try { return JSON.parse(localStorage.getItem('nr-settings')) || {}; } catch (e) { return {}; } })());
const saveST = () => { try { localStorage.setItem('nr-settings', JSON.stringify(ST)); } catch (e) { } };
