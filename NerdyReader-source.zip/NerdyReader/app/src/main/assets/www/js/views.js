'use strict';
/* ===== NerdyReader · screens ===== */
const NAV = [['home', 'home', 'Home'], ['library', 'grid', 'Library'], ['search', 'search', 'Search'], ['shelf', 'shelf', 'Shelf'], ['stats', 'chart', 'Stats'], ['about', 'user', 'About']];
const navStack = [];

function go(view, params = {}, replace = false) {
  const m = $('#main');
  if (!replace) navStack.push({ view: S.view, params: S.params, scroll: m.scrollTop });
  S.view = view; S.params = params;
  render();
  m.scrollTop = 0;
}
function goBack() {
  if (!navStack.length) return false;
  const p = navStack.pop();
  S.view = p.view; S.params = p.params;
  render();
  $('#main').scrollTop = p.scroll || 0;
  return true;
}

const pct = b => Math.round((b.progress || 0) * 100);
function whereText(b) {
  if (!b.pos) return b.format === 'pdf' ? `${b.count} pages` : `${b.count} part${b.count === 1 ? '' : 's'}`;
  if (b.format === 'pdf' && b.pos.page) return `Page ${b.pos.page} of ${b.count}`;
  if (b.pos.ch != null) return `Chapter ${b.pos.ch + 1} of ${b.count}`;
  return `${pct(b)}% read`;
}
const minsLeft = b => Math.max(1, Math.ceil(((b.words || 0) * (1 - (b.progress || 0))) / WPM));

function bookCard(b, opt = {}) {
  return `<a class="bk" data-act="open-book" data-id="${b.id}">${coverHTML(b)}<div class="bt">${esc(b.title)}</div><div class="ba">${esc(b.author || FMT[b.format])}</div>${opt.prog && b.progress > 0 ? `<div class="pbar"><i style="width:${pct(b)}%"></i></div>` : ''}</a>`;
}
function bookRow(b, extra = '') {
  return `<a class="brow" data-act="open-book" data-id="${b.id}">${coverHTML(b, 'sm')}<div class="bri"><b>${esc(b.title)}</b><small>${esc(b.author || 'Unknown author')} · ${FMT[b.format]}</small>${b.progress > 0 ? `<div class="pbar"><i style="width:${pct(b)}%"></i></div><small>${pct(b)}% · ${b.progress >= 1 ? 'finished' : whereText(b)}</small>` : '<small class="mute">Not started</small>'}${extra}</div>${ic('right', 18)}</a>`;
}

function sortBooks(list, how) {
  const a = [...list];
  const cmp = {
    new: (x, y) => y.added - x.added,
    read: (x, y) => (y.lastRead || 0) - (x.lastRead || 0),
    title: (x, y) => x.title.localeCompare(y.title),
    author: (x, y) => (x.author || '~').localeCompare(y.author || '~'),
    prog: (x, y) => (y.progress || 0) - (x.progress || 0),
  }[how] || (() => 0);
  return a.sort(cmp);
}

/* ---------- Home ---------- */
function vHome() {
  const all = bookList(), n = all.length, nd = Dev.items.length;
  const cur = sortBooks(all.filter(b => b.lastRead && b.progress < 1), 'read')[0];
  const recent = sortBooks(all.filter(b => b.lastRead), 'read').slice(0, 12);
  const saved = all.filter(b => b.saved).slice(0, 12);
  const ents = Dev.entries(), phone = ents.filter(e => e.it).sort((x, y) => y.mod - x.mod).slice(0, 14);
  const h = [`<form class="hsearch" data-act="home-search" onsubmit="return false">${ic('search', 19)}<input id="hq" type="search" enterkeyhint="search" placeholder="Search your documents" autocomplete="off"></form>
  ${cur ? `<a class="cont2" data-act="read" data-id="${cur.id}">${coverHTML(cur, 'xs')}<div class="c2t"><small>Continue reading</small><b>${esc(shortStr(cur.title, 40))}</b><span>${esc(cur.author ? shortStr(cur.author, 22) + ' · ' : '')}${whereText(cur)}</span><i class="c2p"><u style="width:${pct(cur)}%"></u></i></div><span class="c2r">Resume</span></a>` : ''}
  ${Dev.gate()}
  ${streakStrip()}
  <div class="pstrip" role="toolbar" aria-label="Shortcuts">
    <button class="pl2" data-act="tool-go" data-v="convert">${ic('swap', 17)}<span>Convert</span></button>
    <button class="pl2" data-act="tool-go" data-v="audio">${ic('phones', 17)}<span>Listen</span></button>
    <button class="pl2" data-act="nav" data-v="style">${ic('palette', 17)}<span>Style</span></button>
    <button class="pl2" data-act="nav" data-v="stats">${ic('cal', 17)}<span>Stats</span></button>
    <button class="pl2" data-act="nav" data-v="quotes">${ic('quote', 17)}<span>Quotes</span></button>
    <button class="pl2" data-act="surprise">${ic('shuffle', 17)}<span>Surprise me</span></button>
  </div>
  ${n ? Quotes.cardHTML() : ''}`];
  if (recent.length) h.push(`<div class="sechd"><h2>Recently read</h2><a data-act="lib-tab" data-v="recent">See all</a></div><div class="hs">${recent.map(b => bookCard(b, { prog: 1 })).join('')}</div>`);
  if (phone.length) h.push(`<div class="sechd"><h2>On this phone</h2><a data-act="nav" data-v="library">All ${nd}</a></div><div class="hs dhs">${phone.map(e => Dev.card(e, true)).join('')}</div>`);
  else if (n) h.push(`<div class="sechd"><h2>Latest added</h2><a data-act="lib-tab" data-v="all">See all</a></div><div class="hs">${sortBooks(all, 'new').slice(0, 12).map(b => bookCard(b)).join('')}</div>`);
  if (saved.length) h.push(`<div class="sechd"><h2>Saved</h2><a data-act="lib-tab" data-v="saved">See all</a></div><div class="hs">${saved.map(b => bookCard(b)).join('')}</div>`);
  return h.join('');
}

/* The library and the search results now live in device.js (they list the documents found on the phone). */

/* ---------- Search ---------- */
function vSearch() {
  return `<h1 class="pgt">Search</h1><p class="sub">Searches titles, authors and file names in your library.</p>
  <div class="sbox big">${ic('search', 20)}<input id="q" type="search" value="${esc(S.q)}" placeholder="Title, author or file name" autocomplete="off"></div>
  <div id="sres">${searchResults(S.q)}</div>`;
}

/* ---------- My shelf ---------- */
function vShelf() {
  const tab = S.shelf.tab, all = bookList();
  const T = (v, t, n) => `<button class="${tab === v ? 'on' : ''}" data-act="shelf-tab" data-v="${v}">${t}${n ? ` <small>${n}</small>` : ''}</button>`;
  const reading = sortBooks(all.filter(b => b.progress > 0 && b.progress < 1), 'read');
  const saved = sortBooks(all.filter(b => b.saved), 'new');
  const done = sortBooks(all.filter(b => b.progress >= 1), 'read');
  const bms = []; all.forEach(b => (b.bookmarks || []).forEach(m => bms.push({ b, m })));
  bms.sort((x, y) => y.m.t - x.m.t);
  let body = '';
  const empty = t => `<div class="card empty"><p>${t}</p></div>`;
  if (tab === 'reading') body = reading.length ? `<div class="rows">${reading.map(b => bookRow(b)).join('')}</div>` : empty('Nothing in progress. Open a book and it will appear here.');
  if (tab === 'saved') body = saved.length ? `<div class="rows">${saved.map(b => bookRow(b)).join('')}</div>` : empty('Tap <b>Save</b> on a book page to keep it here.');
  if (tab === 'done') body = done.length ? `<div class="rows">${done.map(b => bookRow(b)).join('')}</div>` : empty('Finished books show up here.');
  if (tab === 'marks') body = bms.length ? `<div class="rows">${bms.map(({ b, m }) => `<a class="brow" data-act="read-at" data-id="${b.id}" data-bm="${m.id}">${coverHTML(b, 'sm')}<div class="bri"><b>${esc(m.label)}</b><small>${esc(shortStr(b.title, 40))} · ${ago(m.t)}</small></div>${ic('bookmark', 18)}</a>`).join('')}</div>` : empty('Tap the bookmark icon while reading to mark a place.');
  return `<h1 class="pgt">My shelf</h1><p class="sub">Your reading life in one place.</p>
  <div class="seg">${T('reading', 'Reading', reading.length)}${T('saved', 'Saved', saved.length)}${T('done', 'Finished', done.length)}${T('marks', 'Bookmarks', bms.length)}</div>${body}`;
}

/* ---------- Book page ---------- */
function vBook() {
  const b = S.books.get(S.params.id);
  if (!b) return `<div class="card empty"><p>That book is no longer in your library.</p></div>`;
  const started = b.progress > 0 && b.progress < 1;
  const row = (k, v) => `<div class="kv"><span>${k}</span><b>${v}</b></div>`;
  const mins = Math.max(1, Math.round((b.words || 0) / WPM));
  const wordsTxt = b.words ? (mins >= 90 ? '~' + (mins / 60).toFixed(1) + ' h' : '~' + mins + ' min') : '';
  return `<nav class="crumb"><a data-act="nav" data-v="home">Home</a><span>/</span><a data-act="nav" data-v="library">Library</a><span>/</span><b>${esc(shortStr(b.title, 26))}</b></nav>
  <section class="bhero">
    <div class="bh1">${coverHTML(b, 'md')}<div class="bhi">
      <div class="tags"><span class="tag ac">${FMT[b.format]}</span><span class="tag">${sizeStr(b.size)}</span></div>
      <h1>${esc(b.title)}</h1><div class="by">${b.author ? 'by <b>' + esc(b.author) + '</b>' : '<span class="mute">Unknown author</span>'}</div>
    </div></div>
    <div class="stats"><span>${b.format === 'pdf' ? 'Pages' : 'Parts'} <b>${b.count}</b></span><span>Progress <b>${pct(b)}%</b></span>${wordsTxt ? `<span>Reading time <b>${wordsTxt}</b></span>` : ''}</div>
    ${b.progress > 0 ? `<div class="pbar lg"><i style="width:${pct(b)}%"></i></div>` : ''}
    <div class="acts"><button class="btn pri big" data-act="read" data-id="${b.id}">${ic('book', 20)} ${b.progress >= 1 ? 'Read again' : started ? 'Continue · ' + whereText(b) : 'Start reading'}</button>
    <button class="btn big ${b.saved ? 'on' : ''}" data-act="save" data-id="${b.id}">${icFill(b.saved ? 'bookmark' : 'bookmark', 18).replace('fill="currentColor"', b.saved ? 'fill="currentColor"' : 'fill="none"')} ${b.saved ? 'Saved' : 'Save'}</button>
    <button class="btn" data-act="tool-book" data-v="convert" data-id="${b.id}">${ic('swap', 16)} Convert</button>
    <button class="btn" data-act="tool-book" data-v="audio" data-id="${b.id}">${ic('phones', 16)} Audio</button>
    <button class="btn" data-act="edit" data-id="${b.id}">${ic('edit', 16)} Edit details</button>
    <button class="btn" data-act="remove" data-id="${b.id}">${ic('trash', 16)} Remove</button></div>
  </section>
  ${bookReadingCard(b)}
  ${b.desc ? `<section class="card"><h3>About this book</h3><p class="sm serif">${esc(shortStr(b.desc, 900))}</p></section>` : ''}
  <section class="card"><h3>Details</h3>${row('File', esc(shortStr(b.fileName, 34)))}${row('Format', FMT[b.format])}${row('Size', sizeStr(b.size))}${row('Added', dateStr(b.added))}${row('Last read', b.lastRead ? ago(b.lastRead) : 'Never')}${b.words ? row('Reading time', '~' + Math.max(1, Math.round(b.words / WPM / 60 * 10) / 10) + ' h') : ''}${(b.bookmarks || []).length ? row('Bookmarks', b.bookmarks.length) : ''}</section>`;
}

/* ---------- drawer ---------- */
function renderDrawer() {
  const items = [['home', 'Home'], ['library', 'Documents'], ['search', 'Search'], ['shelf', 'My shelf'], ['stats', 'Reading stats'], ['quotes', 'Quotes'], ['tools', 'Convert & listen'], ['style', 'Themes & sound'], ['about', 'About']];
  $('#drawer').innerHTML = `<div class="dh"><b>Menu</b><button class="ib soft" data-act="menu-close" aria-label="Close">${ic('x', 20)}</button></div>
  <div class="di">${items.map(([v, t]) => `<a data-act="nav" data-v="${v}">${t}</a>`).join('')}<a data-act="add">Add a file by hand</a></div>
  <div class="dl"><span>${ic('wifi', 18)} Works fully offline</span><b>No account</b></div>
  <p class="dsec">Help</p>
  <div class="dchips"><button data-act="help" data-v="formats">Supported files</button><button data-act="help" data-v="tips">Reading tips</button><button data-act="help" data-v="privacy">Privacy</button><button data-act="nav" data-v="about">About me</button></div>
  <div class="df"><button class="btn pri big" data-act="dev-scan">${ic('refresh', 18)} Find books on this phone</button></div>`;
}
const HELP = {
  formats: ['Supported files', `<p class="sm"><b>PDF</b> – scroll the original pages with pinch-to-zoom, or switch to reflowed text.</p><p class="sm"><b>EPUB</b> – chapters, images, contents list and covers.</p><p class="sm"><b>TXT, Markdown, HTML</b> – reflowed with your font, size and theme.</p><p class="sm"><b>DOCX</b> – headings, paragraphs, bold/italic and simple tables.</p><p class="sm"><b>Convert</b> any of these into PDF, Word, EPUB, text, Markdown, a web page, or an audio file.</p><p class="sm mute">Not supported yet: MOBI/AZW, DRM-protected books, and scanned-only PDFs in text mode.</p>`],
  tips: ['Reading tips', `<p class="sm">• Tap the page once to hide or show the bars.</p><p class="sm">• <b>Aa</b> changes text size, font, spacing, margins and page colour.</p><p class="sm">• The headphones button reads the page aloud.</p><p class="sm">• Tap the middle of the bottom bar to open contents and bookmarks.</p><p class="sm">• In a PDF, pinch to zoom, or use <b>Aa → Zoom</b>.</p><p class="sm">• The app remembers where you stopped in every book.</p>`],
  privacy: ['Privacy', `<p class="sm">NerdyReader has no internet permission. Your books, bookmarks and reading progress live only inside the app on this phone.</p><p class="sm">Uninstalling the app (or clearing its storage) removes the library, so keep your original files.</p>`],
};

/* ---------- render ---------- */
const VIEWS = { home: vHome, library: () => vLibrary(), search: vSearch, shelf: vShelf, book: vBook, about: () => vAbout(), tools: () => vTools(), style: () => vStyle(), stats: () => vStats(), quotes: () => vQuotes() };
function render() {
  const v = S.view;
  $('#main').innerHTML = (VIEWS[v] || vHome)();
  const active = v === 'book' ? 'library' : (v === 'tools' || v === 'style' || v === 'quotes') ? 'home' : v;
  $('#nav').innerHTML = NAV.map(([k, i, t]) => `<button class="${active === k ? 'on' : ''}" data-act="nav" data-v="${k}">${ic(i, 22)}<span>${t}</span></button>`).join('');
  document.body.dataset.view = v;
  if (v === 'about') abMount();
  if (v === 'style') styleMount();
  if (v === 'tools') toolsMount();
  if (v === 'home') Quotes.mount(); else clearTimeout(Quotes.tm);
  if (v === 'home' || v === 'library') Dev.observe();
  appBars();
}
function setBars(color, darkIcons) { AB && AB.setBars(color, darkIcons); }

/* ---------- book page: your reading of this book ---------- */
function bookReadingCard(b) {
  const bs = Track.bookStats(b.id), qn = Quotes.bank.filter(q => q.bookId === b.id).length;
  const row = (k, v) => `<div class="kv"><span>${k}</span><b>${v}</b></div>`;
  const stars = [1, 2, 3, 4, 5].map(n => `<button class="star ${(b.rating || 0) >= n ? 'on' : ''}" data-act="rate" data-id="${b.id}" data-v="${n}" aria-label="${n} stars">${icFill('star', 26).replace('fill="currentColor"', (b.rating || 0) >= n ? 'fill="currentColor"' : 'fill="none"')}</button>`).join('');
  return `<section class="card"><h3>Your reading</h3><div class="stars">${stars}</div>
    ${bs.s ? row('Time spent', fmtDur(bs.s)) + row('Pages read', bs.p) + row('Days read', bs.d) : '<p class="sm mute" style="margin:0 0 6px">Time and pages appear here once you read.</p>'}
    ${b.finished ? row('Finished', dateStr(b.finished)) : ''}
    <div class="row gap wrap" style="margin-top:12px">${b.progress >= 1 ? '' : `<button class="btn sm" data-act="mark-done" data-id="${b.id}">${ic('check', 15)} Mark finished</button>`}${b.progress > 0 ? `<button class="btn sm" data-act="reset-prog" data-id="${b.id}">${ic('refresh', 15)} Start over</button>` : ''}${qn ? `<button class="btn sm" data-act="bk-quotes" data-id="${b.id}">${ic('quote', 15)} ${qn} quotes</button>` : ''}</div></section>`;
}
ACT['rate'] = el => { const b = S.books.get(el.dataset.id), n = +el.dataset.v; b.rating = b.rating === n ? 0 : n; saveBook(b, true); const sc = $('#main').scrollTop; render(); $('#main').scrollTop = sc; };
ACT['mark-done'] = el => { const b = S.books.get(el.dataset.id); b.progress = 1; if (!b.finished) b.finished = Date.now(); saveBook(b, true); toast('Marked as finished 🎉'); render(); };
ACT['reset-prog'] = async el => { const b = S.books.get(el.dataset.id); if (await confirmBox('Start this book from page one again? Your reading stats stay.', 'Start over')) { b.progress = 0; b.pos = null; saveBook(b, true); render(); } };
ACT['bk-quotes'] = el => { Quotes.q2 = { f: el.dataset.id, q: '', n: 40 }; navTo('quotes'); };
ACT['lib-view'] = () => { ST.libview = ST.libview === 'list' ? 'grid' : 'list'; saveST(); render(); };
ACT['surprise'] = () => {
  const l = bookList().filter(b => b.progress < 1); if (!l.length) return toast('Add a book first');
  const b = l[Math.floor(Math.random() * l.length)]; toast('How about “' + shortStr(b.title, 30) + '”?'); go('book', { id: b.id });
};
