'use strict';
/* ===== NerdyReader · reading tracker, streaks, calendar and stats =====
   Everything is stored on the phone (localStorage "nr-log"):
     days[YYYY-MM-DD] = { s: seconds read, p: pages read, b: { bookId: [seconds, pages] }, ss: [ {t0,t1,id,s,p} ... ], g: goal reached }
   Time only counts while the reader is open, the screen is on and you touched it in the last 2.5 minutes.
   A page counts once per sitting, after it has been on screen for 3 seconds. */
const dkey = t => { const d = new Date(t); return d.getFullYear() + '-' + String(d.getMonth() + 1).padStart(2, '0') + '-' + String(d.getDate()).padStart(2, '0'); };
const fromKey = k => { const [y, m, d] = k.split('-').map(Number); return new Date(y, m - 1, d); };
const fmtDur = s => { s = Math.round(s); if (s < 60) return s + ' s'; const m = Math.round(s / 60); if (m < 60) return m + ' min'; const h = Math.floor(m / 60), r = m % 60; return h + ' h' + (r ? ' ' + r + ' m' : ''); };
const fmtMin = s => { const m = Math.round(s / 60); return m < 60 ? m + 'm' : Math.floor(m / 60) + 'h' + (m % 60 ? String(m % 60).padStart(2, '0') : ''); };
const clock = t => new Date(t).toLocaleTimeString(undefined, { hour: 'numeric', minute: '2-digit' });

const Track = {
  log: { v: 1, days: {} }, sess: null, timer: null, lastAct: 0, act: 0, seen: new Set(), cur: null, idle: 150000,

  load() {
    try { const l = JSON.parse(localStorage.getItem('nr-log')); if (l && l.days) this.log = l; } catch (e) { }
  },
  save() { try { localStorage.setItem('nr-log', JSON.stringify(this.log)); } catch (e) { } },
  day(k) { return this.log.days[k] || (this.log.days[k] = { s: 0, p: 0, b: {}, ss: [] }); },
  get(k) { return this.log.days[k] || null; },

  /* ---------- live session ---------- */
  start(b) {
    this.stop();
    const now = Date.now();
    this.sess = { id: b.id, s: 0, p: 0, dk: null, rec: null };
    this.seen = new Set(); this.cur = null; this.act = 0; this.lastAct = now;
    this.timer = setInterval(() => this.tick(), 1000);
  },
  touch() { this.lastAct = Date.now(); },
  tick() {
    if (!this.sess) return;
    if (document.hidden || Date.now() - this.lastAct > this.idle) return;
    this.act++;
    this.add(1, 0);
    if (this.act % 20 === 0) this.save();
    if (this.act % 15 === 0) this.deco();
  },
  add(sec, pages) {
    const s = this.sess; if (!s) return;
    const now = Date.now(), k = dkey(now), d = this.day(k);
    if (s.dk !== k) {                        // a new sitting, or the sitting crossed midnight
      s.dk = k; s.rec = { t0: now, t1: now, id: s.id, s: 0, p: 0 };
      d.ss.push(s.rec); if (d.ss.length > 80) d.ss.shift();
    }
    d.s += sec; d.p += pages;
    const bk = d.b[s.id] || (d.b[s.id] = [0, 0]); bk[0] += sec; bk[1] += pages;
    s.rec.s += sec; s.rec.p += pages; s.rec.t1 = now; s.s += sec; s.p += pages;
    this.goalCheck(d);
  },
  goalCheck(d) {
    if (d.g) return;
    const gm = ST.goalMin * 60, gp = ST.goalPages;
    if ((gm > 0 && d.s >= gm) || (gp > 0 && d.p >= gp)) {
      d.g = 1; this.save();
      const st = this.streak();
      toast(`Daily goal reached! 🔥 ${st.cur} day${st.cur === 1 ? '' : 's'} in a row`, 3600);
    }
  },
  page(keys) {                               // the pages on screen changed
    if (!this.sess) return;
    const k = keys.join('|');
    if (this.cur && this.cur.k === k) return;
    this.commitPage();
    this.cur = { k, keys, a: this.act };
  },
  commitPage() {
    const c = this.cur; this.cur = null;
    if (!c || !this.sess || this.act - c.a < 3) return;
    let n = 0; for (const x of c.keys) if (!this.seen.has(x)) { this.seen.add(x); n++; }
    if (n) this.add(0, n);
  },
  stop() {
    if (!this.sess) return;
    this.commitPage();
    clearInterval(this.timer); this.timer = null;
    const s = this.sess; this.sess = null;
    if (s.rec && s.rec.s < 5 && !s.rec.p) {  // an accidental open: drop the empty sitting
      const d = this.log.days[s.dk]; if (d) d.ss = d.ss.filter(x => x !== s.rec);
    }
    this.save();
  },
  flush() { if (this.sess) { this.commitPage(); this.save(); } },
  /* tiny "today" label in the reader footer */
  deco() {
    if (!this.sess || ST.showtime === false) return;
    const el = $('#rmeta'); if (!el) return;
    const d = this.get(dkey(Date.now()));
    el.textContent = el.textContent.replace(/ · ⏱ .*$/, '') + ' · ⏱ ' + fmtMin(d ? d.s : 0) + ' today';
  },

  /* ---------- numbers ---------- */
  isRead(d) { return !!d && (d.s >= 60 || d.p >= 2); },
  keys() { return Object.keys(this.log.days).sort(); },
  streak() {
    const d = new Date(); d.setHours(0, 0, 0, 0);
    const todayDone = this.isRead(this.get(dkey(d)));
    if (!todayDone) d.setDate(d.getDate() - 1);
    let cur = 0; while (this.isRead(this.get(dkey(d)))) { cur++; d.setDate(d.getDate() - 1); }
    let best = 0, run = 0, prev = null;
    for (const k of this.keys()) {
      if (!this.isRead(this.log.days[k])) continue;
      const dt = fromKey(k);
      run = prev && Math.round((dt - prev) / 864e5) === 1 ? run + 1 : 1;
      if (run > best) best = run; prev = dt;
    }
    return { cur, best: Math.max(best, cur), todayDone };
  },
  today() { return this.get(dkey(Date.now())) || { s: 0, p: 0, b: {}, ss: [] }; },
  sum(fromT, toT) {                           // totals for days between two timestamps (inclusive)
    const a = dkey(fromT), z = dkey(toT), o = { s: 0, p: 0, days: 0, sess: 0 };
    for (const k of this.keys()) if (k >= a && k <= z) { const d = this.log.days[k]; o.s += d.s; o.p += d.p; if (this.isRead(d)) o.days++; o.sess += d.ss.length; }
    return o;
  },
  totals() {
    const o = { s: 0, p: 0, days: 0, sess: 0, longest: 0, best: null, books: new Set(), hours: new Array(24).fill(0) };
    for (const k of this.keys()) {
      const d = this.log.days[k]; o.s += d.s; o.p += d.p; if (this.isRead(d)) o.days++;
      if (!o.best || d.s > o.best.s) o.best = { k, s: d.s, p: d.p };
      Object.keys(d.b).forEach(id => o.books.add(id));
      for (const r of d.ss) {
        o.sess++; if (r.s > o.longest) o.longest = r.s;
        // spread the sitting over the hours it covered
        const span = Math.max(1, r.t1 - r.t0); let t = r.t0;
        while (t < r.t1 || t === r.t0) {
          const hr = new Date(t).getHours(), next = Math.min(r.t1, new Date(t).setMinutes(60, 0, 0));
          o.hours[hr] += r.s * Math.max(1, next - t) / span;
          if (next <= t) break; t = next; if (r.t1 === r.t0) break;
        }
      }
    }
    return o;
  },
  bookStats(id) {
    let s = 0, p = 0, d = 0;
    for (const k of this.keys()) { const x = this.log.days[k].b[id]; if (x) { s += x[0]; p += x[1]; d++; } }
    return { s, p, d };
  },
  level(sec) {
    if (sec < 60) return sec > 0 ? 1 : 0;
    const g = Math.max(60, (ST.goalMin || 10) * 60);
    return sec < g * 0.5 ? 1 : sec < g ? 2 : sec < g * 2 ? 3 : 4;
  },
};

/* =============================== the Stats screen =============================== */
const MONTHS = ['January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December'];
function ringSVG(frac, size, stroke, inner) {
  const r = (size - stroke) / 2, c = 2 * Math.PI * r, f = clamp(frac, 0, 1);
  return `<div class="ring" style="width:${size}px;height:${size}px"><svg width="${size}" height="${size}" viewBox="0 0 ${size} ${size}"><circle cx="${size / 2}" cy="${size / 2}" r="${r}" class="rg0" stroke-width="${stroke}" fill="none"/><circle cx="${size / 2}" cy="${size / 2}" r="${r}" class="rg1" stroke-width="${stroke}" fill="none" stroke-linecap="round" stroke-dasharray="${c}" stroke-dashoffset="${c * (1 - f)}" transform="rotate(-90 ${size / 2} ${size / 2})"/></svg><div class="rgin">${inner}</div></div>`;
}
function goalFrac() {
  const t = Track.today(), a = ST.goalMin > 0 ? t.s / (ST.goalMin * 60) : null, b = ST.goalPages > 0 ? t.p / ST.goalPages : null;
  return a != null && b != null ? Math.max(a, b) : a != null ? a : b != null ? b : (t.s > 0 ? 1 : 0);
}

/* a compact strip for the Home screen */
function streakStrip() {
  const st = Track.streak(), t = Track.today(), f = goalFrac();
  const msg = st.todayDone ? (st.cur > 1 ? `${st.cur} days in a row. Keep it going!` : 'You read today. Nice start!') : st.cur ? `Read a little today to keep your ${st.cur}-day streak` : 'Read for a minute to start a streak';
  return `<a class="streak" data-act="nav" data-v="stats">${ringSVG(f, 58, 6, `<span class="fl ${st.todayDone ? 'lit' : ''}">${ic('flame', 22)}</span>`)}
    <div class="sti"><b><em>${st.cur}</em> day streak</b><small>${msg}</small><small class="stt">${fmtDur(t.s)} · ${t.p} page${t.p === 1 ? '' : 's'} today</small></div>${ic('right', 18)}</a>`;
}

function vStats() {
  const now = new Date(), st = Track.streak(), tot = Track.totals(), t = Track.today();
  if (!S.stats) S.stats = { y: now.getFullYear(), m: now.getMonth() };
  const { y, m } = S.stats;
  const gm = ST.goalMin, f = goalFrac();
  const hasData = Track.keys().length > 0;

  /* --- hero --- */
  const left = gm > 0 ? Math.max(0, Math.ceil(gm - t.s / 60)) : 0;
  const hero = `<section class="shero">
    <div class="shl"><span class="shk">${ic('flame', 18)} Reading streak</span><div class="shn"><em>${st.cur}</em><span>day${st.cur === 1 ? '' : 's'}</span></div>
    <p>${st.todayDone ? (st.cur > 1 ? 'Today is done. See you tomorrow!' : 'You read today. A streak begins!') : gm > 0 ? `${left} more minute${left === 1 ? '' : 's'} today keeps it alive.` : 'Read a little today to keep it alive.'}</p>
    <div class="shb"><span>${ic('award', 14)} Best ${st.best} day${st.best === 1 ? '' : 's'}</span></div></div>
    ${ringSVG(f, 112, 11, `<b>${fmtMin(t.s)}</b><small>${gm > 0 ? 'of ' + gm + 'm' : 'today'}</small>`)}
  </section>
  <div class="trow"><div class="tile"><small>Today</small><b>${fmtDur(t.s)}</b></div><div class="tile"><small>Pages today</small><b>${t.p}</b></div><div class="tile"><small>Sittings</small><b>${t.ss.length}</b></div></div>`;

  /* --- month calendar --- */
  const first = new Date(y, m, 1), nd = new Date(y, m + 1, 0).getDate(), lead = (first.getDay() + 6) % 7;   // Monday first
  const todayK = dkey(now);
  const run = new Set(); { const d = new Date(now); d.setHours(0, 0, 0, 0); if (!st.todayDone) d.setDate(d.getDate() - 1); for (let i = 0; i < st.cur; i++) { run.add(dkey(d)); d.setDate(d.getDate() - 1); } }
  const fin = new Set(bookList().filter(b => b.finished).map(b => dkey(b.finished)));
  let cells = '', mS = 0, mP = 0, mD = 0;
  for (let i = 0; i < lead; i++) cells += '<i class="cd empty"></i>';
  for (let d = 1; d <= nd; d++) {
    const k = y + '-' + String(m + 1).padStart(2, '0') + '-' + String(d).padStart(2, '0'), x = Track.get(k), lv = x ? Track.level(x.s) : 0;
    if (x) { mS += x.s; mP += x.p; if (Track.isRead(x)) mD++; }
    cells += `<button class="cd lv${lv} ${k === todayK ? 'today' : ''} ${run.has(k) ? 'sk' : ''} ${k > todayK ? 'fut' : ''}" data-act="st-day" data-k="${k}"><span>${d}</span>${x && x.s >= 30 ? `<small>${fmtMin(x.s)}</small>` : ''}${fin.has(k) ? `<u>${ic('star', 11)}</u>` : ''}</button>`;
  }
  const cal = `<section class="card calc"><div class="calh"><button class="ib soft" data-act="st-cal" data-d="-1" aria-label="Previous month">${ic('left', 18)}</button><h3>${MONTHS[m]} ${y}</h3><button class="ib soft" data-act="st-cal" data-d="1" aria-label="Next month">${ic('right', 18)}</button></div>
    <div class="cdw"><span>M</span><span>T</span><span>W</span><span>T</span><span>F</span><span>S</span><span>S</span></div><div class="cdg">${cells}</div>
    <div class="cleg"><span>Less</span><i class="lv0"></i><i class="lv1"></i><i class="lv2"></i><i class="lv3"></i><i class="lv4"></i><span>More</span><em>${ic('flame', 12)} streak &nbsp; ${ic('star', 12)} finished a book</em></div>
    <p class="sm mute csum">${mD ? `<b>${mD}</b> day${mD === 1 ? '' : 's'} read · <b>${fmtDur(mS)}</b> · <b>${mP}</b> pages` : 'No reading logged this month.'} <span class="xs">Tap a day for details.</span></p></section>`;

  /* --- last 7 days --- */
  const days7 = []; for (let i = 6; i >= 0; i--) { const d = new Date(now); d.setDate(d.getDate() - i); const k = dkey(d), x = Track.get(k); days7.push({ k, s: x ? x.s : 0, p: x ? x.p : 0, l: d.toLocaleDateString(undefined, { weekday: 'narrow' }), today: i === 0 }); }
  const mx = Math.max(...days7.map(d => d.s), (gm || 10) * 60, 1);
  const w7 = days7.reduce((a, d) => a + d.s, 0), w7p = days7.reduce((a, d) => a + d.p, 0);
  const bars = `<section class="card"><h3>This week</h3><p class="sm mute" style="margin:0 0 6px"><b>${fmtDur(w7)}</b> · <b>${w7p}</b> pages · avg ${fmtDur(w7 / 7)} a day</p>
    <div class="bars">${gm > 0 ? `<i class="gline" style="bottom:${(gm * 60 / mx) * 100}%"><em>goal</em></i>` : ''}${days7.map(d => `<button class="bar ${d.today ? 'today' : ''}" data-act="st-day" data-k="${d.k}"><span class="bv">${d.s ? fmtMin(d.s) : ''}</span><i style="height:${Math.max(d.s ? 6 : 2, d.s / mx * 100)}%" class="${gm > 0 && d.s >= gm * 60 ? 'hit' : ''}"></i><b>${d.l}</b></button>`).join('')}</div></section>`;

  /* --- heatmap, last 26 weeks --- */
  const hm = []; { const end = new Date(now); end.setHours(0, 0, 0, 0); const dow = (end.getDay() + 6) % 7; const start = new Date(end); start.setDate(start.getDate() - dow - 25 * 7);
    for (let i = 0; i < 26 * 7; i++) { const d = new Date(start); d.setDate(start.getDate() + i); const k = dkey(d), x = Track.get(k); hm.push(`<i class="lv${d > end ? 'x' : x ? Track.level(x.s) : 0}" title="${k}"></i>`); } }
  const heat = `<section class="card"><h3>Last 6 months</h3><div class="heat">${hm.join('')}</div></section>`;

  /* --- when you read --- */
  const hmax = Math.max(...tot.hours, 1), peak = tot.hours.indexOf(Math.max(...tot.hours));
  const hlab = h => (h % 12 || 12) + (h < 12 ? ' AM' : ' PM');
  const hours = `<section class="card"><h3>When you read</h3><p class="sm mute" style="margin:0 0 8px">${tot.s > 120 ? `You read most around <b>${hlab(peak)}</b>.` : 'Read a bit more and your favourite hour shows up here.'}</p>
    <div class="hbars">${tot.hours.map((v, h) => `<i style="height:${Math.max(3, v / hmax * 100)}%" class="${h === peak && tot.s > 120 ? 'pk' : ''}"></i>`).join('')}</div><div class="hax"><span>12 AM</span><span>6 AM</span><span>12 PM</span><span>6 PM</span><span>11 PM</span></div></section>`;

  /* --- totals --- */
  const finished = bookList().filter(b => b.progress >= 1).length;
  const avgS = tot.sess ? tot.s / tot.sess : 0, pph = tot.s > 300 ? Math.round(tot.p / (tot.s / 3600)) : 0;
  const kv = (a, b) => `<div class="kv"><span>${a}</span><b>${b}</b></div>`;
  const totals = `<section class="card"><h3>All time</h3>${kv('Time reading', fmtDur(tot.s))}${kv('Pages read', tot.p.toLocaleString())}${kv('Days read', tot.days)}${kv('Sittings', tot.sess)}${kv('Average sitting', tot.sess ? fmtDur(avgS) : '—')}${kv('Longest sitting', tot.longest ? fmtDur(tot.longest) : '—')}${kv('Reading speed', pph ? pph + ' pages / hour' : '—')}${kv('Best day', tot.best && tot.best.s ? `${dateStr(fromKey(tot.best.k))} · ${fmtDur(tot.best.s)}` : '—')}${kv('Books opened', tot.books.size)}${kv('Books finished', finished)}</section>`;

  /* --- top books --- */
  const tb = bookList().map(b => ({ b, ...Track.bookStats(b.id) })).filter(x => x.s > 0).sort((a, b) => b.s - a.s).slice(0, 6);
  const top = tb.length ? `<section class="card"><h3>Most-read books</h3><div class="rows inrows">${tb.map(x => `<a class="brow" data-act="open-book" data-id="${x.b.id}">${coverHTML(x.b, 'sm')}<div class="bri"><b>${esc(x.b.title)}</b><small>${fmtDur(x.s)} · ${x.p} pages · ${x.d} day${x.d === 1 ? '' : 's'}</small><div class="pbar"><i style="width:${Math.max(3, pct(x.b))}%"></i></div></div></a>`).join('')}</div></section>` : '';

  /* --- goals --- */
  const chip = (key, v, label) => `<button class="${ST[key] === v ? 'on' : ''}" data-act="goal-set" data-k="${key}" data-v="${v}">${label}</button>`;
  const goals = `<section class="card"><h3>Daily goal</h3><p class="sm mute" style="margin:0 0 4px">A day counts for your streak after 1 minute of reading. The ring fills toward your goal.</p>
    <div class="lbl">MINUTES A DAY</div><div class="seg3">${[0, 5, 10, 20, 30, 45, 60].map(v => chip('goalMin', v, v ? v + 'm' : 'Off')).join('')}</div>
    <div class="lbl">OR PAGES A DAY</div><div class="seg3">${[0, 5, 10, 20, 50].map(v => chip('goalPages', v, v ? v : 'Off')).join('')}</div>
    <div class="lbl">READER FOOTER</div><div class="seg3">${chip('showtime', true, 'Show time today')}${chip('showtime', false, 'Hide')}</div></section>`;

  /* --- achievements --- */
  const A = [
    ['flame', '3-day streak', st.best >= 3], ['flame', '7-day streak', st.best >= 7], ['flame', '30-day streak', st.best >= 30], ['flame', '100-day streak', st.best >= 100],
    ['clock', '1 hour read', tot.s >= 3600], ['clock', '10 hours', tot.s >= 36000], ['clock', '50 hours', tot.s >= 180000],
    ['file', '100 pages', tot.p >= 100], ['file', '1,000 pages', tot.p >= 1000],
    ['book', 'First book done', finished >= 1], ['book', '5 books done', finished >= 5], ['book', '10 books done', finished >= 10],
    ['moon', 'Night owl', tot.hours[23] + tot.hours[0] + tot.hours[1] + tot.hours[2] > 900], ['sun', 'Early bird', tot.hours[4] + tot.hours[5] + tot.hours[6] > 900],
  ];
  const got = A.filter(a => a[2]).length;
  const ach = `<section class="card"><h3>Badges <small class="mute">${got} of ${A.length}</small></h3><div class="badges">${A.map(([i, t, ok]) => `<div class="badge ${ok ? 'on' : ''}"><span>${ic(i, 22)}</span><b>${t}</b></div>`).join('')}</div></section>`;

  const tools = `<section class="card"><h3>Your data</h3><p class="sm mute" style="margin:0 0 10px">Your reading log never leaves this phone. Save a copy if you like.</p><div class="row gap"><button class="btn" data-act="st-export">${ic('dl', 16)} Save log</button><button class="btn danger" data-act="st-reset">${ic('trash', 16)} Reset stats</button></div></section>`;

  return `<h1 class="pgt">Reading stats</h1><p class="sub">Your streak, your calendar, your habit.</p>${hero}${!hasData ? `<div class="card empty"><p>Open any book and read. Time, pages and your streak are logged automatically.</p></div>` : ''}${cal}${bars}${heat}${hours}${totals}${top}${goals}${ach}${tools}`;
}

function dayDetail(k) {
  const d = Track.get(k), dt = fromKey(k), title = dt.toLocaleDateString(undefined, { weekday: 'long', day: 'numeric', month: 'long', year: 'numeric' });
  if (!d || (!d.s && !d.p)) return Sheet.open(`<p class="sm mute">Nothing logged on this day.</p>`, { title });
  const books = Object.entries(d.b).map(([id, v]) => ({ b: S.books.get(id), id, s: v[0], p: v[1] })).sort((a, b) => b.s - a.s);
  const sess = d.ss.slice().sort((a, b) => a.t0 - b.t0);
  const fin = bookList().filter(b => b.finished && dkey(b.finished) === k);
  Sheet.open(`<div class="trow" style="margin:0 0 12px"><div class="tile"><small>Time</small><b>${fmtDur(d.s)}</b></div><div class="tile"><small>Pages</small><b>${d.p}</b></div><div class="tile"><small>Sittings</small><b>${sess.length}</b></div></div>
    ${d.g ? `<div class="note" style="margin:0 0 12px">${ic('flame', 14)} Daily goal reached</div>` : ''}
    ${fin.length ? `<div class="note" style="margin:0 0 12px">${ic('star', 14)} Finished ${fin.map(b => '“' + esc(shortStr(b.title, 30)) + '”').join(', ')}</div>` : ''}
    <div class="lbl">BOOKS</div>${books.map(x => `<div class="dyrow">${x.b ? coverHTML(x.b, 'xs') : '<span style="width:36px"></span>'}<div><b>${esc(x.b ? shortStr(x.b.title, 40) : 'Removed book')}</b><small>${fmtDur(x.s)} · ${x.p} page${x.p === 1 ? '' : 's'}</small></div></div>`).join('')}
    <div class="lbl">SITTINGS</div>${sess.map(r => { const b = S.books.get(r.id); return `<div class="dyrow"><span class="dyt">${clock(r.t0)}</span><div><b>${fmtDur(r.s)} · ${r.p} page${r.p === 1 ? '' : 's'}</b><small>${esc(b ? shortStr(b.title, 36) : 'Removed book')} · until ${clock(r.t1)}</small></div></div>`; }).join('')}`, { title });
}

ACT['st-cal'] = el => { const s = S.stats; let m = s.m + +el.dataset.d, y = s.y; if (m < 0) { m = 11; y--; } if (m > 11) { m = 0; y++; } S.stats = { y, m }; const sc = $('#main').scrollTop; render(); $('#main').scrollTop = sc; };
ACT['st-day'] = el => dayDetail(el.dataset.k);
ACT['goal-set'] = el => {
  const k = el.dataset.k, v = el.dataset.v; ST[k] = v === 'true' ? true : v === 'false' ? false : +v; saveST();
  const sc = $('#main').scrollTop; render(); $('#main').scrollTop = sc;
};
ACT['st-export'] = async () => {
  const blob = new Blob([JSON.stringify({ app: 'NerdyReader', exported: new Date().toISOString(), log: Track.log, books: bookList().map(b => ({ id: b.id, title: b.title, author: b.author, finished: b.finished || null })) }, null, 1)], { type: 'application/json' });
  try { await saveBlob(blob, 'nerdyreader-reading-log.json', 'application/json', () => { }); } catch (e) { toast('Could not save the log'); }
};
ACT['st-reset'] = async () => {
  if (await confirmBox('Erase all reading time, pages and streak history? Your books are not touched.', 'Erase stats', true)) { Track.log = { v: 1, days: {} }; Track.save(); toast('Stats cleared'); render(); }
};
