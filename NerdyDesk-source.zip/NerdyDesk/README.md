# NerdyDesk 2.0 — a full PC desktop for your phone  (@NerdyIntruder)

Set it as your Home app (Settings → Make NerdyDesk my Home app) and your phone becomes a desktop.

## What's inside
- **Windows-style boot** (bright bloom, logo, orbit spinner, @NerdyIntruder) + lock screen
- **Window manager**: drag, resize, snap (halves / quarters / maximise), snap preview, 4 virtual desktops, Task View, Alt+Tab, minimise/restore animations
- **Taskbar** (Windows 11 centred or Windows 10 left), pin/unpin any app, jump lists, tray with quick settings, calendar flyout, show-desktop
- **Start menu**: pinned apps, all apps A–Z, recent, search apps + files + web + instant calculator, power menu
- **Widgets panel** (Win+W): clock, weather, markets, quick note, quick launch
- **Run box** (Win+R), right-click desktop menu, light/dark theme, 8 accents, 8 wallpapers (animated option) or your own picture
- **Built-in apps**: File Explorer, **Nerdy Browser** (NerdyBrowser's full shield, tabs, split view, desktop sites, reader mode, find, bookmarks, history, workspaces, downloads, print/PDF, screenshots, shortcuts), Photos (viewer, editor, slideshow, EXIF), Video Player (subtitles, speed, A-B loop, resume), Music (visualiser, EQ, lyrics, playlists), Notepad, Calculator (standard / scientific / hex), Terminal (real shell), Paint, Calendar & Clock (world clocks, market sessions, stopwatch, timer), Weather, **Trade Desk** (live Nifty/BankNifty/BTC/ETH, risk calculator, journal, pre-trade checklist), Task Manager (performance, windows, phone apps), Settings
- **Phone apps**: launch any installed app from Start/taskbar; with "floating windows" on, they open as windows on phones that support freeform mode

## Build
Put `NerdyDesk-source.zip` and `build-apk.yml` (as `.github/workflows/build-apk.yml`) in your GitHub repo like NerdyReader. The APK appears under Releases → latest.
The APK is now signed with a fixed key, so later updates install over this one without losing settings.
(Uninstall the very first NerdyDesk once — it was signed with a different key.)
