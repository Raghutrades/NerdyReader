package com.nerdyintruder.nerdyreader;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.ActivityNotFoundException;
import android.content.ClipData;
import android.content.Intent;
import android.database.Cursor;
import android.graphics.Color;
import android.net.Uri;
import android.os.Bundle;
import android.provider.OpenableColumns;
import android.speech.tts.TextToSpeech;
import android.speech.tts.UtteranceProgressListener;
import android.speech.tts.Voice;
import android.util.Base64;
import android.view.View;
import android.view.WindowManager;
import android.webkit.JavascriptInterface;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;

import androidx.webkit.WebViewAssetLoader;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.RandomAccessFile;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.UUID;
import java.util.concurrent.CancellationException;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.TimeUnit;

/**
 * NerdyReader shell. The whole reader (library, PDF / EPUB / text rendering, About page)
 * is a local web app in assets/www, served from a virtual https origin so it never needs
 * the network. This class only does what a web page cannot:
 *   - show the system file picker,
 *   - receive files from "Open with" / "Share",
 *   - tint the system bars and keep the screen awake while reading,
 *   - read text aloud with Android's own text-to-speech and write it to a .wav file,
 *   - save converted files through the system "Save as" dialog.
 */
public class MainActivity extends Activity {

    private static final int REQ_PICK = 4411;
    private static final int REQ_SAVE = 4412;
    private static final String HOST = "appassets.androidplatform.net";

    private WebView web;
    private ValueCallback<Uri[]> pickCallback;
    private final Map<String, Uri> shared = new ConcurrentHashMap<>();
    private final List<JSONObject> pending = new ArrayList<>();

    // text-to-speech
    private TextToSpeech tts;
    private volatile boolean ttsOk;
    private String voiceNow = "";
    private volatile boolean exporting;
    private volatile boolean exportCancel;
    private final Map<String, CountDownLatch> synthLatches = new ConcurrentHashMap<>();
    private final Map<String, Boolean> synthFailed = new ConcurrentHashMap<>();

    // a finished file waiting for the "Save as" dialog
    private File saveFile;
    private String saveName = "file";
    private String saveMime = "application/octet-stream";
    private FileOutputStream saveOut;
    private String saveError;

    @SuppressLint({"SetJavaScriptEnabled", "AddJavascriptInterface"})
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        web = new WebView(this);
        web.setBackgroundColor(Color.parseColor("#FFF7F0"));
        setContentView(web);

        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setAllowFileAccess(false);
        s.setAllowContentAccess(false);
        s.setSupportZoom(false);
        s.setBuiltInZoomControls(false);
        s.setMediaPlaybackRequiresUserGesture(false); // the calm background music may start by itself
        s.setTextZoom(100); // the app does its own text sizing

        final WebViewAssetLoader loader = new WebViewAssetLoader.Builder()
                .setDomain(HOST)
                .addPathHandler("/assets/", new WebViewAssetLoader.AssetsPathHandler(this))
                .addPathHandler("/shared/", path -> {
                    Uri uri = shared.get(path);
                    if (uri == null) return null;
                    try {
                        InputStream in = getContentResolver().openInputStream(uri);
                        if (in == null) return null;
                        return new WebResourceResponse("application/octet-stream", null, in);
                    } catch (Exception e) {
                        return null;
                    }
                })
                .build();

        web.setWebViewClient(new WebViewClient() {
            @Override
            public WebResourceResponse shouldInterceptRequest(WebView view, WebResourceRequest request) {
                return loader.shouldInterceptRequest(request.getUrl());
            }

            @Override
            public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                Uri u = request.getUrl();
                if (HOST.equals(u.getHost())) return false;
                try {
                    startActivity(new Intent(Intent.ACTION_VIEW, u));
                } catch (ActivityNotFoundException ignored) {
                }
                return true;
            }
        });

        web.setWebChromeClient(new WebChromeClient() {
            @Override
            public boolean onShowFileChooser(WebView view, ValueCallback<Uri[]> cb,
                                             FileChooserParams params) {
                if (pickCallback != null) pickCallback.onReceiveValue(null);
                pickCallback = cb;
                Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT);
                i.addCategory(Intent.CATEGORY_OPENABLE);
                i.setType("*/*");
                i.putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true);
                i.putExtra(Intent.EXTRA_MIME_TYPES, new String[]{
                        "application/pdf",
                        "application/epub+zip",
                        "text/*",
                        "application/xhtml+xml",
                        "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
                        "application/octet-stream"
                });
                try {
                    startActivityForResult(i, REQ_PICK);
                } catch (Exception e) {
                    pickCallback = null;
                    cb.onReceiveValue(null);
                    return false;
                }
                return true;
            }
        });

        web.addJavascriptInterface(new Bridge(), "NerdyBridge");

        collect(getIntent());
        web.loadUrl("https://" + HOST + "/assets/www/index.html");
    }

    @Override
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        setIntent(intent);
        collect(intent);
        web.evaluateJavascript("window.nrIncoming&&window.nrIncoming()", null);
    }

    @Override
    protected void onActivityResult(int req, int res, Intent data) {
        super.onActivityResult(req, res, data);
        if (req == REQ_SAVE) { finishSave(res, data); return; }
        if (req != REQ_PICK || pickCallback == null) return;
        Uri[] out = null;
        if (res == RESULT_OK && data != null) {
            ClipData clip = data.getClipData();
            if (clip != null) {
                out = new Uri[clip.getItemCount()];
                for (int i = 0; i < out.length; i++) out[i] = clip.getItemAt(i).getUri();
            } else if (data.getData() != null) {
                out = new Uri[]{data.getData()};
            }
        }
        pickCallback.onReceiveValue(out);
        pickCallback = null;
    }

    @Override
    public void onBackPressed() {
        web.evaluateJavascript("(window.nrBack&&window.nrBack())?'1':'0'", v -> {
            if (!"\"1\"".equals(v)) finish();
        });
    }

    @Override
    protected void onPause() {
        super.onPause();
        web.evaluateJavascript("window.nrPause&&window.nrPause()", null);
    }

    @Override
    protected void onResume() {
        super.onResume();
        web.evaluateJavascript("window.nrResume&&window.nrResume()", null);
    }

    @Override
    protected void onDestroy() {
        exportCancel = true;
        if (tts != null) {
            try { tts.stop(); tts.shutdown(); } catch (Exception ignored) { }
            tts = null;
        }
        super.onDestroy();
    }

    /** Pull file URIs out of VIEW / SEND intents and queue them for the page. */
    private void collect(Intent intent) {
        if (intent == null) return;
        String action = intent.getAction();
        List<Uri> uris = new ArrayList<>();
        if (Intent.ACTION_VIEW.equals(action) && intent.getData() != null) {
            uris.add(intent.getData());
        } else if (Intent.ACTION_SEND.equals(action)) {
            Uri u = intent.getParcelableExtra(Intent.EXTRA_STREAM);
            if (u != null) uris.add(u);
        } else if (Intent.ACTION_SEND_MULTIPLE.equals(action)) {
            ArrayList<Uri> l = intent.getParcelableArrayListExtra(Intent.EXTRA_STREAM);
            if (l != null) uris.addAll(l);
        }
        for (Uri u : uris) {
            try {
                String id = UUID.randomUUID().toString().replace("-", "");
                shared.put(id, u);
                JSONObject o = new JSONObject();
                o.put("id", id);
                o.put("name", displayName(u));
                String t = getContentResolver().getType(u);
                o.put("mime", t == null ? "" : t);
                synchronized (pending) {
                    pending.add(o);
                }
            } catch (Exception ignored) {
            }
        }
        // Don't re-import the same file when the activity is recreated.
        if (!uris.isEmpty()) intent.setAction(Intent.ACTION_MAIN);
    }

    private String displayName(Uri u) {
        String name = null;
        if ("content".equals(u.getScheme())) {
            try (Cursor c = getContentResolver().query(u, null, null, null, null)) {
                if (c != null && c.moveToFirst()) {
                    int ix = c.getColumnIndex(OpenableColumns.DISPLAY_NAME);
                    if (ix >= 0) name = c.getString(ix);
                }
            } catch (Exception ignored) {
            }
        }
        if (name == null || name.isEmpty()) {
            String p = u.getLastPathSegment();
            name = p == null ? "book" : p.substring(p.lastIndexOf('/') + 1);
        }
        return name;
    }


    /* ===================== messages to the web page ===================== */

    private void js(JSONObject o) {
        final String code = "window.nrNative&&window.nrNative(" + o.toString() + ")";
        runOnUiThread(() -> { if (web != null) web.evaluateJavascript(code, null); });
    }

    private void jsSaved(boolean ok, String name, String error) {
        try {
            JSONObject o = new JSONObject();
            o.put("e", "saved");
            o.put("ok", ok);
            o.put("name", name == null ? "" : name);
            if (error != null) o.put("error", error);
            js(o);
        } catch (Exception ignored) { }
    }

    /* ===================== "Save as" dialog ===================== */

    private void startSave(File f, String name, String mime) {
        saveFile = f; saveName = name; saveMime = mime;
        runOnUiThread(() -> {
            try {
                Intent i = new Intent(Intent.ACTION_CREATE_DOCUMENT);
                i.addCategory(Intent.CATEGORY_OPENABLE);
                i.setType(saveMime);
                i.putExtra(Intent.EXTRA_TITLE, saveName);
                startActivityForResult(i, REQ_SAVE);
            } catch (Exception e) {
                if (saveFile != null) saveFile.delete();
                saveFile = null;
                jsSaved(false, saveName, "Could not open the Save dialog");
            }
        });
    }

    private void finishSave(int res, Intent data) {
        final File f = saveFile;
        saveFile = null;
        if (f == null) return;
        if (res != RESULT_OK || data == null || data.getData() == null) {
            f.delete();
            jsSaved(false, saveName, "Not saved");
            return;
        }
        final Uri u = data.getData();
        new Thread(() -> {
            try (InputStream in = new FileInputStream(f);
                 OutputStream out = getContentResolver().openOutputStream(u, "w")) {
                if (out == null) throw new IOException("Cannot write there");
                byte[] buf = new byte[65536];
                int n;
                while ((n = in.read(buf)) > 0) out.write(buf, 0, n);
                out.flush();
                jsSaved(true, displayName(u), null);
            } catch (Exception e) {
                jsSaved(false, saveName, "Could not save: " + e.getMessage());
            } finally {
                f.delete();
            }
        }, "nr-save").start();
    }

    /* ===================== text to speech ===================== */

    private void initTts() {
        if (tts != null) { notifyReady(ttsOk); return; }
        tts = new TextToSpeech(getApplicationContext(), status -> {
            ttsOk = status == TextToSpeech.SUCCESS;
            if (ttsOk && tts != null) {
                tts.setOnUtteranceProgressListener(new UtteranceProgressListener() {
                    @Override public void onStart(String id) { ttsEvent("start", id); }
                    @Override public void onDone(String id) { ttsEvent("done", id); }
                    @Override public void onError(String id) { ttsEvent("error", id); }
                });
                try { tts.setLanguage(Locale.getDefault()); } catch (Exception ignored) { }
            } else if (tts != null) {
                try { tts.shutdown(); } catch (Exception ignored) { }
                tts = null;
            }
            notifyReady(ttsOk);
        });
    }

    private void notifyReady(boolean ok) {
        try {
            JSONObject o = new JSONObject();
            o.put("e", "ready");
            o.put("ok", ok);
            js(o);
        } catch (Exception ignored) { }
    }

    private void ttsEvent(String kind, String id) {
        if (id != null && id.startsWith("syn:")) {          // pieces of an audio export
            if ("done".equals(kind) || "error".equals(kind)) {
                if ("error".equals(kind)) synthFailed.put(id, Boolean.TRUE);
                CountDownLatch l = synthLatches.get(id);
                if (l != null) l.countDown();
            }
            return;
        }
        try {
            JSONObject o = new JSONObject();
            o.put("e", "tts");
            o.put("k", kind);
            o.put("id", id);
            js(o);
        } catch (Exception ignored) { }
    }

    private void applyVoice(float rate, String voice) {
        TextToSpeech t = tts;
        if (t == null) return;
        t.setSpeechRate(Math.max(0.3f, Math.min(3f, rate)));
        if (voice == null) voice = "";
        if (!voice.equals(voiceNow)) {
            if (!voice.isEmpty()) {
                try {
                    Set<Voice> all = t.getVoices();
                    if (all != null) for (Voice v : all) if (voice.equals(v.getName())) { t.setVoice(v); break; }
                } catch (Exception ignored) { }
            }
            voiceNow = voice;
        }
    }

    /* ===================== audio export ===================== */

    private static final class WavInfo { long offset, length; int hz, ch, bits; }

    private WavInfo readWav(File f) throws IOException {
        try (RandomAccessFile r = new RandomAccessFile(f, "r")) {
            long size = r.length();
            if (size < 44) return null;
            byte[] riff = new byte[12];
            r.readFully(riff);
            if (riff[0] != 'R' || riff[1] != 'I' || riff[2] != 'F' || riff[3] != 'F') return null;
            WavInfo w = new WavInfo();
            boolean gotFmt = false;
            long pos = 12;
            while (pos + 8 <= size) {
                r.seek(pos);
                byte[] hd = new byte[8];
                r.readFully(hd);
                String id = new String(hd, 0, 4, StandardCharsets.US_ASCII);
                long len = (hd[4] & 0xFFL) | ((hd[5] & 0xFFL) << 8) | ((hd[6] & 0xFFL) << 16) | ((hd[7] & 0xFFL) << 24);
                if (id.equals("fmt ")) {
                    byte[] b = new byte[16];
                    r.readFully(b);
                    w.ch = (b[2] & 0xFF) | ((b[3] & 0xFF) << 8);
                    w.hz = (b[4] & 0xFF) | ((b[5] & 0xFF) << 8) | ((b[6] & 0xFF) << 16) | ((b[7] & 0xFF) << 24);
                    w.bits = (b[14] & 0xFF) | ((b[15] & 0xFF) << 8);
                    gotFmt = true;
                } else if (id.equals("data")) {
                    w.offset = pos + 8;
                    long avail = size - w.offset;
                    w.length = (len == 0 || len > avail) ? avail : len;
                    return gotFmt ? w : null;
                }
                pos += 8 + len + (len & 1);
            }
            return null;
        }
    }

    private long copyRange(File src, long off, long len, RandomAccessFile dst) throws IOException {
        try (RandomAccessFile in = new RandomAccessFile(src, "r")) {
            in.seek(off);
            byte[] buf = new byte[65536];
            long left = len;
            while (left > 0) {
                int n = in.read(buf, 0, (int) Math.min(buf.length, left));
                if (n < 0) break;
                dst.write(buf, 0, n);
                left -= n;
            }
            return len - left;
        }
    }

    private long writeSilence(RandomAccessFile dst, int hz, int ch, int ms) throws IOException {
        int frame = Math.max(1, ch) * 2;
        long bytes = (long) hz * frame * ms / 1000;
        bytes -= bytes % frame;
        byte[] zeros = new byte[16384];
        long left = bytes;
        while (left > 0) {
            int n = (int) Math.min(zeros.length, left);
            dst.write(zeros, 0, n);
            left -= n;
        }
        return bytes;
    }

    private void writeWavHeader(RandomAccessFile f, int hz, int ch, int bits, long dataLen) throws IOException {
        ByteBuffer b = ByteBuffer.allocate(44).order(ByteOrder.LITTLE_ENDIAN);
        b.put("RIFF".getBytes(StandardCharsets.US_ASCII));
        b.putInt((int) (36 + dataLen));
        b.put("WAVE".getBytes(StandardCharsets.US_ASCII));
        b.put("fmt ".getBytes(StandardCharsets.US_ASCII));
        b.putInt(16);
        b.putShort((short) 1);
        b.putShort((short) ch);
        b.putInt(hz);
        b.putInt(hz * ch * bits / 8);
        b.putShort((short) (ch * bits / 8));
        b.putShort((short) bits);
        b.put("data".getBytes(StandardCharsets.US_ASCII));
        b.putInt((int) dataLen);
        f.seek(0);
        f.write(b.array());
    }

    /** Cut the text into pieces the voice can take in one go. An empty string marks a longer pause. */
    private List<String> splitForTts(String text) {
        List<String> out = new ArrayList<>();
        final int max = 1500;
        for (String line : text.replace("\r", "").split("\n", -1)) {
            String t = line.trim();
            if (t.isEmpty()) {
                if (!out.isEmpty() && !out.get(out.size() - 1).isEmpty()) out.add("");
                continue;
            }
            while (t.length() > max) {
                int cut = -1;
                for (String sep : new String[]{". ", "? ", "! ", "; ", ", ", " "}) {
                    cut = t.lastIndexOf(sep, max - 1);
                    if (cut > 200) break;
                    cut = -1;
                }
                if (cut < 0) cut = max - 1;
                out.add(t.substring(0, cut + 1).trim());
                t = t.substring(cut + 1).trim();
            }
            if (!t.isEmpty()) out.add(t);
        }
        return out;
    }

    private void exportProgress(float p, String msg) {
        try {
            JSONObject o = new JSONObject();
            o.put("e", "exp");
            o.put("p", p);
            o.put("msg", msg);
            js(o);
        } catch (Exception ignored) { }
    }

    private void runExport(String name, String text, float rate, String voice) {
        File out = new File(getCacheDir(), "audio-export.wav");
        RandomAccessFile raf = null;
        File tmp = null;
        boolean handedOver = false;
        try {
            applyVoice(rate, voice);
            List<String> chunks = splitForTts(text);
            raf = new RandomAccessFile(out, "rw");
            raf.setLength(0);
            raf.write(new byte[44]);
            int hz = 0, ch = 0, bits = 16;
            long dataLen = 0;
            int n = chunks.size();
            for (int i = 0; i < n; i++) {
                if (exportCancel) throw new CancellationException();
                String c = chunks.get(i);
                if (c.isEmpty()) {
                    if (hz > 0) dataLen += writeSilence(raf, hz, ch, 700);
                    continue;
                }
                tmp = new File(getCacheDir(), "syn-" + i + ".wav");
                String id = "syn:" + i;
                CountDownLatch latch = new CountDownLatch(1);
                synthLatches.put(id, latch);
                synthFailed.remove(id);
                TextToSpeech t = tts;
                if (t == null) throw new IOException("The voice is not available any more");
                int r = t.synthesizeToFile(c, null, tmp, id);
                if (r != TextToSpeech.SUCCESS) throw new IOException("The voice could not start");
                boolean finished = latch.await(120, TimeUnit.SECONDS);
                synthLatches.remove(id);
                if (!finished) throw new IOException("The voice took too long");
                if (synthFailed.remove(id) != null) throw new IOException("The voice stopped with an error");
                WavInfo w = readWav(tmp);
                if (w != null && w.length > 0) {
                    if (hz == 0) { hz = w.hz; ch = w.ch; bits = w.bits; }
                    if (w.hz == hz && w.ch == ch && w.bits == bits) dataLen += copyRange(tmp, w.offset, w.length, raf);
                    dataLen += writeSilence(raf, hz, ch, 350);
                }
                tmp.delete();
                tmp = null;
                if (dataLen > 3_900_000_000L) throw new IOException("That is too long for one file. Pick fewer chapters.");
                exportProgress(0.97f * (i + 1) / n, "Making audio… part " + (i + 1) + " of " + n);
            }
            if (dataLen == 0 || hz == 0) throw new IOException("No sound was made. Check the voice in Android's text-to-speech settings.");
            writeWavHeader(raf, hz, ch, bits, dataLen);
            raf.close();
            raf = null;
            exportProgress(0.99f, "Choose where to save…");
            handedOver = true;
            startSave(out, name + ".wav", "audio/wav");
        } catch (CancellationException e) {
            jsSaved(false, name, "Cancelled");
        } catch (Exception e) {
            jsSaved(false, name, e.getMessage() == null ? "Audio failed" : e.getMessage());
        } finally {
            exporting = false;
            exportCancel = false;
            try { if (raf != null) raf.close(); } catch (Exception ignored) { }
            if (tmp != null) tmp.delete();
            if (!handedOver) out.delete();
        }
    }

    /** Methods the web app can call as window.NerdyBridge.xxx() */
    private class Bridge {
        @JavascriptInterface
        public String takePending() {
            synchronized (pending) {
                if (pending.isEmpty()) return "";
                JSONArray a = new JSONArray();
                for (JSONObject o : pending) a.put(o);
                pending.clear();
                return a.toString();
            }
        }

        @JavascriptInterface
        public void setBars(final String color, final boolean darkIcons) {
            runOnUiThread(() -> {
                try {
                    int c = Color.parseColor(color);
                    getWindow().setStatusBarColor(c);
                    getWindow().setNavigationBarColor(c);
                    int f = web.getSystemUiVisibility();
                    if (darkIcons) {
                        f |= View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR | View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR;
                    } else {
                        f &= ~(View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR | View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR);
                    }
                    web.setSystemUiVisibility(f);
                } catch (Exception ignored) {
                }
            });
        }

        @JavascriptInterface
        public void keepScreenOn(final boolean on) {
            runOnUiThread(() -> {
                if (on) getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
                else getWindow().clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
            });
        }

        @JavascriptInterface
        public void toast(final String msg) {
            runOnUiThread(() -> Toast.makeText(MainActivity.this, msg, Toast.LENGTH_SHORT).show());
        }

        @JavascriptInterface
        public void exit() {
            runOnUiThread(MainActivity.this::finish);
        }

        /* ---------- saving files ---------- */
        @JavascriptInterface
        public void saveBegin(String name, String mime) {
            try {
                if (saveOut != null) { try { saveOut.close(); } catch (Exception ignored) { } }
                if (saveFile != null) saveFile.delete();
                saveFile = new File(getCacheDir(), "save-" + UUID.randomUUID().toString().replace("-", "") + ".tmp");
                saveOut = new FileOutputStream(saveFile);
                saveName = name;
                saveMime = mime;
                saveError = null;
            } catch (Exception e) {
                saveError = e.getMessage();
            }
        }

        @JavascriptInterface
        public void saveChunk(String base64) {
            if (saveOut == null) return;
            try {
                saveOut.write(Base64.decode(base64, Base64.DEFAULT));
            } catch (Exception e) {
                saveError = e.getMessage();
            }
        }

        @JavascriptInterface
        public void saveEnd() {
            try { if (saveOut != null) saveOut.close(); } catch (Exception e) { saveError = e.getMessage(); }
            saveOut = null;
            if (saveError != null || saveFile == null) {
                if (saveFile != null) saveFile.delete();
                saveFile = null;
                jsSaved(false, saveName, saveError == null ? "Nothing to save" : saveError);
                return;
            }
            startSave(saveFile, saveName, saveMime);
        }

        /* ---------- text to speech ---------- */
        @JavascriptInterface
        public boolean ttsAvailable() { return true; }

        @JavascriptInterface
        public void ttsInit() { runOnUiThread(MainActivity.this::initTts); }

        @JavascriptInterface
        public String ttsVoices() {
            JSONArray arr = new JSONArray();
            try {
                TextToSpeech t = tts;
                if (t == null || !ttsOk) return "[]";
                Set<Voice> set = t.getVoices();
                if (set == null) return "[]";
                final List<String[]> rows = new ArrayList<>();
                for (Voice v : set) {
                    if (v.isNetworkConnectionRequired()) continue;
                    Set<String> feats = v.getFeatures();
                    if (feats != null && feats.contains(TextToSpeech.Engine.KEY_FEATURE_NOT_INSTALLED)) continue;
                    rows.add(new String[]{v.getName(), v.getLocale().getDisplayName()});
                }
                Collections.sort(rows, new Comparator<String[]>() {
                    @Override public int compare(String[] a, String[] b) {
                        int c = a[1].compareTo(b[1]);
                        return c != 0 ? c : a[0].compareTo(b[0]);
                    }
                });
                Map<String, Integer> seen = new HashMap<>();
                Map<String, Integer> total = new HashMap<>();
                for (String[] r : rows) total.put(r[1], total.containsKey(r[1]) ? total.get(r[1]) + 1 : 1);
                for (String[] r : rows) {
                    int k = seen.containsKey(r[1]) ? seen.get(r[1]) + 1 : 1;
                    seen.put(r[1], k);
                    JSONObject o = new JSONObject();
                    o.put("name", r[0]);
                    o.put("label", total.get(r[1]) > 1 ? r[1] + " · voice " + k : r[1]);
                    arr.put(o);
                }
            } catch (Exception ignored) { }
            return arr.toString();
        }

        @JavascriptInterface
        public void ttsSpeak(String id, String text, double rate, String voice) {
            TextToSpeech t = tts;
            if (t == null || !ttsOk || exporting) return;
            applyVoice((float) rate, voice);
            t.speak(text, TextToSpeech.QUEUE_ADD, null, id);
        }

        @JavascriptInterface
        public void ttsStop() {
            TextToSpeech t = tts;
            if (t != null && !exporting) t.stop();
        }

        @JavascriptInterface
        public void ttsExport(final String name, final String text, final double rate, final String voice) {
            if (tts == null || !ttsOk) { jsSaved(false, name, "The voice is not ready yet. Open Listen once, then try again."); return; }
            if (exporting) return;
            exporting = true;
            exportCancel = false;
            new Thread(() -> runExport(name, text, (float) rate, voice), "nr-export").start();
        }

        @JavascriptInterface
        public void ttsExportCancel() { exportCancel = true; }
    }
}
