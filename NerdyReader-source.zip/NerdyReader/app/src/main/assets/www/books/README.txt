Put your PDFs here (the-false-green.pdf, ...) so About → My books → Add to library works.
