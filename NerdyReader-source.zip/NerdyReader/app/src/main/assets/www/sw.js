/* Offline cache for the web/PWA version (iPhone, desktop). Not used inside the Android app.
   Bump VERSION whenever the files change so installed copies update. */
const VERSION = 'nr-1.0.0';
const FILES = ['./', 'index.html', 'css/app.css', 'manifest.webmanifest',
  'js/util.js', 'js/db.js', 'js/parsers.js', 'js/importer.js', 'js/views.js', 'js/about.js', 'js/reader.js', 'js/tts.js', 'js/app.js',
  'lib/jszip.min.js', 'lib/pdf.min.js', 'lib/pdf.worker.min.js',
  'fonts/dm-sans-latin-400-normal.woff2', 'fonts/dm-sans-latin-500-normal.woff2', 'fonts/dm-sans-latin-700-normal.woff2',
  'fonts/source-serif-4-latin-400-normal.woff2', 'fonts/source-serif-4-latin-600-normal.woff2',
  'icons/icon-192.png', 'icons/icon-512.png', 'icons/apple-touch-icon.png'];
self.addEventListener('install', e => { e.waitUntil(caches.open(VERSION).then(c => c.addAll(FILES)).then(() => self.skipWaiting())); });
self.addEventListener('activate', e => { e.waitUntil(caches.keys().then(k => Promise.all(k.filter(x => x !== VERSION).map(x => caches.delete(x)))).then(() => self.clients.claim())); });
self.addEventListener('fetch', e => {
  if (e.request.method !== 'GET') return;
  e.respondWith(caches.match(e.request).then(hit => hit || fetch(e.request)));
});
