'use strict';
/* ===== NerdyReader · welcome animation =====
   A calm few seconds: a book opens, pages drift, little sparkles twinkle.
   Tap anywhere to skip. Turn it off in Themes & sound. */
const Splash = {
  el: null, timer: null, replaying: false,
  run(replay) {
    const el = this.el = $('#splash');
    if (!el) return;
    if (!replay && ST.splash === false) { el.remove(); return; }
    clearTimeout(this.timer);
    this.replaying = !!replay;
    el.hidden = false; el.classList.remove('out');
    // restart the CSS animations when replaying
    if (replay) { el.style.display = 'none'; void el.offsetWidth; el.style.display = ''; }
    const wait = replay ? 3400 : Math.max(900, 3300 - performance.now());
    this.timer = setTimeout(() => this.hide(), wait);
    if (replay && !Music.on) toast('Tip: turn Music on from the ♪ button');
  },
  hide() {
    const el = this.el;
    if (!el || el.classList.contains('out')) return;
    clearTimeout(this.timer);
    el.classList.add('out');
    setTimeout(() => { if (el.classList.contains('out')) { if (this.replaying) el.hidden = true; else el.remove(); } }, 800);
  },
};
document.addEventListener('click', e => { if (e.target.closest('#splash')) Splash.hide(); });
