package com.nerdy.desk

import android.annotation.SuppressLint
import android.app.DownloadManager
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.content.res.ColorStateList
import android.graphics.Bitmap
import android.graphics.Canvas
import android.net.Uri
import android.os.Environment
import android.print.PrintAttributes
import android.print.PrintManager
import android.text.Editable
import android.text.InputType
import android.text.TextWatcher
import android.view.Gravity
import android.view.KeyEvent
import android.view.View
import android.view.inputmethod.EditorInfo
import android.view.inputmethod.InputMethodManager
import android.webkit.CookieManager
import android.webkit.GeolocationPermissions
import android.webkit.PermissionRequest
import android.webkit.URLUtil
import android.webkit.ValueCallback
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebSettings
import android.webkit.WebStorage
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.HorizontalScrollView
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.PopupMenu
import android.widget.ProgressBar
import android.widget.TextView
import org.json.JSONArray
import org.json.JSONObject
import java.io.ByteArrayInputStream
import java.io.File
import java.net.URLEncoder
import java.util.Locale

/**
 * Nerdy Browser for the desktop: tabs, split view, ad & tracker shield, desktop sites, reader mode,
 * find in page, bookmarks, history, workspaces, downloads, print / PDF, screenshots and shortcuts.
 */
class BrowserApp(act: MainActivity, private val startUrl: String?) : App(act) {
    override val title = "Nerdy Browser"
    override val icon = "\uD83C\uDF10"

    private class Tab(val web: WebView, val incognito: Boolean) {
        var title = "New tab"
        var url = ""
        var icon: Bitmap? = null
        var pinned = false
        var blocked = 0
        var loading = false
        var dark = false
        var cell: LinearLayout? = null
        var label: TextView? = null
        val hostCounts = HashMap<String, Int>()
        var pendingHttp: String? = null
        var mobileUa = false
        var iv: ImageView? = null
    }

    companion object {
        private val blocker = Blocker()
        private var blockerReady = false
        private var injectTpl = ""
        const val DESKTOP_UA = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36"
        val engines = listOf(
            Pair("Google", "https://www.google.com/search?q="),
            Pair("DuckDuckGo", "https://duckduckgo.com/?q="),
            Pair("Brave", "https://search.brave.com/search?q="),
            Pair("Bing", "https://www.bing.com/search?q="),
            Pair("Startpage", "https://www.startpage.com/do/search?q=")
        )
    }

    private val tabs = ArrayList<Tab>()
    private var current: Tab? = null
    private var splitTab: Tab? = null
    private val closed = ArrayList<String>()
    private lateinit var tabStrip: LinearLayout
    private lateinit var address: EditText
    private lateinit var progress: ProgressBar
    private lateinit var holder: LinearLayout
    private lateinit var contentRow: LinearLayout
    private lateinit var side: LinearLayout
    private lateinit var sideList: LinearLayout
    private lateinit var sideSearch: EditText
    private lateinit var sideTitle: TextView
    private var sideMode = "bm"
    private lateinit var bmScroll: HorizontalScrollView
    private lateinit var bmBar: LinearLayout
    private lateinit var tabScroll: HorizontalScrollView
    private lateinit var toolbar: LinearLayout
    private lateinit var fsBtn: TextView
    private var fullscreen = false
    private lateinit var backBtn: TextView
    private lateinit var fwdBtn: TextView
    private lateinit var reloadBtn: TextView
    private lateinit var starBtn: TextView
    private lateinit var shieldBtn: TextView
    private lateinit var lockView: TextView
    private lateinit var findBar: LinearLayout
    private lateinit var findInput: EditText
    private lateinit var findCount: TextView
    private lateinit var suggest: LinearLayout
    private var desktopSite = true
    private var shield = true
    private var st = JSONObject()
    private val httpOk = HashSet<String>()

    private fun loadSt() {
        st = try { JSONObject(prefs().getString("st", "{}") ?: "{}") } catch (e: Exception) { JSONObject() }
        blocker.update(st)
        shield = st.optString("shield", "standard") != "off"
    }

    private fun saveSt() {
        prefs().edit().putString("st", st.toString()).apply()
        blocker.update(st)
        shield = st.optString("shield", "standard") != "off"
    }

    private fun stb(k: String, d: Boolean) = st.optBoolean(k, d)
    private fun ss(k: String, d: String) = st.optString(k, d)

    private fun isLocal(h: String?): Boolean {
        if (h == null) return true
        return h == "localhost" || h.startsWith("127.") || h.startsWith("10.") || h.startsWith("192.168.") ||
            Regex("172\\.(1[6-9]|2[0-9]|3[0-1])\\..*").matches(h) || h.endsWith(".local") || !h.contains('.')
    }

    /** The same clean-up NerdyBrowser does before a page loads: strip tracking parameters, upgrade to https. */
    private fun prep(t: Tab, url: String): String {
        val u = Uri.parse(url)
        val sc = (u.scheme ?: "").lowercase(Locale.ROOT)
        if (sc != "http" && sc != "https") return url
        if (u.host == Local.HOST) return url
        var out = url
        if (stb("stripParams", true)) out = Blocker.clean(out)
        if (sc == "http" && stb("httpsOnly", true) && !httpOk.contains(u.host ?: "") && !isLocal(u.host)) {
            t.pendingHttp = out
            out = "https" + out.substring(4)
        }
        return out
    }

    private fun gpcHeaders(): HashMap<String, String> {
        val h = HashMap<String, String>()
        if (stb("gpc", true)) { h["Sec-GPC"] = "1"; h["DNT"] = "1" }
        return h
    }

    private fun cookiePolicy(t: Tab, url: String) {
        var host = ""
        try { host = Uri.parse(url).host ?: "" } catch (e: Exception) {}
        val si = stb("signinCompat", true) && Blocker.isSignin(host)
        val app = blocker.isCompat(host)
        val mode = ss("cookies", "first")
        CookieManager.getInstance().setAcceptThirdPartyCookies(t.web, mode != "none" && (si || app || mode == "all"))
        t.web.settings.mediaPlaybackRequiresUserGesture = !app && stb("blockAutoplay", true)
    }

    private fun scriptFor(t: Tab): String {
        val c = JSONObject()
        c.put("spoof", stb("spoof", true)); c.put("rtc", stb("noWebrtc", true)); c.put("beacon", stb("noBeacon", true))
        c.put("gpc", stb("gpc", true)); c.put("ref", ss("referrer", "origin")); c.put("cosmetic", stb("cosmetic", true))
        c.put("consent", stb("consent", true)); c.put("forceZoom", stb("forceZoom", true)); c.put("yt", stb("videoAds", true))
        c.put("signin", stb("signinCompat", true)); c.put("compat", blocker.compatArray()); c.put("dw", 0)
        c.put("dark", t.dark)
        c.put("allow", st.optJSONArray("siteAllow") ?: JSONArray())
        c.put("hide", st.optJSONArray("hideSelectors") ?: JSONArray())
        return injectTpl.replace("__NB_CFG__", c.toString())
    }

    private fun prefs() = act.getSharedPreferences("nbrowser", Context.MODE_PRIVATE)

    // ================================================================= UI

    override fun build(): View {
        desktopSite = prefs().getBoolean("desktop", true)
        loadSt()
        if (injectTpl.isEmpty()) {
            try { injectTpl = act.assets.open("apps/browser/inject.js").bufferedReader().use { it.readText() } } catch (e: Exception) {}
        }
        if (!blockerReady) {
            blockerReady = true
            Thread { blocker.load(act.assets) }.start()
        }
        val frame = FrameLayout(act)
        val root = LinearLayout(act)
        root.orientation = LinearLayout.VERTICAL
        root.setBackgroundColor(Ui.bgDark)

        val scroll = HorizontalScrollView(act)
        scroll.isHorizontalScrollBarEnabled = false
        scroll.setBackgroundColor(Ui.side)
        tabStrip = LinearLayout(act)
        tabStrip.orientation = LinearLayout.HORIZONTAL
        tabStrip.gravity = Gravity.CENTER_VERTICAL
        scroll.addView(tabStrip, FrameLayout.LayoutParams(WRAP, MATCH))
        tabScroll = scroll
        root.addView(scroll, lp(MATCH, act.dp(38)))

        val bar = LinearLayout(act)
        bar.orientation = LinearLayout.HORIZONTAL
        bar.gravity = Gravity.CENTER_VERTICAL
        bar.setPadding(act.dp(6), act.dp(4), act.dp(6), act.dp(4))
        bar.setBackgroundColor(Ui.bar)
        backBtn = tool("\u2190") { current?.web?.let { if (it.canGoBack()) it.goBack() } }
        fwdBtn = tool("\u2192") { current?.web?.let { if (it.canGoForward()) it.goForward() } }
        reloadBtn = tool("\u27F3") { val t = current; if (t != null) { if (t.loading) t.web.stopLoading() else t.web.reload() } }
        val home = tool("\u2302") { current?.let { loadHome(it) } }
        bar.addView(tool("\u25A4") { toggleSide(null) }, lp(act.dp(34), act.dp(32)))
        bar.addView(backBtn, lp(act.dp(34), act.dp(32)))
        bar.addView(fwdBtn, lp(act.dp(34), act.dp(32)))
        bar.addView(reloadBtn, lp(act.dp(34), act.dp(32)))
        bar.addView(home, lp(act.dp(34), act.dp(32)))

        val addrBox = LinearLayout(act)
        addrBox.orientation = LinearLayout.HORIZONTAL
        addrBox.gravity = Gravity.CENTER_VERTICAL
        addrBox.background = Ui.rect(Ui.field, act.dp(17).toFloat(), Ui.border, 1)
        lockView = TextView(act)
        lockView.textSize = 12f
        lockView.setPadding(act.dp(12), 0, act.dp(4), 0)
        addrBox.addView(lockView, lp(WRAP, MATCH))
        address = EditText(act)
        address.inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_URI
        address.setSingleLine()
        address.textSize = 13.5f
        address.setTextColor(Ui.text)
        address.setHintTextColor(Ui.textDim)
        address.hint = "Search or enter address"
        address.background = null
        address.setPadding(act.dp(4), 0, act.dp(8), 0)
        address.imeOptions = EditorInfo.IME_ACTION_GO
        address.setOnEditorActionListener { v, id, ev ->
            if (id == EditorInfo.IME_ACTION_GO || (ev != null && ev.keyCode == KeyEvent.KEYCODE_ENTER && ev.action == KeyEvent.ACTION_DOWN)) {
                go(v.text.toString())
                true
            } else false
        }
        address.setOnFocusChangeListener { v, has ->
            if (has) (v as EditText).selectAll() else hideSuggest()
        }
        address.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
            override fun onTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
            override fun afterTextChanged(s: Editable?) {
                if (address.hasFocus()) showSuggest(s?.toString() ?: "")
            }
        })
        addrBox.addView(address, lp(0, MATCH, 1f))
        starBtn = TextView(act)
        starBtn.textSize = 16f
        starBtn.gravity = Gravity.CENTER
        starBtn.isClickable = true
        starBtn.setOnClickListener { toggleBookmark() }
        addrBox.addView(starBtn, lp(act.dp(34), MATCH))
        val al = lp(0, act.dp(32), 1f)
        al.setMargins(act.dp(4), 0, act.dp(4), 0)
        bar.addView(addrBox, al)
        shieldBtn = tool("\uD83D\uDEE1") { shieldMenu(it) }
        shieldBtn.textSize = 12f
        bar.addView(shieldBtn, lp(act.dp(52), act.dp(32)))
        bar.addView(tool("\u2630") { menu(it) }, lp(act.dp(34), act.dp(32)))
        toolbar = bar
        root.addView(bar, lp(MATCH, act.dp(40)))

        progress = ProgressBar(act, null, android.R.attr.progressBarStyleHorizontal)
        progress.max = 100
        progress.progressTintList = ColorStateList.valueOf(Ui.accent)
        progress.visibility = View.INVISIBLE
        root.addView(progress, lp(MATCH, act.dp(3)))

        bmScroll = HorizontalScrollView(act)
        bmScroll.isHorizontalScrollBarEnabled = false
        bmScroll.setBackgroundColor(Ui.bar)
        bmBar = LinearLayout(act)
        bmBar.orientation = LinearLayout.HORIZONTAL
        bmBar.gravity = Gravity.CENTER_VERTICAL
        bmBar.setPadding(act.dp(6), 0, act.dp(6), 0)
        bmScroll.addView(bmBar, FrameLayout.LayoutParams(WRAP, MATCH))
        root.addView(bmScroll, lp(MATCH, act.dp(32)))
        findBar = LinearLayout(act)
        findBar.orientation = LinearLayout.HORIZONTAL
        findBar.gravity = Gravity.CENTER_VERTICAL
        findBar.setBackgroundColor(Ui.bar)
        findBar.setPadding(act.dp(8), act.dp(3), act.dp(8), act.dp(3))
        findBar.visibility = View.GONE
        findInput = EditText(act)
        findInput.setSingleLine()
        findInput.textSize = 13f
        findInput.hint = "Find in page"
        findInput.setTextColor(Ui.text)
        findInput.setHintTextColor(Ui.textDim)
        findInput.background = Ui.rect(Ui.field, act.dp(8).toFloat(), Ui.border, 1)
        findInput.setPadding(act.dp(10), 0, act.dp(10), 0)
        findInput.imeOptions = EditorInfo.IME_ACTION_SEARCH
        findInput.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
            override fun onTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
            override fun afterTextChanged(s: Editable?) { current?.web?.findAllAsync(s?.toString() ?: "") }
        })
        findInput.setOnEditorActionListener { _, _, _ -> current?.web?.findNext(true); true }
        findBar.addView(findInput, lp(0, act.dp(30), 1f))
        findCount = TextView(act)
        findCount.textSize = 11f
        findCount.setTextColor(Ui.textDim)
        findCount.setPadding(act.dp(8), 0, act.dp(8), 0)
        findBar.addView(findCount)
        findBar.addView(tool("\u25B2") { current?.web?.findNext(false) }, lp(act.dp(32), act.dp(30)))
        findBar.addView(tool("\u25BC") { current?.web?.findNext(true) }, lp(act.dp(32), act.dp(30)))
        findBar.addView(tool("\u2715") { closeFind() }, lp(act.dp(32), act.dp(30)))
        root.addView(findBar, lp(MATCH, WRAP))

        holder = LinearLayout(act)
        holder.orientation = LinearLayout.HORIZONTAL
        contentRow = LinearLayout(act)
        contentRow.orientation = LinearLayout.HORIZONTAL
        side = buildSide()
        side.visibility = View.GONE
        contentRow.addView(side, lp(act.dp(290), MATCH))
        contentRow.addView(holder, lp(0, MATCH, 1f))
        root.addView(contentRow, lp(MATCH, 0, 1f))
        frame.addView(root, FrameLayout.LayoutParams(MATCH, MATCH))
        fsBtn = TextView(act)
        fsBtn.text = "\u2715  Exit full screen"
        fsBtn.textSize = 12f
        fsBtn.setTextColor(0xFFFFFFFF.toInt())
        fsBtn.setPadding(act.dp(14), act.dp(8), act.dp(14), act.dp(8))
        fsBtn.background = Ui.rect(0xB0000000.toInt(), act.dp(16).toFloat())
        fsBtn.visibility = View.GONE
        fsBtn.setOnClickListener { setFullscreen(false) }
        fsBtn.visibility = View.GONE
        val fl = FrameLayout.LayoutParams(WRAP, WRAP, Gravity.TOP or Gravity.END)
        fl.setMargins(0, act.dp(8), act.dp(10), 0)
        frame.addView(fsBtn, fl)
        peekBtn = TextView(act)
        peekBtn.textSize = 14f
        peekBtn.gravity = Gravity.CENTER
        peekBtn.setTextColor(0xFFFFFFFF.toInt())
        peekBtn.background = Ui.rect(0x99000000.toInt(), act.dp(11).toFloat())
        peekBtn.visibility = View.GONE
        peekBtn.setOnClickListener { peek = !peek; applyBars() }
        val pl = FrameLayout.LayoutParams(act.dp(54), act.dp(22), Gravity.TOP or Gravity.CENTER_HORIZONTAL)
        pl.topMargin = act.dp(2)
        frame.addView(peekBtn, pl)
        hideBar = prefs().getBoolean("hidebar", false)
        hideTabs = prefs().getBoolean("hidetabs", false)
        applyBars()

        suggest = LinearLayout(act)
        suggest.orientation = LinearLayout.VERTICAL
        suggest.background = Ui.rect(Ui.panel, act.dp(10).toFloat(), Ui.border, 1)
        suggest.elevation = act.dp(12).toFloat()
        suggest.visibility = View.GONE
        val sl = FrameLayout.LayoutParams(MATCH, WRAP)
        sl.topMargin = act.dp(80)
        sl.leftMargin = act.dp(150)
        sl.rightMargin = act.dp(70)
        frame.addView(suggest, sl)

        // restore the last session, or open what was asked for
        val sess = prefs().getString("session", "") ?: ""
        if (startUrl != null) {
            newTab(startUrl)
        } else if (sess.isNotEmpty() && prefs().getBoolean("restore", true)) {
            val l = sess.split("\n").filter { it.isNotBlank() }.take(12)
            for (u in l) newTab(u, background = true)
            if (tabs.isNotEmpty()) select(tabs[0])
        }
        if (tabs.isEmpty()) newTab(null)
        fillBmBar()
        applyBars()
        return frame
    }

    private fun tool(label: String, onClick: (View) -> Unit): TextView {
        val t = TextView(act)
        t.text = label
        t.textSize = 16f
        t.setTextColor(Ui.text)
        t.gravity = Gravity.CENTER
        t.background = Ui.stateBg(act.dp(6).toFloat())
        t.isClickable = true
        t.setOnClickListener { onClick(it) }
        t.hand()
        return t
    }

    // ================================================================= tabs

    @SuppressLint("SetJavaScriptEnabled")
    private fun makeWeb(incognito: Boolean): WebView {
        val w = WebView(act)
        val s = w.settings
        s.javaScriptEnabled = true
        s.domStorageEnabled = true
        s.databaseEnabled = true
        s.setSupportMultipleWindows(true)
        s.javaScriptCanOpenWindowsAutomatically = false
        s.mediaPlaybackRequiresUserGesture = false
        s.mixedContentMode = WebSettings.MIXED_CONTENT_COMPATIBILITY_MODE
        s.builtInZoomControls = true
        s.displayZoomControls = false
        s.setSupportZoom(true)
        s.loadWithOverviewMode = true
        s.useWideViewPort = true
        s.allowFileAccess = false
        s.setGeolocationEnabled(true)
        if (incognito) { s.cacheMode = WebSettings.LOAD_NO_CACHE; s.saveFormData = false }
        s.textZoom = prefs().getInt("zoom", 100)
        CookieManager.getInstance().setAcceptCookie(true)
        CookieManager.getInstance().setAcceptThirdPartyCookies(w, true)
        w.setBackgroundColor(Ui.bgDark)
        return w
    }

    private fun applyUa(t: Tab) {
        t.web.settings.userAgentString = if (desktopSite) DESKTOP_UA else null
    }

    private fun newTab(url: String?, incognito: Boolean = false, background: Boolean = false, transport: WebView? = null): Tab {
        val w = transport ?: makeWeb(incognito)
        val t = Tab(w, incognito)
        applyUa(t)
        wire(t)
        tabs.add(t)
        if (!background) select(t)
        buildStrip()
        if (transport == null) {
            if (url == null || url.isEmpty()) loadHome(t) else navigate(t, url)
        }
        return t
    }

    private fun wire(t: Tab) {
        val w = t.web
        w.webViewClient = object : WebViewClient() {
            override fun shouldInterceptRequest(view: WebView, request: WebResourceRequest): WebResourceResponse? {
                val u = request.url
                if (u.host == Local.HOST) {
                    // only our own internal pages may read from the app
                    val p = u.path ?: ""
                    return if (p.startsWith("/assets/apps/browser/") || p.startsWith("/nerdy/")) Local.handle(act, u, request.requestHeaders)
                    else WebResourceResponse("text/plain", "utf-8", 403, "Forbidden", HashMap<String, String>(), ByteArrayInputStream(ByteArray(0)))
                }
                if (shield && !request.isForMainFrame && blockerReady) {
                    val pageHost = try { Uri.parse(t.url).host } catch (e: Exception) { null }
                    if (blocker.shouldBlock(u, pageHost, request.requestHeaders)) {
                        t.blocked++
                        val bh = u.host ?: ""
                        t.hostCounts[bh] = (t.hostCounts[bh] ?: 0) + 1
                        if (t === current) view.post { updateShield() }
                        return WebResourceResponse("text/plain", "utf-8", 204, "No Content", HashMap<String, String>(), ByteArrayInputStream(ByteArray(0)))
                    }
                }
                return null
            }

            override fun shouldOverrideUrlLoading(view: WebView, request: WebResourceRequest): Boolean {
                val u = request.url
                val sch = u.scheme ?: ""
                if (sch == "nerdy") { internalAction(t, u); return true }
                if (request.isForMainFrame && (sch == "http" || sch == "https") && u.host != Local.HOST) {
                    val p = prep(t, u.toString())
                    if (p != u.toString()) { view.loadUrl(p, gpcHeaders()); return true }
                }
                if (sch == "http" || sch == "https" || sch == "about" || sch == "data" || sch == "blob") return false
                act.startSafely(Intent(Intent.ACTION_VIEW, u).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
                return true
            }

            override fun onReceivedError(view: WebView, request: WebResourceRequest, error: android.webkit.WebResourceError) {
                val pend = t.pendingHttp
                if (request.isForMainFrame && pend != null && request.url.toString().startsWith("https")) {
                    httpOk.add(Uri.parse(pend).host ?: "")
                    t.pendingHttp = null
                    view.loadUrl(pend, gpcHeaders())
                }
            }

            override fun onPageStarted(view: WebView, url: String, favicon: Bitmap?) {
                t.loading = true
                val cu = clean(url)
                if (cu != t.url) { t.blocked = 0; t.hostCounts.clear() }
                t.url = cu
                if (cu.startsWith("http") && !cu.contains(Local.HOST)) {
                    cookiePolicy(t, cu)
                    if (desktopSite) {
                        val wm = blocker.wantsMobile(try { Uri.parse(cu).host } catch (e: Exception) { null })
                        if (wm != t.mobileUa) { t.mobileUa = wm; t.web.settings.userAgentString = if (wm) null else DESKTOP_UA; view.reload() }
                    }
                    view.evaluateJavascript(scriptFor(t), null)
                }
                updateTab(t)
                if (t === current) { progress.visibility = View.VISIBLE; refreshBar() }
            }

            override fun onPageFinished(view: WebView, url: String) {
                t.loading = false
                t.pendingHttp = null
                t.url = clean(url)
                if (t.url.startsWith("http") && !t.url.contains(Local.HOST)) view.evaluateJavascript(scriptFor(t), null)
                val ttl = view.title ?: ""
                if (ttl.isNotEmpty() && !ttl.startsWith(Local.HOST)) t.title = ttl
                if (!t.incognito && t.url.startsWith("http") && !t.url.contains(Local.HOST)) addHistory(t.title, t.url)
                if (t.dark) injectDark(t)
                if (t === current) { progress.visibility = View.INVISIBLE; refreshBar() }
                updateTab(t)
            }
        }
        w.webChromeClient = object : WebChromeClient() {
            override fun onProgressChanged(view: WebView?, p: Int) {
                if (t === current) { progress.progress = p; progress.visibility = if (p in 1..99) View.VISIBLE else View.INVISIBLE }
            }

            override fun onReceivedTitle(view: WebView?, title: String?) {
                if (!title.isNullOrEmpty() && !title.startsWith(Local.HOST)) { t.title = title; updateTab(t); if (t === current) act.focusedTitle(this@BrowserApp, title) }
            }

            override fun onReceivedIcon(view: WebView?, icon: Bitmap?) {
                t.icon = icon
                updateTab(t)
            }

            override fun onCreateWindow(view: WebView?, isDialog: Boolean, isUserGesture: Boolean, resultMsg: android.os.Message?): Boolean {
                val pol = ss("popups", "gesture")
                if (resultMsg == null || pol == "block" || (!isUserGesture && pol != "allow")) {
                    t.blocked++
                    act.runOnUiThread { act.toast("Popup blocked"); if (t === current) updateShield() }
                    return false
                }
                val nw = makeWeb(t.incognito)
                val tr = resultMsg.obj as WebView.WebViewTransport
                tr.webView = nw
                resultMsg.sendToTarget()
                newTab(null, t.incognito, false, nw)
                return true
            }

            override fun onCloseWindow(window: WebView?) {
                closeTab(t)
            }

            override fun onShowFileChooser(webView: WebView?, cb: ValueCallback<Array<Uri>>?, params: WebChromeClient.FileChooserParams?): Boolean {
                act.filePathCallback?.onReceiveValue(null)
                act.filePathCallback = cb
                return try {
                    act.startActivityForResult(params!!.createIntent(), MainActivity.REQ_FILE)
                    true
                } catch (e: Exception) {
                    act.filePathCallback = null
                    false
                }
            }

            override fun onShowCustomView(view: View?, callback: WebChromeClient.CustomViewCallback?) {
                if (view != null) act.showFullscreenView(view, callback)
            }

            override fun onHideCustomView() {
                act.hideFullscreenView()
            }

            override fun onPermissionRequest(request: PermissionRequest) {
                act.runOnUiThread { request.grant(request.resources) }
            }

            override fun onGeolocationPermissionsShowPrompt(origin: String?, callback: GeolocationPermissions.Callback?) {
                callback?.invoke(origin, true, false)
            }
        }
        w.setDownloadListener { dlUrl, agent, disposition, mime, _ -> download(dlUrl, agent, disposition, mime) }
        w.setOnLongClickListener {
            val r = w.hitTestResult
            val ex = r.extra
            if (ex != null && (r.type == WebView.HitTestResult.SRC_ANCHOR_TYPE || r.type == WebView.HitTestResult.SRC_IMAGE_ANCHOR_TYPE ||
                    r.type == WebView.HitTestResult.IMAGE_TYPE)) {
                linkMenu(w, ex, r.type == WebView.HitTestResult.IMAGE_TYPE || r.type == WebView.HitTestResult.SRC_IMAGE_ANCHOR_TYPE)
                true
            } else false
        }
    }

    private fun linkMenu(anchor: View, url: String, image: Boolean) {
        val m = PopupMenu(act, anchor)
        m.menu.add(0, 1, 0, "Open in new tab")
        m.menu.add(0, 2, 1, "Open in incognito tab")
        m.menu.add(0, 3, 2, "Open in split view")
        m.menu.add(0, 4, 3, "Copy link")
        m.menu.add(0, 5, 4, if (image) "Save image" else "Download link")
        m.menu.add(0, 6, 5, "Open in Photos / system")
        m.setOnMenuItemClickListener {
            when (it.itemId) {
                1 -> newTab(url)
                2 -> newTab(url, true)
                3 -> { newTab(url, false, true); splitWith(tabs.last()) }
                4 -> copy(url)
                5 -> download(url, null, null, null)
                6 -> act.startSafely(Intent(Intent.ACTION_VIEW, Uri.parse(url)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
            }
            true
        }
        m.show()
    }

    private fun select(t: Tab) {
        val old = current
        current = t
        if (splitTab != null && splitTab === t) {
            // clicked the right pane's tab: it just becomes the active one
        }
        layoutPanes()
        buildStrip()
        refreshBar()
        if (old !== t) hideSuggest()
    }

    private fun layoutPanes() {
        holder.removeAllViews()
        val c = current ?: return
        val s = splitTab
        (c.web.parent as? android.view.ViewGroup)?.removeView(c.web)
        holder.addView(c.web, lp(0, MATCH, 1f))
        if (s != null && s !== c) {
            (s.web.parent as? android.view.ViewGroup)?.removeView(s.web)
            val d = View(act)
            d.setBackgroundColor(Ui.accent)
            holder.addView(d, lp(act.dp(3), MATCH))
            holder.addView(s.web, lp(0, MATCH, 1f))
        }
    }

    private fun splitWith(t: Tab) {
        if (t === current) return
        splitTab = t
        layoutPanes()
        buildStrip()
    }

    private fun closeSplit() {
        splitTab = null
        layoutPanes()
        buildStrip()
    }

    private fun closeTab(t: Tab) {
        val i = tabs.indexOf(t)
        if (i < 0) return
        if (t.url.startsWith("http")) { closed.add(t.url); if (closed.size > 25) closed.removeAt(0) }
        tabs.remove(t)
        if (splitTab === t) splitTab = null
        try { t.web.loadUrl("about:blank"); (t.web.parent as? android.view.ViewGroup)?.removeView(t.web); t.web.destroy() } catch (e: Exception) {}
        if (tabs.isEmpty()) {
            val w = window
            if (w != null) act.closeWindow(w)
            return
        }
        if (current === t) select(tabs[minOf(i, tabs.size - 1)]) else buildStrip()
    }

    private fun tabText(t: Tab): String =
        (if (t.incognito) "\uD83D\uDD76 " else "") + (if (t.loading) "\u2026 " else "") + (if (t.pinned) "" else t.title)

    /** Update one tab in place (never rebuild the strip while the page loads, or taps get lost). */
    private fun updateTab(t: Tab) {
        t.label?.text = tabText(t)
        val b = t.icon
        if (b != null) t.iv?.setImageBitmap(b)
        if (side.visibility == View.VISIBLE && sideMode == "tabs") fillSide()
    }

    private fun clean(u: String): String {
        val k = "https://" + Local.HOST + "/nerdy/"
        if (u.startsWith(k)) return "nerdy://" + u.substring(k.length).substringBefore("?").substringBefore("#")
        return u
    }

    private fun buildStrip() {
        tabStrip.removeAllViews()
        for (t in tabs) {
            val cell = LinearLayout(act)
            cell.orientation = LinearLayout.HORIZONTAL
            cell.gravity = Gravity.CENTER_VERTICAL
            val isCur = t === current
            val isSplit = t === splitTab
            cell.background = Ui.rect(if (isCur) Ui.bgDark else if (isSplit) Ui.tint else 0, act.dp(8).toFloat(),
                if (t.incognito) 0xFF8E44AD.toInt() else if (isCur) Ui.accent else 0, if (isCur || t.incognito) 1 else 0)
            cell.setPadding(act.dp(8), 0, act.dp(4), 0)
            val ic = ImageView(act)
            if (t.icon != null) ic.setImageBitmap(t.icon) else ic.setImageDrawable(null)
            cell.addView(ic, lp(act.dp(16), act.dp(16)))
            t.iv = ic
            val tt = TextView(act)
            t.label = tt
            tt.text = tabText(t)
            tt.textSize = 11.5f
            tt.setSingleLine()
            tt.ellipsize = android.text.TextUtils.TruncateAt.END
            tt.setTextColor(if (isCur) Ui.text else Ui.textDim)
            tt.setPadding(act.dp(6), 0, act.dp(2), 0)
            cell.addView(tt, lp(if (t.pinned) WRAP else act.dp(150), WRAP))
            if (!t.pinned) {
                val x = TextView(act)
                x.text = "\u2715"
                x.textSize = 10f
                x.gravity = Gravity.CENTER
                x.setTextColor(Ui.textDim)
                x.isClickable = true
                x.background = Ui.stateBg(act.dp(10).toFloat())
                x.setOnClickListener { closeTab(t) }
                cell.addView(x, lp(act.dp(20), act.dp(20)))
            }
            cell.isClickable = true
            cell.setOnClickListener { select(t) }
            cell.setOnLongClickListener { tabMenu(cell, t); true }
            cell.setOnContextClickListener { tabMenu(cell, t); true }
            cell.hand()
            val l = lp(WRAP, act.dp(30))
            l.setMargins(act.dp(3), 0, act.dp(1), 0)
            tabStrip.addView(cell, l)
        }
        val plus = tool("+") { newTab(null) }
        tabStrip.addView(plus, lp(act.dp(32), act.dp(30)))
        val list = tool("\u25BE") { tabList(it) }
        tabStrip.addView(list, lp(act.dp(28), act.dp(30)))
    }

    private fun tabList(anchor: View) {
        val m = PopupMenu(act, anchor)
        tabs.forEachIndexed { i, t -> m.menu.add(0, i, i, (if (t === current) "\u25B8 " else "") + t.title) }
        if (closed.isNotEmpty()) m.menu.add(1, 900, 900, "Reopen closed tab")
        m.setOnMenuItemClickListener {
            if (it.itemId == 900) reopenClosed() else tabs.getOrNull(it.itemId)?.let { t -> select(t) }
            true
        }
        m.show()
    }

    private fun tabMenu(anchor: View, t: Tab) {
        val m = PopupMenu(act, anchor)
        m.menu.add(0, 1, 0, "Duplicate tab")
        m.menu.add(0, 2, 1, if (t.pinned) "Unpin tab" else "Pin tab")
        m.menu.add(0, 3, 2, "Show side by side")
        m.menu.add(0, 4, 3, "Close other tabs")
        m.menu.add(0, 5, 4, "Close tabs to the right")
        m.menu.add(0, 6, 5, "Close tab")
        m.setOnMenuItemClickListener {
            when (it.itemId) {
                1 -> newTab(t.url)
                2 -> { t.pinned = !t.pinned; buildStrip() }
                3 -> splitWith(t)
                4 -> tabs.filter { x -> x !== t && !x.pinned }.forEach { x -> closeTab(x) }
                5 -> { val i = tabs.indexOf(t); tabs.filterIndexed { j, x -> j > i && !x.pinned }.forEach { x -> closeTab(x) } }
                6 -> closeTab(t)
            }
            true
        }
        m.show()
    }

    private fun reopenClosed() {
        if (closed.isNotEmpty()) newTab(closed.removeAt(closed.size - 1))
    }

    // ================================================================= address bar

    private fun normalize(raw: String): String {
        val s = raw.trim()
        if (s.isEmpty()) return homeUrl()
        if (s.startsWith("http://") || s.startsWith("https://") || s.startsWith("file://") || s.startsWith("about:") || s.startsWith("data:") || s.startsWith("nerdy:")) return s
        val looksUrl = !s.contains(" ") && (s.contains(".") || s.startsWith("localhost") || Regex("^[0-9.:]+$").matches(s))
        if (looksUrl) return "https://$s"
        val e = prefs().getInt("engine", 0).coerceIn(0, engines.size - 1)
        return engines[e].second + URLEncoder.encode(s, "UTF-8")
    }

    private fun go(text: String) {
        hideSuggest()
        val t = current ?: return
        navigate(t, text)
        t.web.requestFocus()
        (act.getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager).hideSoftInputFromWindow(address.windowToken, 0)
    }

    private fun navigate(t: Tab, raw: String) {
        val u = normalize(raw)
        if (u.startsWith("nerdy://")) internalAction(t, Uri.parse(u)) else t.web.loadUrl(prep(t, u), gpcHeaders())
    }

    private fun homeUrl() = "nerdy://newtab"

    private fun loadHome(t: Tab) {
        t.url = homeUrl()
        t.title = "New tab"
        showInternal(t, "newtab")
    }

    private fun refreshBar() {
        val t = current ?: return
        if (!address.hasFocus()) {
            address.setText(if (t.url.startsWith("nerdy:") || t.url.isEmpty()) "" else t.url)
        }
        val https = t.url.startsWith("https")
        lockView.text = if (t.url.startsWith("nerdy:") || t.url.isEmpty()) "\uD83E\uDD89" else if (https) "\uD83D\uDD12" else "\u26A0"
        lockView.setTextColor(if (https) 0xFF0F9D58.toInt() else Ui.textDim)
        backBtn.alpha = if (t.web.canGoBack()) 1f else 0.4f
        fwdBtn.alpha = if (t.web.canGoForward()) 1f else 0.4f
        reloadBtn.text = if (t.loading) "\u2715" else "\u27F3"
        starBtn.text = if (isBookmarked(t.url)) "\u2605" else "\u2606"
        starBtn.setTextColor(if (isBookmarked(t.url)) 0xFFF2B01E.toInt() else Ui.textDim)
        updateShield()
        window?.setTitle((if (t.title.isEmpty()) "Nerdy Browser" else t.title) + " - Nerdy Browser")
    }

    private fun updateShield() {
        val t = current ?: return
        shieldBtn.text = "\uD83D\uDEE1" + (if (shield) " " + t.blocked else " off")
        shieldBtn.setTextColor(if (shield) 0xFF0F9D58.toInt() else Ui.textDim)
    }

    private fun showSuggest(q: String) {
        suggest.removeAllViews()
        val s = q.trim().lowercase()
        if (s.isEmpty()) { suggest.visibility = View.GONE; return }
        val out = ArrayList<Pair<String, String>>()
        for (b in bookmarks()) if (b.first.lowercase().contains(s) || b.second.lowercase().contains(s)) out.add(Pair("\u2605 " + b.first, b.second))
        for (h in history()) if ((h.first.lowercase().contains(s) || h.second.lowercase().contains(s)) && out.none { o -> o.second == h.second }) out.add(Pair("\uD83D\uDD52 " + h.first, h.second))
        val rows = ArrayList<Pair<String, String>>()
        rows.add(Pair("\uD83D\uDD0D Search for \"$q\"", q))
        rows.addAll(out.take(6))
        for (r in rows) {
            val row = TextView(act)
            row.text = r.first + (if (r.second != q) "   \u2014   " + r.second.removePrefix("https://").removePrefix("http://") else "")
            row.textSize = 12.5f
            row.setTextColor(Ui.text)
            row.setSingleLine()
            row.ellipsize = android.text.TextUtils.TruncateAt.END
            row.setPadding(act.dp(14), act.dp(9), act.dp(14), act.dp(9))
            row.isClickable = true
            row.background = Ui.stateBg(act.dp(8).toFloat())
            row.setOnClickListener { address.setText(r.second); go(r.second) }
            suggest.addView(row, lp(MATCH, WRAP))
        }
        suggest.visibility = View.VISIBLE
    }

    private fun hideSuggest() {
        suggest.visibility = View.GONE
    }

    // ================================================================= data

    private fun bookmarks(): List<Pair<String, String>> {
        val out = ArrayList<Pair<String, String>>()
        try {
            val a = JSONArray(prefs().getString("bm", "[]"))
            for (i in 0 until a.length()) { val o = a.getJSONObject(i); out.add(Pair(o.getString("t"), o.getString("u"))) }
        } catch (e: Exception) {}
        return out
    }

    private fun saveBookmarks(l: List<Pair<String, String>>) {
        val a = JSONArray()
        for (b in l) a.put(JSONObject().put("t", b.first).put("u", b.second))
        prefs().edit().putString("bm", a.toString()).apply()
        if (::bmBar.isInitialized) { fillBmBar(); if (side.visibility == View.VISIBLE) fillSide() }
    }

    private fun isBookmarked(u: String) = u.isNotEmpty() && bookmarks().any { it.second == u }

    private fun toggleBookmark() {
        val t = current ?: return
        if (!t.url.startsWith("http")) { act.toast("Open a web page first"); return }
        val l = bookmarks().toMutableList()
        if (!l.removeAll { it.second == t.url }) l.add(0, Pair(t.title, t.url))
        saveBookmarks(l)
        refreshBar()
    }

    private fun history(): List<Pair<String, String>> {
        val out = ArrayList<Pair<String, String>>()
        try {
            val a = JSONArray(prefs().getString("hist", "[]"))
            for (i in 0 until a.length()) { val o = a.getJSONObject(i); out.add(Pair(o.getString("t"), o.getString("u"))) }
        } catch (e: Exception) {}
        return out
    }

    private fun addHistory(t: String, u: String) {
        val l = history().toMutableList()
        l.removeAll { it.second == u }
        l.add(0, Pair(if (t.isEmpty()) u else t, u))
        val a = JSONArray()
        for (h in l.take(400)) a.put(JSONObject().put("t", h.first).put("u", h.second))
        prefs().edit().putString("hist", a.toString()).apply()
    }

    private fun workspaces(): MutableMap<String, List<String>> {
        val m = LinkedHashMap<String, List<String>>()
        try {
            val o = JSONObject(prefs().getString("ws", "{}"))
            for (k in o.keys()) { val a = o.getJSONArray(k); val l = ArrayList<String>(); for (i in 0 until a.length()) l.add(a.getString(i)); m[k] = l }
        } catch (e: Exception) {}
        if (!m.containsKey("Trading")) {
            m["Trading"] = listOf("https://quant-reloaded.web.app", "https://in.tradingview.com/chart/", "https://www.nseindia.com/", "https://www.delta.exchange/app/trade")
        }
        return m
    }

    private fun saveWorkspaces(m: Map<String, List<String>>) {
        val o = JSONObject()
        for ((k, v) in m) o.put(k, JSONArray(v))
        prefs().edit().putString("ws", o.toString()).apply()
    }

    private fun saveSession() {
        val sb = StringBuilder()
        for (t in tabs) if (!t.incognito && t.url.startsWith("http")) sb.append(t.url).append("\n")
        prefs().edit().putString("session", sb.toString()).apply()
    }

    // ================================================================= internal pages

    private fun css(): String {
        val bg = String.format("#%06X", Ui.bgDark and 0xFFFFFF)
        val tx = String.format("#%06X", Ui.text and 0xFFFFFF)
        val dim = String.format("#%06X", Ui.textDim and 0xFFFFFF)
        val ac = String.format("#%06X", Ui.accent and 0xFFFFFF)
        val card = String.format("#%06X", Ui.bar and 0xFFFFFF)
        val bd = String.format("#%06X", Ui.border and 0xFFFFFF)
        return "*{box-sizing:border-box}body{margin:0;background:$bg;color:$tx;font-family:Segoe UI,Roboto,sans-serif}" +
            "a{color:$ac;text-decoration:none}.wrap{max-width:900px;margin:0 auto;padding:28px 20px}h1{font-weight:300;font-size:30px;margin:0 0 14px}" +
            ".row{display:flex;align-items:center;gap:10px;padding:10px 12px;border-radius:10px;border:1px solid $bd;margin:6px 0;background:$card}" +
            ".row a{flex:1;min-width:0;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;color:$tx}.row small{color:$dim;display:block}" +
            ".x{color:$dim;font-size:18px;padding:0 8px}.tiles{display:grid;grid-template-columns:repeat(auto-fill,minmax(120px,1fr));gap:12px;margin-top:22px}" +
            ".tile{display:flex;flex-direction:column;align-items:center;gap:8px;padding:16px 8px;border-radius:14px;background:$card;border:1px solid $bd;color:$tx}" +
            ".tile i{width:44px;height:44px;border-radius:12px;background:$ac;color:#fff;display:flex;align-items:center;justify-content:center;font-style:normal;font-size:20px}" +
            ".tile span{font-size:12px;max-width:100%;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}" +
            "form{display:flex;gap:8px}input{flex:1;padding:14px 20px;border-radius:28px;border:1px solid $bd;background:$card;color:$tx;font-size:16px;outline:none}" +
            "input:focus{border-color:$ac}.big{font-size:64px;font-weight:200;margin:30px 0 0}.sub{color:$dim;margin-bottom:26px}" +
            ".btn{display:inline-block;padding:8px 14px;border-radius:8px;background:$card;border:1px solid $bd;color:$tx;margin:4px 6px 4px 0;font-size:13px}"
    }

    private fun esc(s: String) = s.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;").replace("\"", "&quot;")

    private fun pageHtml(kind: String): String {
        val sb = StringBuilder()
        sb.append("<!doctype html><html><head><meta charset=utf-8><meta name=viewport content='width=device-width,initial-scale=1'><title>")
        val b = bookmarks()
        when (kind) {
            "newtab" -> {
                val hr = java.util.Calendar.getInstance().get(java.util.Calendar.HOUR_OF_DAY)
                val greet = if (hr < 12) "Good morning" else if (hr < 17) "Good afternoon" else "Good evening"
                val engine = engines[prefs().getInt("engine", 0).coerceIn(0, engines.size - 1)]
                sb.append("New tab</title><style>").append(css()).append("</style></head><body><div class=wrap style='text-align:center;padding-top:6vh'>")
                sb.append("<div class=big id=c></div><div class=sub>").append(greet).append(", @NerdyIntruder</div>")
                sb.append("<form action='").append(engine.second.substringBefore("?")).append("' method=get><input name=").append(if (engine.second.contains("search?q=") || engine.second.contains("/?q=") || engine.second.contains("q=")) "q" else "q")
                sb.append(" placeholder='Search with ").append(engine.first).append(" or type an address' autofocus></form><div class=tiles>")
                val tiles = ArrayList<Pair<String, String>>()
                tiles.addAll(b.take(12))
                if (tiles.isEmpty()) sb.append("<p class=sub style='grid-column:1/-1'>Star \u2605 a page and it will appear here.</p>")
                for (t in tiles) {
                    val host = try { Uri.parse(t.second).host ?: t.first } catch (e: Exception) { t.first }
                    sb.append("<a class=tile href='").append(esc(t.second)).append("'><i>").append(esc((t.first.firstOrNull() ?: '?').uppercaseChar().toString())).append("</i><span>")
                    sb.append(esc(if (t.first.length > 24) host else t.first)).append("</span></a>")
                }
                sb.append("</div><p style='margin-top:34px'><a class=btn href='nerdy://bookmarks'>\u2605 Bookmarks</a><a class=btn href='nerdy://history'>\uD83D\uDD52 History</a><a class=btn href='nerdy://downloads'>\u2B07 Downloads</a>")
                sb.append("<a class=btn href='nerdy://workspaces'>\uD83D\uDDC2 Workspaces</a></p></div><script>function t(){var d=new Date();document.getElementById('c').textContent=d.toLocaleTimeString([],{hour:'2-digit',minute:'2-digit'})}t();setInterval(t,15000)</script></body></html>")
            }
            "bookmarks" -> {
                sb.append("Bookmarks</title><style>").append(css()).append("</style></head><body><div class=wrap><h1>\u2605 Bookmarks</h1>")
                if (b.isEmpty()) sb.append("<p>No bookmarks yet. Tap the star in the address bar.</p>")
                for (x in b) sb.append("<div class=row><a href='").append(esc(x.second)).append("'>").append(esc(x.first)).append("<small>").append(esc(x.second)).append("</small></a><a class=x href='nerdy://delbm?u=").append(Uri.encode(x.second)).append("'>\u2715</a></div>")
                sb.append("</div></body></html>")
            }
            "history" -> {
                sb.append("History</title><style>").append(css()).append("</style></head><body><div class=wrap><h1>\uD83D\uDD52 History</h1><a class=btn href='nerdy://clearhist'>Clear history</a>")
                for (x in history().take(200)) sb.append("<div class=row><a href='").append(esc(x.second)).append("'>").append(esc(x.first)).append("<small>").append(esc(x.second)).append("</small></a></div>")
                sb.append("</div></body></html>")
            }
            "downloads" -> {
                sb.append("Downloads</title><style>").append(css()).append("</style></head><body><div class=wrap><h1>\u2B07 Downloads</h1>")
                try {
                    val dm = act.getSystemService(Context.DOWNLOAD_SERVICE) as DownloadManager
                    val cur = dm.query(DownloadManager.Query().setFilterByStatus(DownloadManager.STATUS_SUCCESSFUL or DownloadManager.STATUS_RUNNING or DownloadManager.STATUS_PENDING or DownloadManager.STATUS_FAILED))
                    var n = 0
                    while (cur.moveToNext() && n < 60) {
                        val t = cur.getString(cur.getColumnIndexOrThrow(DownloadManager.COLUMN_TITLE)) ?: ""
                        val st = cur.getInt(cur.getColumnIndexOrThrow(DownloadManager.COLUMN_STATUS))
                        val loc = cur.getString(cur.getColumnIndexOrThrow(DownloadManager.COLUMN_LOCAL_URI)) ?: ""
                        val path = if (loc.startsWith("file://")) Uri.parse(loc).path ?: "" else ""
                        val label = when (st) { DownloadManager.STATUS_SUCCESSFUL -> "Done"; DownloadManager.STATUS_FAILED -> "Failed"; else -> "In progress" }
                        sb.append("<div class=row><a href='nerdy://openfile?p=").append(Uri.encode(path)).append("'>").append(esc(t)).append("<small>").append(label).append("</small></a></div>")
                        n++
                    }
                    cur.close()
                    if (n == 0) sb.append("<p>Nothing downloaded yet.</p>")
                } catch (e: Exception) { sb.append("<p>Could not read downloads.</p>") }
                sb.append("<a class=btn href='nerdy://openfolder'>Open Downloads folder</a></div></body></html>")
            }
            "workspaces" -> {
                sb.append("Workspaces</title><style>").append(css()).append("</style></head><body><div class=wrap><h1>\uD83D\uDDC2 Workspaces</h1><p>A workspace opens a whole set of tabs in one tap.</p>")
                for ((k, v) in workspaces()) {
                    sb.append("<div class=row><a href='nerdy://openws?n=").append(Uri.encode(k)).append("'><b>").append(esc(k)).append("</b><small>").append(v.size).append(" tabs</small></a><a class=x href='nerdy://delws?n=").append(Uri.encode(k)).append("'>\u2715</a></div>")
                }
                sb.append("<a class=btn href='nerdy://savews'>+ Save current tabs as a workspace</a></div></body></html>")
            }
            "settings" -> {
                sb.append("Settings</title><style>").append(css()).append("</style></head><body><div class=wrap><h1>\u2699 Browser settings</h1><h3>Search engine</h3>")
                val cur = prefs().getInt("engine", 0)
                engines.forEachIndexed { i, e -> sb.append("<a class=btn href='nerdy://engine?i=").append(i).append("'>").append(if (i == cur) "\u25CF " else "\u25CB ").append(e.first).append("</a>") }
                sb.append("<h3>Shield level</h3>")
                val lv = ss("shield", "standard")
                for (x in listOf("off", "standard", "strict", "ultra")) sb.append("<a class=btn href='nerdy://st?k=shield&v=").append(x).append("'>").append(if (x == lv) "\u25CF " else "\u25CB ").append(x.replaceFirstChar { c -> c.uppercase() }).append("</a>")
                sb.append("<h3>Shield options (same as NerdyBrowser)</h3>")
                fun sg(k: String, label: String, d: Boolean) { sb.append("<div class=row><span style='flex:1'>").append(label).append("</span><a class=btn href='nerdy://stt?k=").append(k).append("&d=").append(if (d) "1" else "0").append("'>").append(if (stb(k, d)) "On" else "Off").append("</a></div>") }
                sg("cosmetic", "Hide ad boxes and sponsored blocks", true)
                sg("consent", "Auto-dismiss cookie banners", true)
                sg("videoAds", "Block YouTube video ads", true)
                sg("stripParams", "Strip tracking parameters from links", true)
                sg("httpsOnly", "HTTPS only (upgrade http links)", true)
                sg("gpc", "Send Do-Not-Track / Global Privacy Control", true)
                sg("spoof", "Fingerprint protection", true)
                sg("noWebrtc", "Block WebRTC IP leaks", true)
                sg("noBeacon", "Block tracking beacons", true)
                sg("signinCompat", "Sign-in compatibility (Google, Microsoft, Apple\u2026)", true)
                sg("appCompat", "Web-app compatibility (Spotify, Netflix\u2026)", true)
                sg("blockAutoplay", "Block autoplay on normal sites", true)
                val pop = ss("popups", "gesture")
                sb.append("<div class=row><span style='flex:1'>Pop-ups: ").append(pop).append("</span>")
                for (x in listOf("gesture", "block", "allow")) sb.append("<a class=btn href='nerdy://st?k=popups&v=").append(x).append("'>").append(x).append("</a>")
                sb.append("</div>")
                val ck = ss("cookies", "first")
                sb.append("<div class=row><span style='flex:1'>Third-party cookies: ").append(ck).append("</span>")
                for (x in listOf("first", "all", "none")) sb.append("<a class=btn href='nerdy://st?k=cookies&v=").append(x).append("'>").append(x).append("</a>")
                sb.append("</div><h3>Options</h3>")
                fun tg(k: String, label: String, on: Boolean) { sb.append("<div class=row><span style='flex:1'>").append(label).append("</span><a class=btn href='nerdy://tog?k=").append(k).append("'>").append(if (on) "On" else "Off").append("</a></div>") }
                tg("desktop", "Request desktop sites", desktopSite)
                tg("restore", "Restore tabs when the browser opens", prefs().getBoolean("restore", true))
                tg("bmbar", "Show bookmarks bar", prefs().getBoolean("bmbar", true))
                sb.append("<h3>Privacy</h3><a class=btn href='nerdy://clearhist'>Clear history</a><a class=btn href='nerdy://clearcookies'>Clear cookies &amp; site data</a></div></body></html>")
            }
            else -> sb.append("</title></head><body></body></html>")
        }
        return sb.toString()
    }

    private fun showInternal(t: Tab, kind: String) {
        t.url = "nerdy://$kind"
        t.title = when (kind) { "newtab" -> "New tab"; "bookmarks" -> "Bookmarks"; "history" -> "History"; "downloads" -> "Downloads"; "settings" -> "Settings"; else -> "Workspaces" }
        t.web.loadDataWithBaseURL("https://" + Local.HOST + "/nerdy/" + kind, pageHtml(kind), "text/html", "utf-8", "nerdy://$kind")
        buildStrip()
        if (t === current) refreshBar()
    }

    private fun internalAction(t: Tab, u: Uri) {
        val host = u.host ?: ""
        when (host) {
            "newtab", "bookmarks", "history", "downloads", "workspaces", "settings" -> showInternal(t, host)
            "engine" -> { prefs().edit().putInt("engine", (u.getQueryParameter("i") ?: "0").toIntOrNull() ?: 0).apply(); showInternal(t, "settings") }
            "st" -> { st.put(u.getQueryParameter("k") ?: "x", u.getQueryParameter("v") ?: ""); saveSt(); showInternal(t, "settings") }
            "stt" -> { val k = u.getQueryParameter("k") ?: "x"; st.put(k, !st.optBoolean(k, u.getQueryParameter("d") == "1")); saveSt(); showInternal(t, "settings") }
            "tog" -> { toggleSetting(u.getQueryParameter("k") ?: ""); showInternal(t, "settings") }
            "clearcookies" -> { CookieManager.getInstance().removeAllCookies(null); WebStorage.getInstance().deleteAllData(); act.toast("Cookies and site data cleared") }
            "delbm" -> { val x = u.getQueryParameter("u") ?: ""; saveBookmarks(bookmarks().filter { it.second != x }); showInternal(t, "bookmarks") }
            "clearhist" -> { prefs().edit().putString("hist", "[]").apply(); showInternal(t, "history") }
            "openfile" -> { val p = u.getQueryParameter("p") ?: ""; if (p.isNotEmpty()) act.openFileSmart(p) }
            "openfolder" -> act.open(AppKind.FILES, Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS).absolutePath)
            "openws" -> { val n = u.getQueryParameter("n") ?: ""; workspaces()[n]?.let { l -> openWorkspace(l, t) } }
            "delws" -> { val n = u.getQueryParameter("n") ?: ""; val m = workspaces(); m.remove(n); saveWorkspaces(m); showInternal(t, "workspaces") }
            "savews" -> saveWorkspace()
        }
    }

    private fun openWorkspace(urls: List<String>, from: Tab) {
        for (u in urls) newTab(u, false, true)
        closeTab(from)
        if (tabs.isNotEmpty()) select(tabs[tabs.size - urls.size])
        if (urls.size >= 2) splitWith(tabs[tabs.size - urls.size + 1])
    }

    private fun saveWorkspace() {
        val et = EditText(act)
        et.hint = "Workspace name"
        android.app.AlertDialog.Builder(act).setTitle("Save tabs as workspace").setView(et)
            .setPositiveButton("Save") { _, _ ->
                val n = et.text.toString().trim()
                if (n.isNotEmpty()) {
                    val m = workspaces()
                    m[n] = tabs.filter { !it.incognito && it.url.startsWith("http") }.map { it.url }
                    saveWorkspaces(m)
                    act.toast("Saved workspace \"$n\"")
                }
            }.setNegativeButton("Cancel", null).show()
    }

    // ================================================================= menu & tools

    private fun copy(s: String) {
        (act.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager).setPrimaryClip(ClipData.newPlainText("link", s))
        act.toast("Copied")
    }

    private fun siteOff(host: String?): Boolean = host != null && blocker.isAllowed(host)

    private fun shieldMenu(anchor: View) {
        val t = current ?: return
        val host = try { Uri.parse(t.url).host } catch (e: Exception) { null }
        val m = PopupMenu(act, anchor)
        m.menu.add(0, 0, 0, "\uD83D\uDEE1 " + t.blocked + " blocked on this page").isEnabled = false
        var n = 1
        for (e in t.hostCounts.entries.sortedByDescending { it.value }.take(5)) m.menu.add(0, 0, n++, "   " + e.key + "  \u00D7" + e.value).isEnabled = false
        if (host != null) m.menu.add(1, 3, 20, if (siteOff(host)) "Turn shield ON for $host" else "Turn shield OFF for $host")
        m.menu.add(1, 4, 21, "Shield level: " + ss("shield", "standard") + "  (tap to change)")
        m.menu.add(1, 2, 22, "Clear cookies & site data")
        m.menu.add(1, 5, 23, "All shield settings")
        m.setOnMenuItemClickListener {
            when (it.itemId) {
                2 -> { CookieManager.getInstance().removeAllCookies(null); WebStorage.getInstance().deleteAllData(); act.toast("Cookies and site data cleared") }
                3 -> if (host != null) {
                    val cur = st.optJSONArray("siteAllow") ?: JSONArray()
                    val l = ArrayList<String>()
                    for (i in 0 until cur.length()) l.add(cur.optString(i))
                    if (!l.remove(host)) l.add(host)
                    st.put("siteAllow", JSONArray(l))
                    saveSt()
                    t.web.reload()
                }
                4 -> {
                    val order = listOf("off", "standard", "strict", "ultra")
                    st.put("shield", order[(order.indexOf(ss("shield", "standard")) + 1) % order.size])
                    saveSt()
                    act.toast("Shield: " + ss("shield", "standard"))
                    t.web.reload()
                    updateShield()
                }
                5 -> showInternal(t, "settings")
            }
            true
        }
        m.show()
    }

    private fun toggleSetting(k: String) {
        when (k) {
            "shield" -> { st.put("shield", if (shield) "off" else "standard"); saveSt() }
            "desktop" -> { desktopSite = !desktopSite; prefs().edit().putBoolean("desktop", desktopSite).apply(); tabs.forEach { x -> applyUa(x) } }
            "restore" -> prefs().edit().putBoolean("restore", !prefs().getBoolean("restore", true)).apply()
            "bmbar" -> { prefs().edit().putBoolean("bmbar", !prefs().getBoolean("bmbar", true)).apply(); fillBmBar() }
        }
    }

    // ================================================================= bookmarks bar, side panel, full screen

    private fun fillBmBar() {
        bmBar.removeAllViews()
        val b = bookmarks()
        val show = prefs().getBoolean("bmbar", true) && b.isNotEmpty() && !fullscreen
        bmScroll.visibility = if (show) View.VISIBLE else View.GONE
        for (x in b) {
            val c = TextView(act)
            c.text = "\u2605 " + (if (x.first.length > 22) x.first.substring(0, 22) + "\u2026" else x.first)
            c.textSize = 11.5f
            c.setTextColor(Ui.text)
            c.setPadding(act.dp(10), 0, act.dp(10), 0)
            c.gravity = Gravity.CENTER_VERTICAL
            c.background = Ui.stateBg(act.dp(6).toFloat())
            c.isClickable = true
            c.setOnClickListener { current?.let { t -> navigate(t, x.second) } }
            c.setOnLongClickListener { newTab(x.second); true }
            c.hand()
            bmBar.addView(c, lp(WRAP, MATCH))
        }
    }

    private fun buildSide(): LinearLayout {
        val s = LinearLayout(act)
        s.orientation = LinearLayout.VERTICAL
        s.setBackgroundColor(Ui.side)
        val head = LinearLayout(act)
        head.orientation = LinearLayout.HORIZONTAL
        val modes = listOf(Pair("bm", "\u2605"), Pair("hist", "\uD83D\uDD52"), Pair("dl", "\u2B07"), Pair("tabs", "\uD83D\uDDC2"))
        for (m in modes) head.addView(tool(m.second) { sideMode = m.first; sideSearch.setText(""); fillSide() }, lp(0, act.dp(38), 1f))
        head.addView(tool("\u2715") { toggleSide("") }, lp(act.dp(40), act.dp(38)))
        s.addView(head, lp(MATCH, act.dp(38)))
        sideTitle = TextView(act)
        sideTitle.textSize = 14f
        sideTitle.setTextColor(Ui.text)
        sideTitle.setPadding(act.dp(12), act.dp(8), act.dp(12), act.dp(4))
        s.addView(sideTitle, lp(MATCH, WRAP))
        sideSearch = EditText(act)
        sideSearch.hint = "Filter\u2026"
        sideSearch.setSingleLine()
        sideSearch.textSize = 12.5f
        sideSearch.setTextColor(Ui.text)
        sideSearch.setHintTextColor(Ui.textDim)
        sideSearch.background = Ui.rect(Ui.field, act.dp(8).toFloat(), Ui.border, 1)
        sideSearch.setPadding(act.dp(10), 0, act.dp(10), 0)
        sideSearch.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(x: CharSequence?, a: Int, b: Int, c: Int) {}
            override fun onTextChanged(x: CharSequence?, a: Int, b: Int, c: Int) {}
            override fun afterTextChanged(x: Editable?) { fillSide() }
        })
        val sl = lp(MATCH, act.dp(32))
        sl.setMargins(act.dp(8), 0, act.dp(8), act.dp(6))
        s.addView(sideSearch, sl)
        val sv = android.widget.ScrollView(act)
        sideList = LinearLayout(act)
        sideList.orientation = LinearLayout.VERTICAL
        sv.addView(sideList, FrameLayout.LayoutParams(MATCH, WRAP))
        s.addView(sv, lp(MATCH, 0, 1f))
        return s
    }

    private fun toggleSide(mode: String?) {
        val open = side.visibility == View.VISIBLE
        if (mode == "") { side.visibility = View.GONE; return }
        if (mode != null) sideMode = mode
        if (open && mode == null) { side.visibility = View.GONE; return }
        side.visibility = View.VISIBLE
        fillSide()
    }

    private fun sideRow(title: String, sub: String, onClick: () -> Unit, onDelete: (() -> Unit)?): View {
        val r = LinearLayout(act)
        r.orientation = LinearLayout.HORIZONTAL
        r.gravity = Gravity.CENTER_VERTICAL
        r.setPadding(act.dp(12), act.dp(6), act.dp(4), act.dp(6))
        r.isClickable = true
        r.background = Ui.stateBg(act.dp(6).toFloat())
        val col = LinearLayout(act)
        col.orientation = LinearLayout.VERTICAL
        val a = TextView(act)
        a.text = title
        a.textSize = 12.5f
        a.setTextColor(Ui.text)
        a.setSingleLine()
        a.ellipsize = android.text.TextUtils.TruncateAt.END
        col.addView(a)
        if (sub.isNotEmpty()) {
            val b = TextView(act)
            b.text = sub
            b.textSize = 10.5f
            b.setTextColor(Ui.textDim)
            b.setSingleLine()
            b.ellipsize = android.text.TextUtils.TruncateAt.MIDDLE
            col.addView(b)
        }
        r.addView(col, lp(0, WRAP, 1f))
        if (onDelete != null) r.addView(tool("\u2715") { onDelete() }, lp(act.dp(30), act.dp(30)))
        r.setOnClickListener { onClick() }
        r.hand()
        return r
    }

    private fun fillSide() {
        if (!::sideList.isInitialized) return
        sideList.removeAllViews()
        val q = sideSearch.text.toString().trim().lowercase()
        when (sideMode) {
            "bm" -> {
                sideTitle.text = "\u2605 Bookmarks"
                for (b in bookmarks().filter { it.first.lowercase().contains(q) || it.second.lowercase().contains(q) })
                    sideList.addView(sideRow(b.first, b.second, { current?.let { t -> navigate(t, b.second) } }, { saveBookmarks(bookmarks().filter { x -> x.second != b.second }) }))
                if (bookmarks().isEmpty()) sideList.addView(sideRow("No bookmarks yet", "Tap the star in the address bar", {}, null))
            }
            "hist" -> {
                sideTitle.text = "\uD83D\uDD52 History"
                for (h in history().filter { it.first.lowercase().contains(q) || it.second.lowercase().contains(q) }.take(80))
                    sideList.addView(sideRow(h.first, h.second, { current?.let { t -> navigate(t, h.second) } }, null))
            }
            "dl" -> {
                sideTitle.text = "\u2B07 Downloads"
                try {
                    val dm = act.getSystemService(Context.DOWNLOAD_SERVICE) as DownloadManager
                    val cur = dm.query(DownloadManager.Query())
                    var n = 0
                    while (cur.moveToNext() && n < 50) {
                        val t = cur.getString(cur.getColumnIndexOrThrow(DownloadManager.COLUMN_TITLE)) ?: ""
                        val st = cur.getInt(cur.getColumnIndexOrThrow(DownloadManager.COLUMN_STATUS))
                        val loc = cur.getString(cur.getColumnIndexOrThrow(DownloadManager.COLUMN_LOCAL_URI)) ?: ""
                        val path = if (loc.startsWith("file://")) Uri.parse(loc).path ?: "" else ""
                        if (q.isNotEmpty() && !t.lowercase().contains(q)) continue
                        sideList.addView(sideRow(t, if (st == DownloadManager.STATUS_SUCCESSFUL) "Done" else if (st == DownloadManager.STATUS_FAILED) "Failed" else "In progress", { if (path.isNotEmpty()) act.openFileSmart(path) }, null))
                        n++
                    }
                    cur.close()
                } catch (e: Exception) {
                }
            }
            else -> {
                sideTitle.text = "\uD83D\uDDC2 Tabs (" + tabs.size + ")"
                for (t in tabs.filter { it.title.lowercase().contains(q) || it.url.lowercase().contains(q) })
                    sideList.addView(sideRow((if (t === current) "\u25B8 " else "") + t.title, t.url.removePrefix("https://"), { select(t) }, { closeTab(t) }))
            }
        }
    }

    private var hideBar = false
    private var hideTabs = false
    private var peek = false
    private lateinit var peekBtn: TextView

    private fun applyBars() {
        val showTabs = !fullscreen && (!hideTabs || peek)
        val showBar = !fullscreen && (!hideBar || peek)
        tabScroll.visibility = if (showTabs) View.VISIBLE else View.GONE
        toolbar.visibility = if (showBar) View.VISIBLE else View.GONE
        val anyHidden = !fullscreen && (hideTabs || hideBar)
        peekBtn.visibility = if (anyHidden) View.VISIBLE else View.GONE
        peekBtn.text = if (peek) "\u2303" else "\u2304"
        fillBmBar()
    }

    private fun showBarsNow() {
        if (fullscreen) return
        peek = true
        applyBars()
    }

    /** Called by the window when it goes full screen (title bar + taskbar + phone bars already hidden). */
    override fun onFullscreen(on: Boolean) {
        fullscreen = on
        if (on) side.visibility = View.GONE
        applyBars()
    }

    private fun setFullscreen(on: Boolean) {
        val w = window ?: return
        act.setWindowFullscreen(w, on)
    }


    private fun menu(anchor: View) {
        val t = current ?: return
        val m = PopupMenu(act, anchor)
        m.menu.add(0, 1, 0, "New tab")
        m.menu.add(0, 2, 1, "New incognito tab")
        m.menu.add(0, 3, 2, "Bookmarks")
        m.menu.add(0, 4, 3, "History")
        m.menu.add(0, 5, 4, "Downloads")
        m.menu.add(0, 6, 5, "Workspaces")
        m.menu.add(1, 7, 6, "Find in page")
        m.menu.add(1, 8, 7, (if (desktopSite) "\u2713 " else "") + "Desktop site")
        m.menu.add(1, 9, 8, (if (t.dark) "\u2713 " else "") + "Dark pages")
        m.menu.add(1, 10, 9, "Reader mode")
        m.menu.add(1, 11, 10, if (splitTab == null) "Split view" else "Close split view")
        m.menu.add(2, 12, 11, "Zoom in")
        m.menu.add(2, 13, 12, "Zoom out")
        m.menu.add(2, 14, 13, "Reset zoom")
        m.menu.add(3, 15, 14, "Screenshot")
        m.menu.add(3, 16, 15, "Print / Save as PDF")
        m.menu.add(3, 17, 16, "View source")
        m.menu.add(3, 18, 17, "Share link")
        m.menu.add(3, 19, 18, "Copy link")
        m.menu.add(3, 20, 19, "Open in phone browser")
        m.menu.add(4, 21, 20, "Search engine: " + engines[prefs().getInt("engine", 0).coerceIn(0, engines.size - 1)].first)
        m.menu.add(4, 22, 21, "Reopen closed tab")
        m.menu.add(4, 23, 22, (if (prefs().getBoolean("restore", true)) "\u2713 " else "") + "Restore tabs on start")
        m.menu.add(5, 24, 23, "Full screen (F11)")
        m.menu.add(5, 25, 24, "Side panel (bookmarks, history, tabs)")
        m.menu.add(5, 26, 25, (if (prefs().getBoolean("bmbar", true)) "\u2713 " else "") + "Bookmarks bar")
        m.menu.add(5, 27, 26, "Browser settings")
        m.menu.add(5, 28, 27, (if (hideBar) "\u2713 " else "") + "Hide address bar")
        m.menu.add(5, 29, 28, (if (hideTabs) "\u2713 " else "") + "Hide tab strip")
        m.setOnMenuItemClickListener {
            when (it.itemId) {
                1 -> newTab(null)
                2 -> newTab(null, true)
                3 -> showInternal(t, "bookmarks")
                4 -> showInternal(t, "history")
                5 -> showInternal(t, "downloads")
                6 -> showInternal(t, "workspaces")
                7 -> openFind()
                8 -> { desktopSite = !desktopSite; prefs().edit().putBoolean("desktop", desktopSite).apply(); tabs.forEach { x -> applyUa(x) }; t.web.reload() }
                9 -> { t.dark = !t.dark; if (t.dark) injectDark(t) else t.web.reload() }
                10 -> reader(t)
                11 -> if (splitTab == null) { newTab(null, false, true); splitWith(tabs.last()) } else closeSplit()
                12 -> zoom(10)
                13 -> zoom(-10)
                14 -> { prefs().edit().putInt("zoom", 100).apply(); tabs.forEach { x -> x.web.settings.textZoom = 100 } }
                15 -> screenshot(t)
                16 -> printPage(t)
                17 -> if (t.url.startsWith("http")) newTab("view-source:" + t.url)
                18 -> act.startSafely(Intent.createChooser(Intent(Intent.ACTION_SEND).setType("text/plain").putExtra(Intent.EXTRA_TEXT, t.url), "Share").addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
                19 -> copy(t.url)
                20 -> act.startSafely(Intent(Intent.ACTION_VIEW, Uri.parse(t.url)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK).setPackage(null))
                21 -> engineMenu(anchor)
                22 -> reopenClosed()
                23 -> prefs().edit().putBoolean("restore", !prefs().getBoolean("restore", true)).apply()
                24 -> setFullscreen(!fullscreen)
                25 -> toggleSide(null)
                26 -> toggleSetting("bmbar")
                27 -> showInternal(t, "settings")
                28 -> { hideBar = !hideBar; peek = false; prefs().edit().putBoolean("hidebar", hideBar).apply(); applyBars() }
                29 -> { hideTabs = !hideTabs; peek = false; prefs().edit().putBoolean("hidetabs", hideTabs).apply(); applyBars() }
            }
            true
        }
        m.show()
    }

    private fun engineMenu(anchor: View) {
        val m = PopupMenu(act, anchor)
        engines.forEachIndexed { i, e -> m.menu.add(0, i, i, e.first) }
        m.setOnMenuItemClickListener { prefs().edit().putInt("engine", it.itemId).apply(); true }
        m.show()
    }

    private fun zoom(d: Int) {
        val z = (prefs().getInt("zoom", 100) + d).coerceIn(50, 250)
        prefs().edit().putInt("zoom", z).apply()
        tabs.forEach { it.web.settings.textZoom = z }
        act.toast("Zoom $z%")
    }

    private fun openFind() {
        findBar.visibility = View.VISIBLE
        findInput.requestFocus()
        (act.getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager).showSoftInput(findInput, 0)
        current?.web?.setFindListener { active, total, _ -> findCount.text = if (total == 0) "0" else (active + 1).toString() + "/" + total }
    }

    private fun closeFind() {
        findBar.visibility = View.GONE
        current?.web?.clearMatches()
        findInput.setText("")
    }

    private fun injectDark(t: Tab) {
        t.web.evaluateJavascript(
            "(function(){if(document.getElementById('nd-dark'))return;var s=document.createElement('style');s.id='nd-dark';" +
                "s.textContent='html{filter:invert(1) hue-rotate(180deg)!important;background:#fff}img,video,canvas,picture,svg image{filter:invert(1) hue-rotate(180deg)!important}';" +
                "document.documentElement.appendChild(s)})()", null)
    }

    private fun reader(t: Tab) {
        val js = "(function(){var best=null,bs=0;document.querySelectorAll('article,main,div,section').forEach(function(e){var p=e.querySelectorAll(':scope > p, :scope > div > p');var n=0;p.forEach(function(x){n+=x.textContent.length});if(n>bs){bs=n;best=e}});" +
            "if(!best){alert('No article found on this page');return}var h='<h1>'+document.title+'</h1>';best.querySelectorAll('p,h2,h3,li,img,blockquote').forEach(function(x){if(x.tagName=='IMG'){if(x.width>200)h+='<img src=\"'+x.src+'\">'}else if(x.textContent.trim().length>1){h+='<'+x.tagName+'>'+x.textContent+'</'+x.tagName+'>'}});" +
            "var d=document.createElement('div');d.id='nd-reader';d.style.cssText='position:fixed;inset:0;z-index:2147483647;overflow:auto;background:#fbf7ef;color:#222;font:20px/1.7 Georgia,serif;padding:40px 12vw';" +
            "d.innerHTML='<style>#nd-reader img{max-width:100%;border-radius:8px}#nd-reader h1{font-size:34px;line-height:1.2}</style><div style=\"max-width:720px;margin:0 auto\">'+h+'<p><a href=# onclick=\"this.closest(\\'#nd-reader\\').remove();return false\">\u2715 Close reader</a></p></div>';document.body.appendChild(d)})()"
        t.web.evaluateJavascript(js, null)
    }

    private fun screenshot(t: Tab) {
        try {
            val w = t.web
            val bmp = Bitmap.createBitmap(w.width, w.height, Bitmap.Config.ARGB_8888)
            w.draw(Canvas(bmp))
            val dir = File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_PICTURES), "NerdyDesk")
            dir.mkdirs()
            val f = File(dir, "browser_" + System.currentTimeMillis() + ".png")
            f.outputStream().use { bmp.compress(Bitmap.CompressFormat.PNG, 100, it) }
            android.media.MediaScannerConnection.scanFile(act, arrayOf(f.absolutePath), null, null)
            act.toast("Saved to Pictures/NerdyDesk")
        } catch (e: Exception) {
            act.toast("Could not take a screenshot")
        }
    }

    private fun printPage(t: Tab) {
        try {
            val pm = act.getSystemService(Context.PRINT_SERVICE) as PrintManager
            val name = (if (t.title.isEmpty()) "page" else t.title)
            pm.print(name, t.web.createPrintDocumentAdapter(name), PrintAttributes.Builder().build())
        } catch (e: Exception) {
            act.toast("Printing is not available")
        }
    }

    private fun download(url: String, agent: String?, disposition: String?, mime: String?) {
        try {
            if (url.startsWith("blob:") || url.startsWith("data:")) { act.toast("Use right-click / long-press > Save for this file"); return }
            val req = DownloadManager.Request(Uri.parse(url))
            if (mime != null) req.setMimeType(mime)
            CookieManager.getInstance().getCookie(url)?.let { req.addRequestHeader("cookie", it) }
            if (agent != null) req.addRequestHeader("User-Agent", agent)
            val name = URLUtil.guessFileName(url, disposition, mime)
            req.setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED)
            req.setDestinationInExternalPublicDir(Environment.DIRECTORY_DOWNLOADS, name)
            (act.getSystemService(Context.DOWNLOAD_SERVICE) as DownloadManager).enqueue(req)
            act.toast("Downloading $name")
        } catch (e: Exception) {
            act.toast("Download failed")
        }
    }

    // ================================================================= window hooks

    override fun currentArg(): String? = current?.url

    override fun onOpenArg(arg: String) {
        newTab(arg)
    }

    override fun onShortcut(e: KeyEvent): Boolean {
        val ctrl = e.isCtrlPressed
        val shift = e.isShiftPressed
        val alt = e.isAltPressed
        if (ctrl) {
            when (e.keyCode) {
                KeyEvent.KEYCODE_T -> { if (shift) reopenClosed() else newTab(null); return true }
                KeyEvent.KEYCODE_N -> { newTab(null, shift); return true }
                KeyEvent.KEYCODE_W -> { current?.let { closeTab(it) }; return true }
                KeyEvent.KEYCODE_L -> { showBarsNow(); address.requestFocus(); address.selectAll(); return true }
                KeyEvent.KEYCODE_R -> { current?.web?.reload(); return true }
                KeyEvent.KEYCODE_F -> { openFind(); return true }
                KeyEvent.KEYCODE_D -> { toggleBookmark(); return true }
                KeyEvent.KEYCODE_H -> { current?.let { showInternal(it, "history") }; return true }
                KeyEvent.KEYCODE_J -> { current?.let { showInternal(it, "downloads") }; return true }
                KeyEvent.KEYCODE_P -> { current?.let { printPage(it) }; return true }
                KeyEvent.KEYCODE_PLUS, KeyEvent.KEYCODE_EQUALS -> { zoom(10); return true }
                KeyEvent.KEYCODE_MINUS -> { zoom(-10); return true }
                KeyEvent.KEYCODE_0 -> { prefs().edit().putInt("zoom", 100).apply(); tabs.forEach { it.web.settings.textZoom = 100 }; return true }
                KeyEvent.KEYCODE_TAB -> {
                    if (tabs.size > 1) { val i = tabs.indexOf(current); select(tabs[(i + (if (shift) tabs.size - 1 else 1)) % tabs.size]) }
                    return true
                }
            }
            if (e.keyCode >= KeyEvent.KEYCODE_1 && e.keyCode <= KeyEvent.KEYCODE_9) {
                val n = e.keyCode - KeyEvent.KEYCODE_1
                tabs.getOrNull(if (e.keyCode == KeyEvent.KEYCODE_9) tabs.size - 1 else n)?.let { select(it) }
                return true
            }
        }
        if (alt && e.keyCode == KeyEvent.KEYCODE_DPAD_LEFT) { current?.web?.let { if (it.canGoBack()) it.goBack() }; return true }
        if (alt && e.keyCode == KeyEvent.KEYCODE_DPAD_RIGHT) { current?.web?.let { if (it.canGoForward()) it.goForward() }; return true }
        if (ctrl && e.keyCode == KeyEvent.KEYCODE_B) { toggleSide(null); return true }
        if (e.keyCode == KeyEvent.KEYCODE_F5) { current?.web?.reload(); return true }
        if (e.keyCode == KeyEvent.KEYCODE_ESCAPE && fullscreen) { setFullscreen(false); return true }
        if (e.keyCode == KeyEvent.KEYCODE_ESCAPE && findBar.visibility == View.VISIBLE) { closeFind(); return true }
        return false
    }

    override fun onBack(): Boolean {
        val t = current ?: return false
        if (findBar.visibility == View.VISIBLE) { closeFind(); return true }
        if (t.web.canGoBack()) { t.web.goBack(); return true }
        return false
    }

    override fun onResume() {
        current?.web?.onResume()
    }

    override fun onClose() {
        saveSession()
        for (t in tabs) {
            try { t.web.loadUrl("about:blank"); (t.web.parent as? android.view.ViewGroup)?.removeView(t.web); t.web.destroy() } catch (e: Exception) {}
        }
        tabs.clear()
    }
}
