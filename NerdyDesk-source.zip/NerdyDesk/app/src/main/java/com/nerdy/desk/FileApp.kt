package com.nerdy.desk

import android.Manifest
import android.app.AlertDialog
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.os.SystemClock
import android.provider.Settings
import android.view.Gravity
import android.view.KeyEvent
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.webkit.MimeTypeMap
import android.widget.BaseAdapter
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ListView
import android.widget.PopupMenu
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class FileApp(act: MainActivity, startPath: String?) : App(act) {
    override val title = "File Explorer"
    override val icon = "\uD83D\uDCC1"

    private val root: File = Environment.getExternalStorageDirectory()
    private var dir: File = startPath?.let { File(it) }?.takeIf { it.isDirectory } ?: root
    private val back = ArrayList<File>()
    private var items: List<File> = emptyList()
    private var clip: List<File> = emptyList()
    private var clipCut = false
    private var selected: File? = null
    private var showHidden = false
    private var lastTool = MotionEvent.TOOL_TYPE_FINGER
    private var lastClick = 0L
    private val df = SimpleDateFormat("dd MMM yyyy HH:mm", Locale.getDefault())

    private lateinit var list: ListView
    private lateinit var pathBar: EditText
    private lateinit var status: TextView
    private lateinit var banner: LinearLayout

    private val textExts = setOf(
        "txt", "md", "log", "json", "xml", "csv", "ini", "cfg", "conf", "yml", "yaml",
        "kt", "java", "py", "js", "html", "css", "sh", "gradle", "properties"
    )

    private val adapter = object : BaseAdapter() {
        override fun getCount() = items.size
        override fun getItem(position: Int): Any = items[position]
        override fun getItemId(position: Int) = position.toLong()
        override fun getView(position: Int, convertView: View?, parent: ViewGroup?): View {
            val f = items[position]
            val row = (convertView as? LinearLayout) ?: makeRow()
            bind(row, f)
            return row
        }
    }

    private fun hasAccess(): Boolean =
        if (Build.VERSION.SDK_INT >= 30) Environment.isExternalStorageManager()
        else act.checkSelfPermission(Manifest.permission.READ_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED

    private fun requestAccess() {
        if (Build.VERSION.SDK_INT >= 30) {
            val i = Intent(Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION, Uri.parse("package:" + act.packageName))
            if (!act.startSafely(i)) act.startSafely(Intent(Settings.ACTION_MANAGE_ALL_FILES_ACCESS_PERMISSION))
        } else {
            act.requestPermissions(
                arrayOf(Manifest.permission.READ_EXTERNAL_STORAGE, Manifest.permission.WRITE_EXTERNAL_STORAGE), 1
            )
        }
    }

    override fun build(): View {
        val rootView = LinearLayout(act)
        rootView.orientation = LinearLayout.VERTICAL
        rootView.setBackgroundColor(Ui.bgDark)

        // toolbar
        val tb = LinearLayout(act)
        tb.orientation = LinearLayout.HORIZONTAL
        tb.gravity = Gravity.CENTER_VERTICAL
        tb.setBackgroundColor(Ui.bar)
        tb.setPadding(act.dp(6), act.dp(4), act.dp(6), act.dp(4))
        tb.addView(tool("\u2190") { goBack() }, lp(act.dp(34), act.dp(32)))
        tb.addView(tool("\u2191") { goUp() }, lp(act.dp(34), act.dp(32)))
        tb.addView(tool("\u27F3") { load() }, lp(act.dp(34), act.dp(32)))
        pathBar = EditText(act)
        pathBar.setSingleLine()
        pathBar.textSize = 13f
        pathBar.setTextColor(Ui.text)
        pathBar.background = Ui.rect(Ui.field, act.dp(6).toFloat())
        pathBar.setPadding(act.dp(10), 0, act.dp(10), 0)
        pathBar.imeOptions = android.view.inputmethod.EditorInfo.IME_ACTION_GO
        pathBar.setOnEditorActionListener { v, _, _ ->
            val f = File(v.text.toString().trim())
            if (f.isDirectory) navigate(f) else Toast.makeText(act, "Folder not found", Toast.LENGTH_SHORT).show()
            true
        }
        val pl = lp(0, act.dp(32), 1f)
        pl.setMargins(act.dp(4), 0, act.dp(4), 0)
        tb.addView(pathBar, pl)
        tb.addView(tool("\uFF0B") { askText("New folder", "New folder") { n -> newFolder(n) } }, lp(act.dp(34), act.dp(32)))
        rootView.addView(tb, lp(MATCH, WRAP))

        // permission banner
        banner = LinearLayout(act)
        banner.orientation = LinearLayout.HORIZONTAL
        banner.gravity = Gravity.CENTER_VERTICAL
        banner.setBackgroundColor(Ui.warn)
        banner.setPadding(act.dp(10), act.dp(6), act.dp(10), act.dp(6))
        val bt = TextView(act)
        bt.text = "File access is off. Allow it to see your files."
        bt.textSize = 12f
        bt.setTextColor(Ui.text)
        banner.addView(bt, lp(0, WRAP, 1f))
        banner.addView(Ui.button(act, "Allow") { requestAccess() }, lp(WRAP, WRAP))
        rootView.addView(banner, lp(MATCH, WRAP))

        // body = sidebar + list
        val body = LinearLayout(act)
        body.orientation = LinearLayout.HORIZONTAL
        val side = ScrollView(act)
        side.setBackgroundColor(Ui.side)
        val sideCol = LinearLayout(act)
        sideCol.orientation = LinearLayout.VERTICAL
        sideCol.setPadding(act.dp(4), act.dp(6), act.dp(4), act.dp(6))
        side.addView(sideCol, lp(MATCH, WRAP))
        fun quick(label: String, f: File) {
            val t = TextView(act)
            t.text = label
            t.textSize = 13f
            t.setTextColor(Ui.text)
            t.setPadding(act.dp(10), act.dp(8), act.dp(6), act.dp(8))
            t.isClickable = true
            t.background = Ui.stateBg(act.dp(5).toFloat())
            t.setOnClickListener { navigate(f) }
            t.hand()
            sideCol.addView(t, lp(MATCH, WRAP))
        }
        quick("\uD83D\uDCBE  Internal storage", root)
        quick("\u2B07\uFE0F  Downloads", File(root, "Download"))
        quick("\uD83D\uDCC4  Documents", File(root, "Documents"))
        quick("\uD83D\uDDBC\uFE0F  Pictures", File(root, "Pictures"))
        quick("\uD83D\uDCF7  Camera", File(root, "DCIM"))
        quick("\uD83C\uDFB5  Music", File(root, "Music"))
        quick("\uD83C\uDFAC  Movies", File(root, "Movies"))
        body.addView(side, lp(act.dp(132), MATCH))

        list = ListView(act)
        list.adapter = adapter
        list.divider = null
        list.setOnContextClickListener { emptyMenu(list); true }
        list.setOnLongClickListener { emptyMenu(list); true }
        body.addView(list, lp(0, MATCH, 1f))
        rootView.addView(body, lp(MATCH, 0, 1f))

        status = TextView(act)
        status.textSize = 11f
        status.setTextColor(Ui.textDim)
        status.setBackgroundColor(Ui.side)
        status.setPadding(act.dp(10), act.dp(3), act.dp(10), act.dp(3))
        rootView.addView(status, lp(MATCH, WRAP))

        load()
        return rootView
    }

    private fun tool(label: String, onClick: () -> Unit): TextView {
        val t = TextView(act)
        t.text = label
        t.textSize = 16f
        t.setTextColor(Ui.text)
        t.gravity = Gravity.CENTER
        t.isClickable = true
        t.background = Ui.stateBg(act.dp(6).toFloat())
        t.setOnClickListener { onClick() }
        t.hand()
        return t
    }

    private fun makeRow(): LinearLayout {
        val row = LinearLayout(act)
        row.orientation = LinearLayout.HORIZONTAL
        row.gravity = Gravity.CENTER_VERTICAL
        row.isClickable = true
        row.background = Ui.stateBg(act.dp(4).toFloat())
        row.setPadding(act.dp(8), 0, act.dp(8), 0)
        row.minimumHeight = act.dp(36)
        val ic = TextView(act)
        ic.textSize = 17f
        row.addView(ic, lp(act.dp(30), WRAP))
        val name = TextView(act)
        name.textSize = 13f
        name.setTextColor(Ui.text)
        name.setSingleLine()
        name.ellipsize = android.text.TextUtils.TruncateAt.MIDDLE
        row.addView(name, lp(0, WRAP, 1f))
        val date = TextView(act)
        date.textSize = 11f
        date.setTextColor(Ui.textDim)
        date.setSingleLine()
        row.addView(date, lp(act.dp(112), WRAP))
        val size = TextView(act)
        size.textSize = 11f
        size.setTextColor(Ui.textDim)
        size.gravity = Gravity.END
        size.setSingleLine()
        row.addView(size, lp(act.dp(70), WRAP))
        return row
    }

    private fun bind(row: LinearLayout, f: File) {
        (row.getChildAt(0) as TextView).text = iconFor(f)
        (row.getChildAt(1) as TextView).text = f.name
        (row.getChildAt(2) as TextView).text = df.format(Date(f.lastModified()))
        (row.getChildAt(3) as TextView).text = if (f.isDirectory) "" else humanSize(f.length())
        row.isSelected = (f == selected)
        row.setOnTouchListener { _, e ->
            if (e.actionMasked == MotionEvent.ACTION_DOWN) lastTool = e.getToolType(0)
            false
        }
        row.setOnClickListener { rowClick(f) }
        row.setOnLongClickListener { showMenu(row, f); true }
        row.setOnContextClickListener { showMenu(row, f); true }
    }

    private fun iconFor(f: File): String {
        if (f.isDirectory) return "\uD83D\uDCC1"
        return when (f.extension.lowercase()) {
            "jpg", "jpeg", "png", "gif", "webp", "bmp" -> "\uD83D\uDDBC\uFE0F"
            "mp3", "wav", "flac", "m4a", "ogg", "aac" -> "\uD83C\uDFB5"
            "mp4", "mkv", "avi", "mov", "webm", "3gp" -> "\uD83C\uDFAC"
            "pdf" -> "\uD83D\uDCD5"
            "zip", "rar", "7z", "tar", "gz" -> "\uD83D\uDDDC\uFE0F"
            "apk" -> "\uD83D\uDCE6"
            else -> if (f.extension.lowercase() in textExts) "\uD83D\uDCDD" else "\uD83D\uDCC4"
        }
    }

    private fun humanSize(b: Long): String {
        if (b < 1024) return "$b B"
        val kb = b / 1024.0
        if (kb < 1024) return String.format(Locale.US, "%.0f KB", kb)
        val mb = kb / 1024
        if (mb < 1024) return String.format(Locale.US, "%.1f MB", mb)
        return String.format(Locale.US, "%.2f GB", mb / 1024)
    }

    private fun rowClick(f: File) {
        if (lastTool == MotionEvent.TOOL_TYPE_MOUSE) {
            val now = SystemClock.uptimeMillis()
            if (selected == f && now - lastClick < 450) {
                lastClick = 0
                open(f)
            } else {
                selected = f
                lastClick = now
                adapter.notifyDataSetChanged()
                updateStatus()
            }
        } else {
            selected = f
            adapter.notifyDataSetChanged()
            open(f)
        }
    }

    private fun navigate(f: File, push: Boolean = true) {
        if (!f.isDirectory) {
            Toast.makeText(act, "${f.name} isn't available", Toast.LENGTH_SHORT).show()
            return
        }
        if (push && f != dir) back.add(dir)
        dir = f
        selected = null
        load()
    }

    private fun goBack() {
        if (back.isNotEmpty()) navigate(back.removeAt(back.size - 1), false)
    }

    private fun goUp() {
        dir.parentFile?.let { navigate(it) }
    }

    fun load() {
        val arr = dir.listFiles()
        items = (arr ?: emptyArray<File>())
            .filter { showHidden || !it.name.startsWith(".") }
            .sortedWith(compareBy<File>({ !it.isDirectory }, { it.name.lowercase() }))
        adapter.notifyDataSetChanged()
        pathBar.setText(dir.absolutePath)
        banner.visibility = if (hasAccess()) View.GONE else View.VISIBLE
        updateStatus(arr == null)
        val n = if (dir.name.isEmpty()) "/" else dir.name
        window?.setTitle("$n - File Explorer")
    }

    private fun updateStatus(denied: Boolean = false) {
        val sel = selected
        status.text = when {
            denied -> "Can't open this folder"
            sel != null -> "${items.size} items   \u2022   ${sel.name} selected"
            else -> "${items.size} items"
        }
    }

    override fun currentArg(): String? = dir.absolutePath

    private fun open(f: File) {
        if (f.isDirectory) {
            navigate(f)
            return
        }
        act.openFileSmart(f.absolutePath)
    }

    private fun showMenu(anchor: View, f: File) {
        selected = f
        adapter.notifyDataSetChanged()
        updateStatus()
        val m = PopupMenu(act, anchor)
        m.menu.add(0, 1, 0, "Open")
        m.menu.add(0, 2, 1, "Copy")
        m.menu.add(0, 3, 2, "Cut")
        if (clip.isNotEmpty() && f.isDirectory) m.menu.add(0, 4, 3, "Paste into folder")
        m.menu.add(0, 5, 4, "Rename")
        m.menu.add(0, 6, 5, "Delete")
        m.menu.add(0, 7, 6, "Properties")
        m.setOnMenuItemClickListener {
            when (it.itemId) {
                1 -> open(f)
                2 -> copy(f, false)
                3 -> copy(f, true)
                4 -> paste(f)
                5 -> rename(f)
                6 -> delete(f)
                7 -> properties(f)
            }
            true
        }
        m.show()
    }

    private fun emptyMenu(anchor: View) {
        val m = PopupMenu(act, anchor)
        m.menu.add(0, 1, 0, "New folder")
        m.menu.add(0, 2, 1, "New text file")
        if (clip.isNotEmpty()) m.menu.add(0, 3, 2, "Paste")
        m.menu.add(0, 4, 3, "Refresh")
        m.menu.add(0, 5, 4, if (showHidden) "Hide hidden files" else "Show hidden files")
        m.setOnMenuItemClickListener {
            when (it.itemId) {
                1 -> askText("New folder", "New folder") { n -> newFolder(n) }
                2 -> askText("New text file", "New file.txt") { n -> newFile(n) }
                3 -> paste(dir)
                4 -> load()
                5 -> { showHidden = !showHidden; load() }
            }
            true
        }
        m.show()
    }

    private fun toast(s: String) = Toast.makeText(act, s, Toast.LENGTH_SHORT).show()

    private fun askText(title: String, initial: String, ok: (String) -> Unit) {
        val input = EditText(act)
        input.setSingleLine()
        input.setText(initial)
        input.selectAll()
        AlertDialog.Builder(act)
            .setTitle(title)
            .setView(input)
            .setPositiveButton("OK") { _, _ ->
                val n = input.text.toString().trim()
                if (n.isNotEmpty() && !n.contains("/")) ok(n)
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    private fun newFolder(n: String) {
        if (File(dir, n).mkdirs()) load() else toast("Couldn't create folder")
    }

    private fun newFile(n: String) {
        try {
            if (File(dir, n).createNewFile()) load() else toast("Couldn't create file")
        } catch (e: Exception) {
            toast("Couldn't create file")
        }
    }

    private fun copy(f: File, cut: Boolean) {
        clip = listOf(f)
        clipCut = cut
        toast(if (cut) "Cut ${f.name}" else "Copied ${f.name}")
    }

    private fun uniqueName(target: File, src: File): File {
        val base = src.nameWithoutExtension
        val ext = if (src.isDirectory || src.extension.isEmpty()) "" else "." + src.extension
        var n = 1
        var dst = File(target, "$base - Copy$ext")
        while (dst.exists()) {
            n++
            dst = File(target, "$base - Copy ($n)$ext")
        }
        return dst
    }

    private fun paste(target: File) {
        val files = clip
        val cut = clipCut
        Thread {
            var err = 0
            for (src in files) {
                try {
                    if (src.isDirectory && target.absolutePath.startsWith(src.absolutePath)) {
                        err++
                        continue
                    }
                    var dst = File(target, src.name)
                    if (dst.exists()) dst = uniqueName(target, src)
                    if (cut) {
                        if (!src.renameTo(dst)) {
                            src.copyRecursively(dst)
                            src.deleteRecursively()
                        }
                    } else {
                        src.copyRecursively(dst)
                    }
                } catch (e: Exception) {
                    err++
                }
            }
            act.runOnUiThread {
                if (cut) clip = emptyList()
                load()
                if (err > 0) toast("$err item(s) failed")
            }
        }.start()
    }

    private fun rename(f: File) {
        askText("Rename", f.name) { n ->
            if (!f.renameTo(File(f.parentFile, n))) toast("Rename failed")
            load()
        }
    }

    private fun delete(f: File) {
        AlertDialog.Builder(act)
            .setTitle("Delete")
            .setMessage("Delete \"${f.name}\"? This can't be undone.")
            .setPositiveButton("Delete") { _, _ ->
                Thread {
                    f.deleteRecursively()
                    act.runOnUiThread {
                        if (selected == f) selected = null
                        load()
                    }
                }.start()
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    private fun properties(f: File) {
        val sb = StringBuilder()
        sb.append("Name: ").append(f.name).append("\n")
        sb.append("Location: ").append(f.parent ?: "").append("\n")
        if (f.isDirectory) sb.append("Items: ").append(f.listFiles()?.size ?: 0).append("\n")
        else sb.append("Size: ").append(humanSize(f.length())).append("\n")
        sb.append("Modified: ").append(df.format(Date(f.lastModified())))
        AlertDialog.Builder(act).setTitle("Properties").setMessage(sb.toString()).setPositiveButton("OK", null).show()
    }

    override fun onResume() {
        if (this::list.isInitialized) load()
    }

    override fun onBack(): Boolean {
        if (back.isNotEmpty()) {
            goBack()
            return true
        }
        return false
    }

    override fun onShortcut(e: KeyEvent): Boolean {
        val k = e.keyCode
        if (k == KeyEvent.KEYCODE_F5) {
            load()
            return true
        }
        if (act.currentFocus is EditText) return false
        val sel = selected
        if (e.isCtrlPressed) {
            when (k) {
                KeyEvent.KEYCODE_C -> { sel?.let { copy(it, false) }; return true }
                KeyEvent.KEYCODE_X -> { sel?.let { copy(it, true) }; return true }
                KeyEvent.KEYCODE_V -> { if (clip.isNotEmpty()) paste(dir); return true }
            }
            return false
        }
        when (k) {
            KeyEvent.KEYCODE_FORWARD_DEL -> { sel?.let { delete(it) }; return true }
            KeyEvent.KEYCODE_F2 -> { sel?.let { rename(it) }; return true }
            KeyEvent.KEYCODE_ENTER -> { sel?.let { open(it) }; return true }
            KeyEvent.KEYCODE_DEL -> { goUp(); return true }
        }
        return false
    }
}
