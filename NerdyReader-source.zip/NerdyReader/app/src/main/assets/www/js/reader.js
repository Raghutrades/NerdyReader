'use strict';
/* ===== NerdyReader · the reader =====
   Two engines behind one screen:
   - reflow : EPUB / TXT / MD / HTML / DOCX (and PDF "text mode"): one chapter at a time, your font + theme
   - pages  : PDF original pages, lazily rendered canvases with pinch-to-zoom                           */
let RD = null; // current reading session

const THEME_BARS = { light: ['#FFFFFF', true], sepia: ['#F4ECD8', true], night: ['#1D1A22', false] };
const LH = { compact: 1.45, normal: 1.7, relaxed: 2.0 };

function applyReaderStyle() {
  const r = $('#reader');
  r.className = 't-' + ST.theme + (RD && RD.immersive ? ' imm' : '');
  r.style.setProperty('--fs', ST.size + 'px');
  r.style.setProperty('--ff', ST.font === 'serif' ? "'Source Serif 4', Georgia, serif" : "'DM Sans', system-ui, sans-serif");
  r.style.setProperty('--lh', LH[ST.lh] || 1.7);
  const [c, d] = THEME_BARS[ST.theme];
  AB && AB.setBars(c, d);
}

async function openReader(id, at) {
  const b = S.books.get(id);
  if (!b) return;
  if (RD) await closeReader(true);
  RD = { b, immersive: false, kind: null, urls: [], r: 0, ch: 0, alive: true };
  $('#reader').hidden = false;
  $('#rload').classList.remove('off');
  $('#rloadt').textContent = 'Opening…';
  $('#rtext').hidden = true; $('#rpdf').hidden = true;
  $('#rtitle').textContent = b.title;
  $('#rsub').textContent = b.author || FMT[b.format];
  $('#rcov').innerHTML = coverHTML(b, 'xs');
  $('#rbm').innerHTML = ic('bookmark', 22);
  applyReaderStyle();
  AB && AB.keepScreenOn(true);
  try {
    const blob = await DB.getFile(id);
    if (!blob) throw new Error('The file for this book is missing. Remove it and add it again.');
    RD.blob = blob;
    const pos = at || b.pos || null;
    if (b.format === 'pdf') await rdOpenPdf(pos);
    else await rdOpenReflow(pos);
    if (!b.lastRead) b.lastRead = Date.now();
    saveBook(b);
  } catch (e) {
    console.error(e);
    toast(e.message || 'Could not open this book', 5000);
    closeReader(true);
  }
}

async function closeReader(quiet) {
  if (!RD) return;
  const s = RD; RD = null; s.alive = false;
  rdFlush(s);
  try { s.P && s.P.revoke(); } catch (e) { }
  try { s.pdf && s.pdf.destroy(); } catch (e) { }
  if (s.obs) s.obs.disconnect();
  $('#rart').innerHTML = ''; $('#rpages').innerHTML = '';
  $('#reader').hidden = true;
  AB && AB.keepScreenOn(false);
  setBars('#FDF6F3', true);
  Sheet.close();
  if (!quiet) render();
}

/* ---------- progress bookkeeping ---------- */
function rdFlush(s = RD) {
  if (!s || !s.dirty) return;
  s.dirty = false;
  saveBook(s.b, true);
}
function rdMark(pos, progress) {
  const b = RD.b;
  b.pos = pos; b.progress = clamp(progress, 0, 1); b.lastRead = Date.now();
  RD.dirty = true;
  clearTimeout(RD.st);
  RD.st = setTimeout(() => RD && rdFlush(), 700);
}

/* ====================== reflow engine ====================== */
async function rdOpenReflow(pos) {
  const f = RD.b.format;
  if (f === 'pdf') { // text mode of a PDF
    if (!RD.pdf) RD.pdf = await pdfjsLib.getDocument({ data: new Uint8Array(await RD.blob.arrayBuffer()) }).promise;
    RD.P = pdfTextParser(RD.pdf, RD.b);
  } else if (f === 'epub') RD.P = await parseEpub(RD.blob);
  else if (f === 'docx') RD.P = await parseDocx(RD.blob);
  else {
    const txt = await decodeText(await RD.blob.arrayBuffer());
    RD.P = f === 'md' ? parseMd(txt, RD.b) : f === 'html' ? parseHtml(txt, RD.b) : parseTxt(txt, RD.b);
  }
  RD.kind = 'reflow';
  RD.n = RD.P.chapters.length;
  $('#rtext').hidden = false; $('#rpdf').hidden = true;
  let ch = 0, r = 0;
  if (pos) {
    if (pos.ch != null) { ch = pos.ch; r = pos.r || 0; }
    else if (pos.page && f === 'pdf') { ch = Math.floor((pos.page - 1) / 8); r = 0; }
  }
  await rdShowChapter(clamp(ch, 0, RD.n - 1), r);
  $('#rload').classList.add('off');
}

function rdWeightBefore(i) { let w = 0; for (let k = 0; k < i; k++) w += RD.P.chapters[k].words; return w; }
function rdTotalWords() { return RD.P.chapters.reduce((a, c) => a + c.words, 0) || 1; }

async function rdShowChapter(i, r = 0, frag = null) {
  const s = RD;
  $('#rload').classList.remove('off');
  const { html } = await s.P.load(i);
  if (RD !== s) return;
  RD.ch = i;
  const c = s.P.chapters[i];
  const last = i === s.n - 1;
  const art = $('#rart');
  art.innerHTML = html + `<div class="rend">${last ? '<p class="mute">— The end —</p>' : `<button class="btn pri big" data-act="r-next">Next: ${esc(shortStr(s.P.chapters[i + 1].title, 38))} ${ic('right', 18)}</button>`}</div>`;
  const el = $('#rtext');
  el.scrollTop = 0;
  // let images settle before restoring the scroll position
  const imgs = [...art.querySelectorAll('img')];
  if (imgs.length) await Promise.race([Promise.all(imgs.map(m => m.decode().catch(() => { }))), sleep(700)]);
  if (RD !== s) return;
  if (frag) { const t = document.getElementById('x-' + frag); t ? t.scrollIntoView() : (el.scrollTop = 0); }
  else el.scrollTop = r * Math.max(0, el.scrollHeight - el.clientHeight);
  $('#rload').classList.add('off');
  rdUpdate(true);
}

function rdUpdate(save) {
  if (!RD || RD.kind !== 'reflow') return;
  const el = $('#rtext'), max = el.scrollHeight - el.clientHeight;
  const r = max > 4 ? clamp(el.scrollTop / max, 0, 1) : 1;
  RD.r = r;
  const total = rdTotalWords(), c = RD.P.chapters[RD.ch];
  let prog = (rdWeightBefore(RD.ch) + r * c.words) / total;
  const atEnd = RD.ch === RD.n - 1 && r > 0.97;
  if (atEnd) prog = 1;
  const left = Math.max(0, Math.ceil(total * (1 - prog) / WPM));
  $('#rpos').textContent = RD.b.format === 'pdf' ? c.title : `Chapter ${RD.ch + 1} of ${RD.n}`;
  $('#rmeta').textContent = `${Math.round(prog * 100)}% read · ${atEnd ? 'finished' : left + ' min left'} · All chapters`;
  $('#rbm').classList.toggle('on', !!rdFindMark());
  if (save) rdMark({ ch: RD.ch, r }, prog);
}

function rdFindMark() {
  const b = RD.b;
  if (RD.kind === 'pages') return (b.bookmarks || []).find(m => m.page === RD.page);
  return (b.bookmarks || []).find(m => m.ch === RD.ch && Math.abs((m.r || 0) - RD.r) < 0.06);
}

async function rdStep(d) {
  if (!RD) return;
  if (RD.kind === 'pages') return pdfGoPage(clamp(RD.page + d, 1, RD.np));
  const i = RD.ch + d;
  if (i < 0 || i >= RD.n) { toast(d > 0 ? 'You have reached the end' : 'This is the first chapter'); return; }
  await rdShowChapter(i, 0);
}

/* ====================== PDF pages engine ====================== */
async function rdOpenPdf(pos) {
  RD.pdf = await pdfjsLib.getDocument({ data: new Uint8Array(await RD.blob.arrayBuffer()) }).promise;
  RD.np = RD.pdf.numPages;
  if (RD.b.pdfText) return rdOpenReflow(pos);
  RD.kind = 'pages';
  const p1 = await RD.pdf.getPage(1);
  RD.vp1 = p1.getViewport({ scale: 1 });
  RD.zoom = RD.b.zoom || 1;
  RD.page = 1; RD.pr = 0;
  $('#rtext').hidden = true; $('#rpdf').hidden = false;
  pdfBuild();
  let page = pos?.page || 1, r = pos?.r || 0;
  if (pos && pos.ch != null && !pos.page) { page = 1 + pos.ch * 8; r = 0; }
  await sleep(30);
  pdfScrollTo(clamp(page, 1, RD.np), r);
  $('#rload').classList.add('off');
  pdfUpdate(false);
  pdfBindGestures();
}

function pdfBuild() {
  const wrap = $('#rpdf'), box = $('#rpages');
  if (RD.obs) RD.obs.disconnect();
  box.innerHTML = '';
  RD.fit = Math.max(120, wrap.clientWidth - 16) / RD.vp1.width;
  const sc = RD.fit * RD.zoom, w = RD.vp1.width * sc, h = RD.vp1.height * sc;
  const frag = document.createDocumentFragment();
  RD.holders = [];
  for (let i = 1; i <= RD.np; i++) {
    const d = document.createElement('div');
    d.className = 'pg'; d.dataset.i = i; d._gen = 0;
    d.style.width = w + 'px'; d.style.height = h + 'px';
    RD.holders.push(d); frag.appendChild(d);
  }
  box.appendChild(frag);
  RD.obs = new IntersectionObserver(es => {
    for (const e of es) { const i = +e.target.dataset.i; e.isIntersecting ? pdfRender(i) : pdfRelease(i); }
  }, { root: wrap, rootMargin: '120% 0px' });
  RD.holders.forEach(h => RD.obs.observe(h));
}

async function pdfRender(i) {
  const s = RD, h = s.holders[i - 1];
  if (h._on) return;
  h._on = true; const gen = ++h._gen;
  try {
    const page = await s.pdf.getPage(i);
    if (RD !== s || gen !== h._gen) return;
    const css = s.fit * s.zoom, vp = page.getViewport({ scale: css });
    h.style.width = vp.width + 'px'; h.style.height = vp.height + 'px';
    let q = Math.min(window.devicePixelRatio || 1, 2.5);
    if (vp.width * vp.height * q * q > 12e6) q = Math.sqrt(12e6 / (vp.width * vp.height));
    const cv = document.createElement('canvas');
    cv.width = Math.floor(vp.width * q); cv.height = Math.floor(vp.height * q);
    cv.style.width = vp.width + 'px'; cv.style.height = vp.height + 'px';
    const task = page.render({ canvasContext: cv.getContext('2d'), viewport: page.getViewport({ scale: css * q }), background: '#ffffff' });
    h._task = task;
    await task.promise;
    if (RD !== s || gen !== h._gen) return;
    h.replaceChildren(cv);
    page.cleanup();
  } catch (e) {
    if (e && e.name !== 'RenderingCancelledException') console.warn('page', i, e);
    h._on = false;
  }
}
function pdfRelease(i) {
  const h = RD && RD.holders[i - 1];
  if (!h || !h._on) return;
  h._on = false; h._gen++;
  try { h._task && h._task.cancel(); } catch (e) { }
  h.replaceChildren();
}

function pdfScrollTo(page, r = 0) {
  const wrap = $('#rpdf'), h = RD.holders[page - 1];
  if (!h) return;
  wrap.scrollTop = h.offsetTop + h.offsetHeight * r - 72;
}
function pdfGoPage(p) { pdfScrollTo(p, 0); setTimeout(() => pdfUpdate(true), 60); }

function pdfCurrent() {
  const wrap = $('#rpdf'), hs = RD.holders;
  const y = wrap.scrollTop + wrap.clientHeight * 0.35;
  let lo = 0, hi = hs.length - 1;
  while (lo < hi) { const mid = (lo + hi + 1) >> 1; if (hs[mid].offsetTop <= y) lo = mid; else hi = mid - 1; }
  const h = hs[lo];
  return { page: lo + 1, r: clamp((y - h.offsetTop) / Math.max(1, h.offsetHeight), 0, 1) };
}
function pdfUpdate(save) {
  if (!RD || RD.kind !== 'pages') return;
  const wrap = $('#rpdf');
  const { page, r } = pdfCurrent();
  RD.page = page; RD.pr = r;
  const atEnd = wrap.scrollTop + wrap.clientHeight >= wrap.scrollHeight - 30;
  const prog = atEnd && page >= RD.np ? 1 : (page - 1 + r) / RD.np;
  $('#rpos').textContent = `Page ${page} of ${RD.np}`;
  const left = Math.max(0, RD.np - page);
  $('#rmeta').textContent = `${Math.round(prog * 100)}% read · ${left} page${left === 1 ? '' : 's'} left · Contents`;
  $('#rbm').classList.toggle('on', !!rdFindMark());
  if (save) rdMark({ page, r }, prog);
}

function pdfSetZoom(z, keep = true) {
  z = clamp(z, 0.5, 4);
  const { page, r } = RD.page ? { page: RD.page, r: RD.pr } : { page: 1, r: 0 };
  RD.zoom = z; RD.b.zoom = z; saveBook(RD.b);
  pdfBuild();
  if (keep) pdfScrollTo(page, r);
  pdfUpdate(false);
}

/* two-finger pinch: scale the whole column while the fingers move, re-render sharp on release */
function pdfBindGestures() {
  const wrap = $('#rpdf'), box = $('#rpages');
  if (wrap._bound) return; wrap._bound = true;
  let d0 = 0, z0 = 1, cx = 0, cy = 0, mx = 0, my = 0, live = false, scale = 1;
  const dist = t => Math.hypot(t[0].clientX - t[1].clientX, t[0].clientY - t[1].clientY);
  wrap.addEventListener('touchstart', e => {
    if (e.touches.length === 2 && RD && RD.kind === 'pages') {
      live = true; d0 = dist(e.touches); z0 = RD.zoom; scale = 1;
      const rc = wrap.getBoundingClientRect();
      mx = (e.touches[0].clientX + e.touches[1].clientX) / 2 - rc.left;
      my = (e.touches[0].clientY + e.touches[1].clientY) / 2 - rc.top;
      cx = wrap.scrollLeft + mx; cy = wrap.scrollTop + my;
      box.style.transformOrigin = `${cx}px ${cy}px`;
    }
  }, { passive: true });
  wrap.addEventListener('touchmove', e => {
    if (!live || e.touches.length !== 2) return;
    e.preventDefault();
    scale = clamp(dist(e.touches) / d0, 0.4 / z0, 4 / z0);
    box.style.transform = `scale(${scale})`;
  }, { passive: false });
  const end = () => {
    if (!live) return; live = false;
    box.style.transform = ''; box.style.transformOrigin = '';
    if (Math.abs(scale - 1) < 0.03) return;
    const nz = clamp(z0 * scale, 0.5, 4), ratio = nz / z0;
    pdfSetZoom(nz, false);
    wrap.scrollLeft = cx * ratio - mx; wrap.scrollTop = cy * ratio - my;
    pdfUpdate(true);
  };
  wrap.addEventListener('touchend', end, { passive: true });
  wrap.addEventListener('touchcancel', end, { passive: true });
}

/* ====================== sheets: text settings / contents ====================== */
function openAa() {
  const pdfPages = RD.kind === 'pages', isPdf = RD.b.format === 'pdf';
  const seg = (key, opts) => `<div class="seg3">${opts.map(([v, t]) => `<button class="${ST[key] === v ? 'on' : ''} ${key === 'theme' ? 'th-' + v : ''}" data-act="set" data-k="${key}" data-v="${v}">${t}</button>`).join('')}</div>`;
  const textBlock = `<div class="lbl" id="szl">TEXT SIZE · ${ST.size} PX</div>
    <div class="slr"><button class="btn sq" data-act="size" data-d="-1">A-</button><input type="range" id="szr" min="14" max="36" value="${ST.size}"><button class="btn sq" data-act="size" data-d="1">A+</button></div>
    <div class="lbl">FONT</div>${seg('font', [['serif', 'Serif'], ['sans', 'Sans']])}
    <div class="lbl">LINE SPACING</div>${seg('lh', [['compact', 'Compact'], ['normal', 'Normal'], ['relaxed', 'Relaxed']])}`;
  const zoomBlock = `<div class="lbl" id="zml">ZOOM · ${Math.round(RD.zoom * 100)}%</div>
    <div class="slr"><button class="btn sq" data-act="zoom" data-d="-0.25">${ic('minus', 18)}</button><input type="range" id="zmr" min="50" max="400" step="5" value="${Math.round(RD.zoom * 100)}"><button class="btn sq" data-act="zoom" data-d="0.25">${ic('plus', 18)}</button></div>
    <button class="btn wide" data-act="zoom-fit">${ic('fit', 16)} Fit to width</button>`;
  Sheet.open(`${pdfPages ? zoomBlock : textBlock}
    <div class="lbl">THEME</div>${seg('theme', [['light', 'Light'], ['sepia', 'Sepia'], ['night', 'Night']])}
    ${isPdf ? `<button class="btn wide" data-act="pdf-mode" style="margin-top:12px">${pdfPages ? 'Read as reflowable text' : 'View the original PDF pages'}</button>` : ''}`, { title: pdfPages ? 'Page settings' : 'Text settings', cls: 'compact' });
  const r = $('#szr'); if (r) r.oninput = () => { ST.size = +r.value; $('#szl').textContent = 'TEXT SIZE · ' + ST.size + ' PX'; saveST(); applyReaderStyle(); };
  const z = $('#zmr'); if (z) { z.oninput = () => { $('#zml').textContent = 'ZOOM · ' + z.value + '%'; }; z.onchange = () => pdfSetZoom(+z.value / 100); }
}

async function openToc() {
  const b = RD.b;
  const marks = (b.bookmarks || []).slice().sort((x, y) => (x.page || x.ch * 1000) - (y.page || y.ch * 1000) || (x.r - y.r));
  const tabs = `<div class="seg" style="margin:0 0 10px"><button class="on" data-act="toc-tab" data-v="toc">Contents</button><button data-act="toc-tab" data-v="marks">Bookmarks${marks.length ? ' ' + marks.length : ''}</button></div>`;
  const marksHtml = marks.length ? marks.map(m => `<div class="tocrow"><a data-act="go-mark" data-id="${m.id}"><b>${esc(m.label)}</b><small>${ago(m.t)}</small></a><button class="ib soft" data-act="del-mark" data-id="${m.id}" aria-label="Delete">${ic('trash', 16)}</button></div>`).join('') : '<p class="sm mute">No bookmarks yet. Tap the bookmark icon at the top while reading.</p>';
  let tocHtml = '';
  if (RD.kind === 'reflow') {
    tocHtml = RD.P.chapters.map((c, i) => `<a class="tocrow ${i === RD.ch ? 'cur' : ''}" data-act="go-ch" data-i="${i}"><span class="tn">${i + 1}</span><b>${esc(shortStr(c.title, 60))}</b></a>`).join('');
  } else {
    tocHtml = `<div class="row gap" style="margin-bottom:10px"><input id="gopage" class="inp" type="number" min="1" max="${RD.np}" placeholder="Go to page (1–${RD.np})"><button class="btn pri" data-act="go-page">Go</button></div><div id="outl"><p class="sm mute">Loading outline…</p></div>`;
  }
  Sheet.open(`${tabs}<div id="tocbody">${tocHtml}</div><div id="marksbody" hidden>${marksHtml}</div>`, {
    title: RD.kind === 'reflow' ? 'All chapters' : 'Contents',
    onMount: s => { const c = s.querySelector('.tocrow.cur'); c && c.scrollIntoView({ block: 'center' }); },
  });
  if (RD.kind === 'pages') {
    try {
      const ol = await RD.pdf.getOutline();
      const flat = []; (function walk(a, d) { (a || []).forEach(n => { flat.push({ t: n.title, d, dest: n.dest }); walk(n.items, d + 1); }); })(ol, 0);
      RD.outline = flat;
      const o = $('#outl');
      if (o) o.innerHTML = flat.length ? flat.slice(0, 400).map((n, i) => `<a class="tocrow" style="padding-left:${12 + n.d * 16}px" data-act="go-out" data-i="${i}"><b>${esc(shortStr(n.t || 'Untitled', 60))}</b></a>`).join('') : '<p class="sm mute">This PDF has no table of contents. Use “Go to page”.</p>';
    } catch (e) { const o = $('#outl'); if (o) o.innerHTML = ''; }
  }
}

function toggleMark() {
  const b = RD.b; b.bookmarks = b.bookmarks || [];
  const ex = rdFindMark();
  if (ex) { b.bookmarks = b.bookmarks.filter(m => m !== ex); toast('Bookmark removed'); }
  else {
    const m = { id: uid(), t: Date.now() };
    if (RD.kind === 'pages') { m.page = RD.page; m.r = RD.pr; m.label = `Page ${RD.page}`; }
    else { m.ch = RD.ch; m.r = RD.r; m.label = `${shortStr(RD.P.chapters[RD.ch].title, 40)} · ${Math.round((b.progress || 0) * 100)}%`; }
    b.bookmarks.push(m); toast('Bookmarked');
  }
  saveBook(b, true);
  $('#rbm').classList.toggle('on', !!rdFindMark());
}

async function switchPdfMode() {
  const b = RD.b, toText = RD.kind === 'pages';
  const pos = toText ? { ch: Math.floor((RD.page - 1) / 8), r: 0 } : { page: Math.min(RD.np, 1 + RD.ch * 8), r: 0 };
  Sheet.close();
  b.pdfText = toText; saveBook(b, true);
  const s = RD;
  if (s.obs) s.obs.disconnect();
  $('#rpages').innerHTML = '';
  $('#rload').classList.remove('off');
  if (toText) await rdOpenReflow(pos);
  else {
    RD.kind = 'pages';
    const p1 = await RD.pdf.getPage(1); RD.vp1 = p1.getViewport({ scale: 1 });
    RD.zoom = b.zoom || 1;
    $('#rtext').hidden = true; $('#rpdf').hidden = false;
    pdfBuild(); await sleep(30); pdfScrollTo(pos.page, 0);
    $('#rload').classList.add('off'); pdfUpdate(true); pdfBindGestures();
  }
}

/* reader scroll + tap */
function bindReaderEvents() {
  let t;
  const onScroll = () => { clearTimeout(t); t = setTimeout(() => { rdUpdate(true); }, 120); };
  $('#rtext').addEventListener('scroll', onScroll, { passive: true });
  let pt;
  $('#rpdf').addEventListener('scroll', () => { clearTimeout(pt); pt = setTimeout(() => pdfUpdate(true), 120); }, { passive: true });
  // single tap on text toggles the bars (not on links / buttons)
  let down = null;
  const wrapTap = e => {
    if (e.target.closest('a,button,input')) return;
    if (!RD) return;
    RD.immersive = !RD.immersive;
    $('#reader').classList.toggle('imm', RD.immersive);
  };
  ['#rtext', '#rpdf'].forEach(sel => {
    const el = $(sel);
    el.addEventListener('pointerdown', e => { down = { x: e.clientX, y: e.clientY, t: Date.now() }; });
    el.addEventListener('pointerup', e => {
      if (down && Math.hypot(e.clientX - down.x, e.clientY - down.y) < 8 && Date.now() - down.t < 400) wrapTap(e);
      down = null;
    });
  });
  $('#rart').addEventListener('click', e => {
    const a = e.target.closest('a'); if (!a) return;
    if (a.dataset.ch != null) { e.preventDefault(); rdShowChapter(+a.dataset.ch, 0, a.dataset.frag || null); }
    else if ((a.getAttribute('href') || '').startsWith('#')) e.preventDefault();
  });
}
