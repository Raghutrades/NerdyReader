'use strict';
/* ===== NerdyReader · welcome film (about 4.4 seconds) =====
   A night sky with a soft aurora and drifting fireflies; a glowing book rises, opens and lets go a burst of sparkles;
   the name appears in a sweep of light; then the screen opens into the app.
   The music is made on the spot (bells, a warm pad and a page rustle), so there is no sound file.
   Tap to skip. Turn the film or its sound off in Themes & sound. */
const Splash = {
  el: null, timer: null, replaying: false, raf: 0, ac: null, mg: null,
  run(replay) {
    const el = this.el = $('#splash');
    if (!el) return;
    if (!replay && ST.splash === false) { el.remove(); return; }
    clearTimeout(this.timer); cancelAnimationFrame(this.raf);
    try {
      const L = JSON.parse(localStorage.getItem('nr-qsp') || '[]'), q = L[Math.floor(Math.random() * L.length)], s = el.querySelector('.sp-s');
      if (q && s) { s.classList.add('qt'); s.innerHTML = '“' + esc(q.t) + '”' + (q.b ? '<small>' + esc(shortStr(q.b, 40)) + '</small>' : ''); }
    } catch (e) { }
    this.replaying = !!replay;
    el.hidden = false; el.classList.remove('out');
    if (replay) { el.style.display = 'none'; void el.offsetWidth; el.style.display = ''; }
    this.scene(); this.sound();
    this.timer = setTimeout(() => this.hide(), replay ? 4600 : Math.max(1200, 4600 - performance.now()));
  },
  hide() {
    const el = this.el;
    if (!el || el.classList.contains('out')) return;
    clearTimeout(this.timer);
    el.classList.add('out');
    try { if (this.mg) { this.mg.gain.cancelScheduledValues(this.ac.currentTime); this.mg.gain.setTargetAtTime(0, this.ac.currentTime, 0.18); } } catch (e) { }
    setTimeout(() => {
      cancelAnimationFrame(this.raf);
      try { this.ac && this.ac.close(); } catch (e) { } this.ac = null;
      if (el.classList.contains('out')) { if (this.replaying) el.hidden = true; else el.remove(); }
    }, 900);
  },

  /* ---------- the picture ---------- */
  scene() {
    const cv = $('#spc'), g = cv.getContext('2d'), dpr = Math.min(window.devicePixelRatio || 1, 2);
    const W = cv.width = Math.round(innerWidth * dpr), H = cv.height = Math.round(innerHeight * dpr);
    const cs = getComputedStyle(document.documentElement), c1 = cs.getPropertyValue('--p1').trim() || '#f26a2e', c2 = cs.getPropertyValue('--p2').trim() || '#d6336c';
    const R = (a, b) => a + Math.random() * (b - a), u = dpr;
    const stars = Array.from({ length: 150 }, () => ({ x: R(0, W), y: R(0, H * 0.78), r: R(0.5, 1.7) * u, p: R(0, 6.28), s: R(0.8, 2.6) }));
    const flies = Array.from({ length: 22 }, () => ({ x: R(0, W), y: R(H * 0.35, H), r: R(1.6, 3.4) * u, p: R(0, 6.28), sp: R(0.2, 0.6), a: R(10, 30) * u }));
    let parts = [], burst = false;
    const cx = W / 2, cy = H * 0.42, t0 = performance.now();
    const spawn = (n, spread, up) => { for (let i = 0; i < n; i++) { const a = R(0, 6.283), v = R(0.3, 1) * spread * u; parts.push({ x: cx + R(-30, 30) * u, y: cy + R(-6, 20) * u, vx: Math.cos(a) * v, vy: Math.sin(a) * v - up * u, life: 0, max: R(1.4, 2.8), r: R(1.2, 3.2) * u, h: Math.random() < 0.5 ? 0 : 1, tw: R(0, 6.28) }); } };
    const star4 = (x, y, r, a) => { g.save(); g.translate(x, y); g.rotate(a); g.beginPath(); g.moveTo(0, -r); g.quadraticCurveTo(0, 0, r, 0); g.quadraticCurveTo(0, 0, 0, r); g.quadraticCurveTo(0, 0, -r, 0); g.quadraticCurveTo(0, 0, 0, -r); g.fill(); g.restore(); };
    const loop = now => {
      const t = (now - t0) / 1000;
      const sky = g.createLinearGradient(0, 0, 0, H); sky.addColorStop(0, '#070515'); sky.addColorStop(0.55, '#1b1040'); sky.addColorStop(1, '#2f1347');
      g.globalAlpha = 1; g.fillStyle = sky; g.fillRect(0, 0, W, H);
      const hz = g.createRadialGradient(cx, H * 0.78, 0, cx, H * 0.78, H * 0.6); hz.addColorStop(0, c1 + '55'); hz.addColorStop(1, 'transparent'); g.fillStyle = hz; g.fillRect(0, 0, W, H);
      // aurora ribbons
      g.globalCompositeOperation = 'lighter';
      [[c1, 0.17, 0.0], [c2, 0.14, 1.7], ['#3ad6c5', 0.09, 3.1]].forEach(([c, al, ph], k) => {
        g.beginPath(); g.moveTo(0, H);
        for (let x = 0; x <= W; x += 24 * u) g.lineTo(x, H * (0.55 + k * 0.04) + Math.sin(x / (170 * u) + t * (0.5 + k * 0.15) + ph) * 34 * u + Math.sin(x / (80 * u) - t * 0.7 + ph) * 12 * u);
        g.lineTo(W, H); g.closePath();
        const gr = g.createLinearGradient(0, H * 0.45, 0, H); gr.addColorStop(0, c + Math.round(al * 255).toString(16).padStart(2, '0')); gr.addColorStop(1, 'transparent'); g.fillStyle = gr; g.fill();
      });
      g.globalCompositeOperation = 'source-over';
      // stars
      g.fillStyle = '#fff';
      for (const s of stars) { g.globalAlpha = (0.35 + 0.65 * (0.5 + 0.5 * Math.sin(t * s.s + s.p))) * Math.min(1, t / 0.8); g.beginPath(); g.arc(s.x, s.y, s.r, 0, 6.283); g.fill(); }
      // moon
      g.globalAlpha = Math.min(1, t / 1.2) * 0.95; const mx = W * 0.8, my = H * 0.14, mr = 20 * u;
      const mg = g.createRadialGradient(mx, my, mr * 0.4, mx, my, mr * 4); mg.addColorStop(0, 'rgba(255,240,200,.35)'); mg.addColorStop(1, 'transparent'); g.fillStyle = mg; g.fillRect(mx - mr * 4, my - mr * 4, mr * 8, mr * 8);
      g.fillStyle = '#fff3d6'; g.beginPath(); g.arc(mx, my, mr, 0, 6.283); g.fill(); g.fillStyle = '#1b1040'; g.beginPath(); g.arc(mx + mr * 0.42, my - mr * 0.12, mr * 0.9, 0, 6.283); g.fill();
      // fireflies
      for (const f of flies) {
        const x = f.x + Math.sin(t * f.sp + f.p) * f.a, y = f.y - ((t * 14 * u * f.sp) % (H * 0.7)) * 0 + Math.cos(t * f.sp * 1.3 + f.p) * f.a * 0.6;
        const gl = 0.5 + 0.5 * Math.sin(t * 2 + f.p), a = Math.min(1, t / 1.2) * (0.35 + gl * 0.65);
        const gr = g.createRadialGradient(x, y, 0, x, y, f.r * 6); gr.addColorStop(0, `rgba(255,228,150,${a})`); gr.addColorStop(1, 'rgba(255,228,150,0)');
        g.globalAlpha = 1; g.fillStyle = gr; g.fillRect(x - f.r * 6, y - f.r * 6, f.r * 12, f.r * 12);
      }
      // the burst when the book opens, then a gentle fountain of sparkles
      if (t > 0.95 && !burst) { burst = true; spawn(90, 120, 40); }
      if (t > 1.2 && t < 3.6 && Math.random() < 0.55) spawn(1, 30, 70);
      g.globalCompositeOperation = 'lighter';
      parts = parts.filter(p => (p.life += 0.016) < p.max);
      for (const p of parts) {
        p.x += p.vx * 0.016; p.y += p.vy * 0.016; p.vx *= 0.985; p.vy = p.vy * 0.985 - 5 * u * 0.016;
        const k = 1 - p.life / p.max, tw = 0.6 + 0.4 * Math.sin(p.life * 12 + p.tw);
        g.globalAlpha = k * tw; g.fillStyle = p.h ? '#fff1c2' : c1;
        p.r > 2.4 * u ? star4(p.x, p.y, p.r * 2.2, p.life * 2) : (g.beginPath(), g.arc(p.x, p.y, p.r, 0, 6.283), g.fill());
      }
      g.globalCompositeOperation = 'source-over'; g.globalAlpha = 1;
      if (this.el && !this.el.hidden && t < 8) this.raf = requestAnimationFrame(loop);
    };
    this.raf = requestAnimationFrame(loop);
  },

  /* ---------- the sound: a soft pad, a page rustle, a run of bells, then a warm chord ---------- */
  sound() {
    if (ST.splashSnd === false) return;
    const AC = window.AudioContext || window.webkitAudioContext; if (!AC) return;
    try { this.ac && this.ac.close(); } catch (e) { }
    const c = this.ac = new AC(); c.resume && c.resume().catch(() => { });
    const mg = this.mg = c.createGain(); mg.gain.value = 0.9;
    const comp = c.createDynamicsCompressor(); mg.connect(comp); comp.connect(c.destination);
    const len = c.sampleRate * 2.4, ir = c.createBuffer(2, len, c.sampleRate);
    for (let ch = 0; ch < 2; ch++) { const d = ir.getChannelData(ch); for (let i = 0; i < len; i++) d[i] = (Math.random() * 2 - 1) * Math.pow(1 - i / len, 2.4); }
    const rev = c.createConvolver(); rev.buffer = ir; const wet = c.createGain(); wet.gain.value = 0.55; rev.connect(wet); wet.connect(mg);
    const dry = c.createGain(); dry.gain.value = 0.7; dry.connect(mg);
    const t0 = c.currentTime + 0.08, f = m => 440 * Math.pow(2, (m - 69) / 12);
    const tone = (t, m, dur, vol, type, send) => {
      const o = c.createOscillator(), o2 = c.createOscillator(), g = c.createGain();
      o.type = type || 'sine'; o2.type = 'sine'; o.frequency.value = f(m); o2.frequency.value = f(m) * 2.005;
      g.gain.setValueAtTime(0.0001, t); g.gain.exponentialRampToValueAtTime(vol, t + 0.012); g.gain.exponentialRampToValueAtTime(0.0001, t + dur);
      const g2 = c.createGain(); g2.gain.value = 0.28; o.connect(g); o2.connect(g2); g2.connect(g); g.connect(dry); g.connect(rev);
      o.start(t); o2.start(t); o.stop(t + dur + 0.1); o2.stop(t + dur + 0.1);
    };
    // pad that swells under everything
    [48, 55, 64, 67].forEach((m, i) => {
      const o = c.createOscillator(), lp = c.createBiquadFilter(), g = c.createGain();
      o.type = 'sawtooth'; o.frequency.value = f(m); o.detune.value = (i % 2 ? 7 : -7);
      lp.type = 'lowpass'; lp.frequency.setValueAtTime(300, t0); lp.frequency.exponentialRampToValueAtTime(1500, t0 + 2.2); lp.frequency.exponentialRampToValueAtTime(500, t0 + 4.2);
      g.gain.setValueAtTime(0.0001, t0); g.gain.exponentialRampToValueAtTime(0.05, t0 + 1.6); g.gain.exponentialRampToValueAtTime(0.0001, t0 + 4.4);
      o.connect(lp); lp.connect(g); g.connect(dry); g.connect(rev); o.start(t0); o.stop(t0 + 4.5);
    });
    // page rustle as the book opens
    const nb = c.createBuffer(1, c.sampleRate * 0.5, c.sampleRate), nd = nb.getChannelData(0);
    for (let i = 0; i < nd.length; i++) nd[i] = (Math.random() * 2 - 1) * Math.sin(Math.PI * i / nd.length);
    const ns = c.createBufferSource(), bp = c.createBiquadFilter(), ng = c.createGain();
    ns.buffer = nb; bp.type = 'bandpass'; bp.frequency.setValueAtTime(1800, t0 + 0.8); bp.frequency.exponentialRampToValueAtTime(5200, t0 + 1.3); bp.Q.value = 0.8; ng.gain.value = 0.16;
    ns.connect(bp); bp.connect(ng); ng.connect(dry); ng.connect(rev); ns.start(t0 + 0.8);
    // a low "heartbeat" glow
    tone(t0 + 0.9, 36, 1.6, 0.16, 'sine');
    // bells, running up a pentatonic scale
    [72, 76, 79, 81, 84, 88, 91].forEach((m, i) => tone(t0 + 1.12 + i * 0.115, m, 1.7, 0.1 - i * 0.004, 'triangle'));
    // the chord the title lands on
    [60, 67, 72, 76, 79].forEach((m, i) => tone(t0 + 2.0 + i * 0.03, m, 2.4, 0.08, 'sine'));
    // a few glints
    [96, 93, 98, 91].forEach((m, i) => tone(t0 + 2.5 + i * 0.3, m, 0.9, 0.035, 'sine'));
  },
};
document.addEventListener('click', e => { if (e.target.closest('#splash')) Splash.hide(); });
