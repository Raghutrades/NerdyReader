'use strict';
/* ===== NerdyReader · look a word up =====
   Long-press a word (or tap it, if you switch that on in Aa) to open its meaning. NerdyReader has no internet permission
   by design, so the meaning opens in your phone's browser; the app itself never goes online.
   Words you save are kept on the phone (a small vocabulary list, in the Quotes tab). */
const WORD = /[\p{L}\p{M}'’\-]/u;
const Dict = {
  words: [], pc: new Map(), _ate: 0,
  load() { try { this.words = JSON.parse(localStorage.getItem('nr-words')) || []; } catch (e) { this.words = []; } },
  save() { try { localStorage.setItem('nr-words', JSON.stringify(this.words)); } catch (e) { } },
  clean(w) { return (w || '').replace(/^[^\p{L}]+|[^\p{L}]+$/gu, '').replace(/['’]s$/i, ''); },
  ext(url) { if (AB && AB.openUrl) AB.openUrl(url); else window.open(url, '_blank'); },

  /* ----- find the word under a point ----- */
  async at(x, y) {
    if (!RD) return null;
    const el = document.elementFromPoint(x, y);
    if (el && el.closest('#rart, .bkwin')) {                          // real text: ask the browser where the caret would be
      let r = null;
      if (document.caretRangeFromPoint) r = document.caretRangeFromPoint(x, y);
      else if (document.caretPositionFromPoint) { const c = document.caretPositionFromPoint(x, y); if (c) { r = document.createRange(); r.setStart(c.offsetNode, c.offset); } }
      if (!r || r.startContainer.nodeType !== 3) return null;
      const t = r.startContainer.nodeValue; let a = r.startOffset, z = a;
      while (a > 0 && WORD.test(t[a - 1])) a--; while (z < t.length && WORD.test(t[z])) z++;
      const w = this.clean(t.slice(a, z)); if (!w) return null;
      const par = r.startContainer.parentElement, blk = (par && par.closest('p,li,blockquote,div,h1,h2,h3')) || par;
      return { word: w, ctx: this.sentence((blk && blk.textContent) || t, w) };
    }
    const host = el && el.closest('.bkpdf[data-p], .pg[data-i]');     // PDF page: find the word in the page's text
    if (!host || !RD.pdf) return null;
    const p = +(host.dataset.p || host.dataset.i), rc = host.getBoundingClientRect();
    return this.pdfWord(p, (x - rc.left) / rc.width, (y - rc.top) / rc.height);
  },
  async pdfWord(p, nx, ny) {
    let c = this.pc.get(p);
    if (!c) {
      const page = await RD.pdf.getPage(p), vp = page.getViewport({ scale: 1 }), tc = await page.getTextContent();
      c = { vp, items: tc.items.filter(i => i.str && i.str.trim()) }; page.cleanup(); this.pc.set(p, c); if (this.pc.size > 12) this.pc.delete(this.pc.keys().next().value);
    }
    const px = nx * c.vp.width, py = ny * c.vp.height, g = (this._cv || (this._cv = document.createElement('canvas'))).getContext('2d');
    for (const it of c.items) {
      const m = pdfjsLib.Util.transform(c.vp.transform, it.transform), fh = Math.hypot(m[2], m[3]) || 10, w = it.width * c.vp.scale;
      if (px < m[4] - 2 || px > m[4] + w + 2 || py < m[5] - fh * 0.95 || py > m[5] + fh * 0.3) continue;
      g.font = fh + 'px serif'; const tot = g.measureText(it.str).width || 1, k = w / tot;
      let i = 0; while (i < it.str.length - 1 && m[4] + g.measureText(it.str.slice(0, i + 1)).width * k < px) i++;
      let a = i, z = i + 1; while (a > 0 && WORD.test(it.str[a - 1])) a--; while (z < it.str.length && WORD.test(it.str[z])) z++;
      const word = this.clean(it.str.slice(a, z)); if (!word) return null;
      return { word, ctx: this.sentence(c.items.map(x => x.str).join(' ').replace(/\s+/g, ' '), word) };
    }
    return null;
  },
  sentence(text, w) {
    text = (text || '').replace(/\s+/g, ' '); const i = text.toLowerCase().indexOf(w.toLowerCase()); if (i < 0) return text.slice(0, 160);
    let a = Math.max(text.lastIndexOf('. ', i), text.lastIndexOf('? ', i), text.lastIndexOf('! ', i)); a = a < 0 ? Math.max(0, i - 80) : a + 2;
    let z = text.slice(i).search(/[.!?]\s|$/); z = i + (z < 0 ? 0 : z) + 1; z = Math.min(z, a + 220);
    return text.slice(a, z).trim();
  },

  /* ----- the meaning sheet ----- */
  show(word, ctx) {
    word = this.clean(word); if (!word) return;
    const q = encodeURIComponent(word), saved = this.words.some(x => x.w.toLowerCase() === word.toLowerCase());
    this._cur = { word, ctx };
    Sheet.open(`<div class="dword"><b>${esc(word)}</b></div>
      ${ctx ? `<p class="dctx serif">“${esc(shortStr(ctx, 230))}”</p>` : ''}
      <div class="dgrid">
        <button class="btn pri" data-act="dict-go" data-u="https://www.google.com/search?q=define+${q}">${ic('define', 16)} Meaning</button>
        <button class="btn" data-act="dict-go" data-u="https://en.wiktionary.org/wiki/${q}">Wiktionary</button>
        <button class="btn" data-act="dict-go" data-u="https://translate.google.com/?sl=auto&tl=en&text=${q}&op=translate">Translate</button>
        <button class="btn" data-act="dict-save">${ic('star', 16)} ${saved ? 'Saved' : 'Save word'}</button>
      </div><p class="xs mute" style="margin:12px 2px 0">The meaning opens in your browser. NerdyReader itself stays offline.</p>`, { title: 'Look up' });
  },
};
ACT['dict-go'] = el => Dict.ext(el.dataset.u);
ACT['dict-save'] = el => {
  const c = Dict._cur; if (!c) return;
  const i = Dict.words.findIndex(x => x.w.toLowerCase() === c.word.toLowerCase());
  if (i >= 0) { Dict.words.splice(i, 1); el.innerHTML = ic('star', 16) + ' Save word'; toast('Removed from your words'); }
  else { Dict.words.unshift({ w: c.word, ctx: shortStr(c.ctx || '', 200), b: RD ? RD.b.id : '', t: RD ? RD.b.title : '', ts: Date.now() }); el.innerHTML = ic('star', 16) + ' Saved'; toast('Word saved'); }
  Dict.save();
};
ACT['dict-sel'] = () => {
  const sel = window.getSelection(), t = sel ? sel.toString().trim() : ''; if (!t) return;
  const w = t.split(/\s+/)[0], n = sel.anchorNode, blk = n && (n.nodeType === 1 ? n : n.parentElement).closest('p,li,blockquote,div');
  $('#selbar').hidden = true; Dict.show(w, Dict.sentence((blk && blk.textContent) || t, Dict.clean(w)));
};
ACT['w-look'] = el => { const w = Dict.words[+el.dataset.i]; if (w) Dict.show(w.w, w.ctx); };
ACT['w-del'] = el => { Dict.words.splice(+el.dataset.i, 1); Dict.save(); const sc = $('#main').scrollTop; render(); $('#main').scrollTop = sc; };
function vocabCard() {
  if (!Dict.words.length) return `<section class="card"><h3>Saved words</h3><p class="sm mute" style="margin:0">Long-press any word while reading, then tap <b>Save word</b>. They collect here.</p></section>`;
  return `<section class="card"><h3>Saved words <small class="mute">${Dict.words.length}</small></h3>${Dict.words.slice(0, 40).map((w, i) => `<div class="dyrow"><div style="flex:1;min-width:0"><b>${esc(w.w)}</b><small>${esc(shortStr(w.ctx || w.t || '', 90))}</small></div><button class="ib soft" data-act="w-look" data-i="${i}" aria-label="Look up">${ic('define', 17)}</button><button class="ib soft" data-act="w-del" data-i="${i}" aria-label="Delete">${ic('trash', 17)}</button></div>`).join('')}</section>`;
}
/* long-press a word */
(() => {
  let t = null, d = null;
  const stop = () => { clearTimeout(t); t = null; d = null; };
  document.addEventListener('pointerdown', e => {
    if (!RD || ST.dict !== 'press' || !e.isPrimary || Ann.active() || e.target.closest('button,a,input,#drawbar,#selbar')) return;
    if (!e.target.closest('#rbook, #rpdf')) return;                   // in the scroll view of text books, the phone's own selection is used
    d = { x: e.clientX, y: e.clientY };
    t = setTimeout(async () => { const p = d; stop(); if (!p) return; const h = await Dict.at(p.x, p.y); if (h) { if (navigator.vibrate) navigator.vibrate(12); Dict.show(h.word, h.ctx); } }, 480);
  }, true);
  document.addEventListener('pointermove', e => { if (d && Math.hypot(e.clientX - d.x, e.clientY - d.y) > 9) stop(); }, true);
  ['pointerup', 'pointercancel'].forEach(ev => document.addEventListener(ev, stop, true));
})();
