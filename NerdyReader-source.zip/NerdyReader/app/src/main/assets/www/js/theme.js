'use strict';
/* ===== NerdyReader · themes and reading styles =====
   The full colour sets live in css/extra.css as  :root[data-theme=…]  and  [data-paper=…].
   This file only knows names, a few preview colours, and applies the choices.
   All themes are light and gentle on purpose: no black screens. */

const THEMES = {
  sunrise:  { name: 'Sunrise',  bg: '#fff7f0', p1: '#f0642f', p2: '#d6336c', paper: 'cream' },
  meadow:   { name: 'Meadow',   bg: '#f3fbf5', p1: '#2f9e6f', p2: '#1c7c54', paper: 'mint' },
  ocean:    { name: 'Ocean',    bg: '#f1f8fd', p1: '#2b8fd6', p2: '#0b7285', paper: 'sky' },
  lavender: { name: 'Lavender', bg: '#f7f3fe', p1: '#845ef7', p2: '#9c36b5', paper: 'lilac' },
  blossom:  { name: 'Blossom',  bg: '#fff3f7', p1: '#f06595', p2: '#be4bdb', paper: 'rose' },
  sunny:    { name: 'Sunny',    bg: '#fffbea', p1: '#ffd43b', p2: '#ffa94d', paper: 'butter' },
  midnight: { name: 'Midnight', bg: '#14121f', p1: '#6d5bf0', p2: '#3b2f9e', paper: 'night',  dark: true },
  black:    { name: 'Black',    bg: '#000000', p1: '#4a3fbf', p2: '#1a1445', paper: 'black',  dark: true },
};
const PAPER_COL = { cream: '#fff9f1', paper: '#ffffff', sepia: '#f4ecd8', mint: '#eaf7ee', sky: '#eaf4fc', rose: '#fdeef3', lilac: '#f1ecfc', butter: '#fff8d6', night: '#1c1a24', black: '#000000' };
const PAPER_DARK = { night: true, black: true };
const PAPER_LIST = [['auto', 'Match app'], ['paper', 'Paper'], ['sepia', 'Sepia'], ['mint', 'Mint'], ['sky', 'Sky'], ['rose', 'Rose'], ['lilac', 'Lilac'], ['night', 'Night'], ['black', 'Black']];
const FONTS = {
  serif: "'Source Serif 4', Georgia, serif",
  sans: "'DM Sans', system-ui, sans-serif",
  classic: "Georgia, 'Times New Roman', 'Noto Serif', serif",
  mono: "ui-monospace, 'Roboto Mono', Menlo, monospace",
};
const MARGINS = { snug: '14px', normal: '26px', roomy: '46px' };
const LH = { compact: 1.45, normal: 1.7, relaxed: 2.0 };

const themeNow = () => THEMES[ST.app] || THEMES.sunrise;
const paperNow = () => (PAPER_COL[ST.theme] ? ST.theme : themeNow().paper);

/* colour of the Android status / navigation bar while the library is showing */
function appBars() { AB && AB.setBars(themeNow().bg, !themeNow().dark); }

function applyTheme() {
  const k = THEMES[ST.app] ? ST.app : 'sunrise';
  document.documentElement.dataset.theme = k;
  document.documentElement.dataset.heads = ST.heads === 'serif' ? 'serif' : 'sans';
  try { document.querySelector('meta[name=theme-color]').content = THEMES[k].bg; } catch (e) { }
  if (!(typeof RD !== 'undefined' && RD)) appBars();
}

/* push the reading choices (font, size, spacing, margins, page colour) onto any element */
function readerVars(el) {
  el.dataset.paper = paperNow();
  el.style.setProperty('--fs', ST.size + 'px');
  el.style.setProperty('--ff', FONTS[ST.font] || FONTS.sans);
  el.style.setProperty('--lh', LH[ST.lh] || 1.7);
  el.style.setProperty('--mg', MARGINS[ST.mg] || '26px');
  el.style.setProperty('--ta', ST.ta === 'justify' ? 'justify' : 'left');
}

/* ---------- the "Themes & sound" screen ---------- */
const segBtns = (key, opts, act = 'st-set') =>
  `<div class="seg3">${opts.map(([v, t]) => `<button class="${ST[key] === v ? 'on' : ''}" data-act="${act}" data-k="${key}" data-v="${v}">${t}</button>`).join('')}</div>`;

function paperSwatches(act = 'st-set') {
  return `<div class="papers">${PAPER_LIST.map(([k, t]) => {
    const col = k === 'auto' ? PAPER_COL[themeNow().paper] : PAPER_COL[k];
    return `<button class="psw ${ST.theme === k ? 'on' : ''}" data-act="${act}" data-k="theme" data-v="${k}" style="--pc:${col}"><i></i><span>${t}</span></button>`;
  }).join('')}</div>`;
}

function vStyle() {
  const sw = Object.entries(THEMES).map(([k, t]) => `<button class="tsw ${ST.app === k ? 'on' : ''}" data-act="app-theme" data-v="${k}" style="--a:${t.p1};--b:${t.p2};--c:${t.bg};--tx:${t.dark ? '#f1eefc' : '#2a2230'}">
      <span class="tprev"><i></i><u></u></span><b>${t.name}</b><em>${ic('check', 14)}</em></button>`).join('');
  return `<h1 class="pgt">Themes &amp; sound</h1><p class="sub">Calm and bright, or dark and cosy. Your choice.</p>
  <section class="card"><h3>Colour theme</h3><div class="tgrid">${sw}</div>
    <div class="lbl">HEADINGS</div>${segBtns('heads', [['sans', 'Friendly'], ['serif', 'Storybook']], 'st-heads')}</section>
  <section class="card"><h3>Music</h3><p class="sm mute" style="margin:0 0 4px">Soft music that is made on your phone, so it works offline and never repeats the same way twice.</p><div class="mpanel">${Music.panelHTML()}</div></section>
  <section class="card"><h3>Reading style</h3>
    <div id="stprev" class="rprev"><h4>A page from your book</h4><p>The quick brown fox jumps over the lazy dog. Reading a little every day makes a quiet, happy habit that stays with you for years.</p></div>
    <div class="lbl">READING VIEW</div>${segBtns('view', [['scroll', 'Scroll'], ['book', 'Book']])}
    <div class="lbl">PAGES SHOWN IN BOOK VIEW</div>${segBtns('spread', [['auto', 'Auto'], ['2', 'Two pages'], ['1', 'One page']])}
    <div class="lbl">PAGE COLOUR</div>${paperSwatches()}
    <div class="lbl" id="szl2">TEXT SIZE · ${ST.size} PX</div>
    <div class="slr"><button class="btn sq" data-act="st-size" data-d="-1">A-</button><input type="range" id="st-size" min="14" max="36" value="${ST.size}"><button class="btn sq" data-act="st-size" data-d="1">A+</button></div>
    <div class="lbl">FONT</div>${segBtns('font', [['serif', 'Serif'], ['sans', 'Sans'], ['classic', 'Classic'], ['mono', 'Mono']])}
    <div class="lbl">LINE SPACING</div>${segBtns('lh', [['compact', 'Compact'], ['normal', 'Normal'], ['relaxed', 'Relaxed']])}
    <div class="lbl">MARGINS</div>${segBtns('mg', [['snug', 'Snug'], ['normal', 'Normal'], ['roomy', 'Roomy']])}
    <div class="lbl">ALIGNMENT</div>${segBtns('ta', [['left', 'Left'], ['justify', 'Justified']])}</section>
  <section class="card"><h3>Welcome animation</h3><p class="sm mute" style="margin:0 0 10px">A short calm intro each time you open the app.</p>
    <div class="row gap"><button class="btn ${ST.splash ? 'on' : ''}" data-act="splash-toggle" id="splbtn">${ST.splash ? 'On' : 'Off'}</button><button class="btn" data-act="splash-replay">${ic('play', 16)} Watch it now</button></div></section>`;
}
function styleMount() { const p = $('#stprev'); if (p) readerVars(p); }

function refreshStyleUI(k) {
  $$('[data-act=st-set]').filter(x => x.dataset.k === k).forEach(x => x.classList.toggle('on', x.dataset.v === ST[k]));
  $$('.psw[data-v=auto]').forEach(x => x.style.setProperty('--pc', PAPER_COL[themeNow().paper]));
  styleMount();
}

ACT['app-theme'] = el => {
  ST.app = el.dataset.v; saveST(); applyTheme();
  const m = $('#main'), y = m.scrollTop; render(); m.scrollTop = y;
};
ACT['st-heads'] = el => { ST.heads = el.dataset.v; saveST(); applyTheme(); refreshStyleUI('heads'); };
ACT['st-set'] = el => { ST[el.dataset.k] = el.dataset.v; saveST(); applyReaderStyle(); refreshStyleUI(el.dataset.k); };
ACT['st-size'] = el => {
  ST.size = clamp(ST.size + +el.dataset.d, 14, 36); saveST(); applyReaderStyle(); styleMount();
  const r = $('#st-size'); if (r) r.value = ST.size; const l = $('#szl2'); if (l) l.textContent = 'TEXT SIZE · ' + ST.size + ' PX';
};
ACT['splash-toggle'] = el => { ST.splash = !ST.splash; saveST(); el.textContent = ST.splash ? 'On' : 'Off'; el.classList.toggle('on', ST.splash); toast(ST.splash ? 'Welcome animation on' : 'Welcome animation off'); };
ACT['splash-replay'] = () => Splash.run(true);

document.addEventListener('input', e => {
  if (e.target.id === 'st-size') {
    ST.size = +e.target.value; saveST(); applyReaderStyle(); styleMount();
    const l = $('#szl2'); if (l) l.textContent = 'TEXT SIZE · ' + ST.size + ' PX';
  }
});
