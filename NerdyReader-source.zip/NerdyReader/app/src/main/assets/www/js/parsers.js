'use strict';
/* ===== NerdyReader · document parsers =====
   Every parser returns the same shape so the reader does not care about the format:
   { meta:{title,author,desc,cover(Blob|null)}, chapters:[{title, words, html?}], load(i)->Promise<{html,title?}>, revoke() }  */

const WPM = 230;
const countWords = t => (t.trim().match(/\S+/g) || []).length;
const stripTags = h => h.replace(/<[^>]*>/g, ' ').replace(/&nbsp;/g, ' ').replace(/&amp;/g, '&').replace(/\s+/g, ' ').trim();

async function decodeText(buf) {
  const u = new Uint8Array(buf);
  let s;
  if (u[0] === 0xFF && u[1] === 0xFE) s = new TextDecoder('utf-16le').decode(u.subarray(2));
  else if (u[0] === 0xFE && u[1] === 0xFF) s = new TextDecoder('utf-16be').decode(u.subarray(2));
  else {
    try { s = new TextDecoder('utf-8', { fatal: true }).decode(u); }
    catch (e) { s = new TextDecoder('windows-1252').decode(u); }
  }
  return s.replace(/^\uFEFF/, '');
}

const MIME = { jpg: 'image/jpeg', jpeg: 'image/jpeg', png: 'image/png', gif: 'image/gif', webp: 'image/webp', svg: 'image/svg+xml', bmp: 'image/bmp' };
const mimeOf = p => MIME[(p.split('.').pop() || '').toLowerCase()] || 'application/octet-stream';
function resolvePath(from, rel) {
  try { return decodeURIComponent(new URL(rel, 'http://x/' + from).pathname.slice(1)); }
  catch (e) { return rel; }
}

/* ---- make safe, theme-able HTML out of arbitrary markup ---- */
function sanitize(root) {
  root.querySelectorAll('script,style,link,meta,iframe,object,embed,form,input,button,select,textarea,noscript,video,audio,canvas,base,title').forEach(n => n.remove());
  root.querySelectorAll('*').forEach(n => {
    for (const a of [...n.attributes]) {
      const k = a.name.toLowerCase();
      if (k.startsWith('on') || ['style', 'class', 'color', 'bgcolor', 'face', 'size', 'width', 'height', 'align', 'valign', 'border', 'cellpadding', 'cellspacing'].includes(k)) n.removeAttribute(a.name);
      else if (k === 'href' && /^\s*javascript:/i.test(a.value)) n.removeAttribute(a.name);
    }
  });
  root.querySelectorAll('[id]').forEach(e => { e.id = 'x-' + e.id; });
  root.querySelectorAll('a[name]').forEach(a => { if (!a.id) a.id = 'x-' + a.getAttribute('name'); });
}

/* ---- split a flat list of blocks into chapters ---- */
function buildChapters(blocks, bookTitle) {
  const total = blocks.reduce((a, b) => a + b.len, 0);
  const heads = blocks.filter(b => b.h && b.h <= 2).length;
  const chapters = [];
  if (heads >= 3 && heads <= 500) {
    let cur = null;
    for (const b of blocks) {
      if (b.h && b.h <= 2) { cur = { title: b.text || 'Section', parts: [b.html], len: b.len }; chapters.push(cur); }
      else {
        if (!cur) { cur = { title: bookTitle || 'Start', parts: [], len: 0 }; chapters.push(cur); }
        cur.parts.push(b.html); cur.len += b.len;
      }
    }
  } else if (total <= 26000) {
    chapters.push({ title: bookTitle || 'Text', parts: blocks.map(b => b.html), len: total });
  } else {
    let cur = null;
    for (const b of blocks) {
      if (!cur || cur.len > 16000) { cur = { title: 'Part ' + (chapters.length + 1), parts: [], len: 0 }; chapters.push(cur); }
      cur.parts.push(b.html); cur.len += b.len;
    }
  }
  return chapters.filter(c => c.parts.length).map(c => ({ title: c.title, html: c.parts.join('\n'), words: Math.max(1, Math.round(c.len / 5.8)) }));
}
function memParser(chapters, meta) {
  return { meta, chapters, load: async i => ({ html: chapters[i].html }), revoke() { } };
}

/* ---- plain text ---- */
const CH_RE = /^(chapter|part|book|section|canto|act|scene|prologue|epilogue|preface|introduction|foreword)\b[\s.:\-–—]*([0-9]+|[ivxlcdm]+|one|two|three|four|five|six|seven|eight|nine|ten|eleven|twelve|thirteen|fourteen|fifteen|sixteen|seventeen|eighteen|nineteen|twenty)?\b.*$/i;
function parseTxt(str, rec) {
  str = str.replace(/\r\n?/g, '\n');
  const paras = str.split(/\n[ \t]*\n+/).map(p => p.replace(/^\n+|\n+$/g, '')).filter(p => p.trim());
  const lens = str.split('\n').filter(l => l.trim()).map(l => l.length).sort((a, b) => a - b);
  const unwrap = (lens[lens.length >> 1] || 0) >= 40;
  const blocks = paras.map(p => {
    const one = p.trim();
    if (!one.includes('\n') && one.length < 90 && CH_RE.test(one)) return { h: 1, text: one, html: `<h2>${esc(one)}</h2>`, len: one.length };
    const body = unwrap ? esc(p.replace(/\s*\n\s*/g, ' ')) : esc(p).replace(/\n/g, '<br>');
    return { h: 0, html: `<p>${body}</p>`, len: p.length };
  });
  const title = rec.title || 'Text';
  return memParser(buildChapters(blocks, title), { title: '', author: '', desc: '', cover: null });
}

/* ---- markdown (small, forgiving) ---- */
function inlineMd(s) {
  s = esc(s);
  return s.replace(/!\[([^\]]*)\]\([^)]*\)/g, '$1')
    .replace(/`([^`]+)`/g, '<code>$1</code>')
    .replace(/\*\*([^*]+)\*\*/g, '<b>$1</b>')
    .replace(/(^|[^*\w])\*([^*\n]+)\*/g, '$1<i>$2</i>')
    .replace(/(^|[^\w])_([^_\n]+)_/g, '$1<i>$2</i>')
    .replace(/\[([^\]]+)\]\((https?:[^)\s]+)\)/g, '<a href="$2" target="_blank">$1</a>');
}
function parseMd(src, rec) {
  const lines = src.replace(/\r\n?/g, '\n').split('\n');
  const blocks = []; let para = [], list = null, quote = [], code = null, mdTitle = '';
  const flushP = () => { if (para.length) { const t = para.join(' '); blocks.push({ h: 0, html: `<p>${inlineMd(t)}</p>`, len: t.length }); para = []; } };
  const flushL = () => { if (list) { blocks.push({ h: 0, html: `<${list.t}>${list.items.map(i => `<li>${inlineMd(i)}</li>`).join('')}</${list.t}>`, len: list.items.join(' ').length }); list = null; } };
  const flushQ = () => { if (quote.length) { const t = quote.join(' '); blocks.push({ h: 0, html: `<blockquote>${inlineMd(t)}</blockquote>`, len: t.length }); quote = []; } };
  const flushAll = () => { flushP(); flushL(); flushQ(); };
  for (const raw of lines) {
    if (code) {
      if (/^\s*```/.test(raw)) { blocks.push({ h: 0, html: `<pre><code>${esc(code.join('\n'))}</code></pre>`, len: code.join('\n').length }); code = null; }
      else code.push(raw);
      continue;
    }
    if (/^\s*```/.test(raw)) { flushAll(); code = []; continue; }
    let m;
    if ((m = raw.match(/^(#{1,6})\s+(.*?)\s*#*\s*$/))) {
      flushAll();
      const lv = m[1].length;
      if (lv === 1 && !mdTitle) mdTitle = m[2];
      blocks.push({ h: lv, text: m[2], html: `<h${Math.min(lv + 1, 6)}>${inlineMd(m[2])}</h${Math.min(lv + 1, 6)}>`, len: m[2].length });
    } else if (/^\s*([-*_])(\s*\1){2,}\s*$/.test(raw)) { flushAll(); blocks.push({ h: 0, html: '<hr>', len: 1 }); }
    else if ((m = raw.match(/^\s*([-*+]|\d+[.)])\s+(.*)$/))) {
      flushP(); flushQ();
      const t = /\d/.test(m[1]) ? 'ol' : 'ul';
      if (!list || list.t !== t) { flushL(); list = { t, items: [] }; }
      list.items.push(m[2]);
    } else if ((m = raw.match(/^\s*>\s?(.*)$/))) { flushP(); flushL(); quote.push(m[1]); }
    else if (!raw.trim()) flushAll();
    else { flushL(); flushQ(); para.push(raw.trim()); }
  }
  if (code) blocks.push({ h: 0, html: `<pre><code>${esc(code.join('\n'))}</code></pre>`, len: code.join('\n').length });
  flushAll();
  // use h1 as the split level when the file uses "# Chapter" style, else h2
  const h1 = blocks.filter(b => b.h === 1).length;
  if (h1 >= 2) blocks.forEach(b => { if (b.h === 1) b.h = 1; });
  return memParser(buildChapters(blocks, mdTitle || rec.title), { title: mdTitle, author: '', desc: '', cover: null });
}

/* ---- html files ---- */
function parseHtml(src, rec) {
  const doc = new DOMParser().parseFromString(src, 'text/html');
  const title = (doc.querySelector('title')?.textContent || '').trim();
  let body = doc.body;
  sanitize(body);
  body.querySelectorAll('img').forEach(i => { if (!/^data:/i.test(i.getAttribute('src') || '')) i.remove(); });
  for (let k = 0; k < 3 && body.children.length === 1 && /^(div|article|main|section)$/i.test(body.children[0].tagName); k++) body = body.children[0];
  const blocks = [];
  body.childNodes.forEach(n => {
    if (n.nodeType === 3) { const t = n.textContent.trim(); if (t) blocks.push({ h: 0, html: `<p>${esc(t)}</p>`, len: t.length }); return; }
    if (n.nodeType !== 1) return;
    const m = n.tagName.match(/^H([1-6])$/i);
    const txt = n.textContent.trim();
    if (!txt && !n.querySelector('img')) return;
    blocks.push({ h: m ? +m[1] : 0, text: txt, html: n.outerHTML, len: txt.length || 50 });
  });
  const h1 = doc.querySelector('h1')?.textContent.trim();
  return memParser(buildChapters(blocks, title || h1 || rec.title), { title: title || h1 || '', author: doc.querySelector('meta[name=author]')?.content || '', desc: '', cover: null });
}

/* ---- Word (.docx): headings, paragraphs, bold/italic, lists, simple tables ---- */
async function parseDocx(blob) {
  const zip = await JSZip.loadAsync(blob);
  const f = zip.file('word/document.xml');
  if (!f) throw new Error('This .docx has no readable text');
  const W = 'http://schemas.openxmlformats.org/wordprocessingml/2006/main';
  const xml = new DOMParser().parseFromString(await f.async('string'), 'application/xml');
  const bodyEl = xml.getElementsByTagNameNS(W, 'body')[0];
  const kids = (el, n) => [...el.children].filter(c => c.localName === n);
  const firstKid = (el, n) => kids(el, n)[0];
  const runHtml = p => {
    let out = '';
    const runs = p.getElementsByTagNameNS(W, 'r');
    for (const r of runs) {
      const pr = firstKid(r, 'rPr');
      const bold = pr && firstKid(pr, 'b') && firstKid(pr, 'b').getAttributeNS(W, 'val') !== '0';
      const ital = pr && firstKid(pr, 'i') && firstKid(pr, 'i').getAttributeNS(W, 'val') !== '0';
      let t = '';
      for (const c of r.children) {
        if (c.localName === 't') t += esc(c.textContent);
        else if (c.localName === 'tab') t += '&emsp;';
        else if (c.localName === 'br') t += '<br>';
      }
      if (!t) continue;
      if (bold) t = `<b>${t}</b>`;
      if (ital) t = `<i>${t}</i>`;
      out += t;
    }
    return out;
  };
  const blocks = [];
  const para = p => {
    const html = runHtml(p);
    const text = stripTags(html);
    if (!text) return;
    const ppr = firstKid(p, 'pPr');
    const style = ppr && firstKid(ppr, 'pStyle')?.getAttributeNS(W, 'val') || '';
    const hm = style.match(/^(?:Heading|heading)\s?([1-6])$/) || (/^Title$/i.test(style) ? [0, 1] : null);
    if (hm) { const lv = +hm[1]; blocks.push({ h: lv, text, html: `<h${Math.min(lv + 1, 6)}>${html}</h${Math.min(lv + 1, 6)}>`, len: text.length }); return; }
    const isList = ppr && firstKid(ppr, 'numPr');
    blocks.push({ h: 0, html: isList ? `<p>• ${html}</p>` : `<p>${html}</p>`, len: text.length });
  };
  for (const el of bodyEl.children) {
    if (el.localName === 'p') para(el);
    else if (el.localName === 'tbl') {
      let rows = '';
      for (const tr of kids(el, 'tr')) rows += '<tr>' + kids(tr, 'tc').map(tc => '<td>' + kids(tc, 'p').map(runHtml).join('<br>') + '</td>').join('') + '</tr>';
      blocks.push({ h: 0, html: `<table>${rows}</table>`, len: stripTags(rows).length });
    }
  }
  let title = '', author = '';
  const core = zip.file('docProps/core.xml');
  if (core) {
    const cx = new DOMParser().parseFromString(await core.async('string'), 'application/xml');
    title = cx.getElementsByTagNameNS('*', 'title')[0]?.textContent.trim() || '';
    author = cx.getElementsByTagNameNS('*', 'creator')[0]?.textContent.trim() || '';
  }
  return memParser(buildChapters(blocks, title), { title, author, desc: '', cover: null });
}

/* ---- EPUB ---- */
async function parseEpub(blob) {
  const zip = await JSZip.loadAsync(blob);
  const rd = async p => { const f = zip.file(p); if (!f) throw new Error('Missing file in EPUB: ' + p); return f.async('string'); };
  const xml = s => new DOMParser().parseFromString(s, 'application/xml');
  const G = (d, n) => [...d.getElementsByTagNameNS('*', n)];
  const container = xml(await rd('META-INF/container.xml'));
  const rootPath = G(container, 'rootfile')[0].getAttribute('full-path');
  const opf = xml(await rd(rootPath));
  const man = {};
  G(opf, 'item').forEach(i => { man[i.getAttribute('id')] = { href: i.getAttribute('href'), type: i.getAttribute('media-type') || '', props: i.getAttribute('properties') || '' }; });
  const spineItems = G(opf, 'itemref').map(r => man[r.getAttribute('idref')]).filter(Boolean)
    .map(m => ({ path: resolvePath(rootPath, m.href), type: m.type }))
    .filter(m => /html|xml/i.test(m.type) && zip.file(m.path));
  if (!spineItems.length) throw new Error('This EPUB has no readable chapters');
  const idxOf = {}; spineItems.forEach((m, i) => { idxOf[m.path] = i; });

  // titles from the table of contents (EPUB3 nav or EPUB2 ncx)
  const titles = {};
  const navItem = Object.values(man).find(m => /\bnav\b/.test(m.props));
  const ncxItem = Object.values(man).find(m => /ncx/i.test(m.type));
  try {
    if (navItem) {
      const np = resolvePath(rootPath, navItem.href);
      const nd = new DOMParser().parseFromString(await rd(np), 'text/html');
      const nav = [...nd.querySelectorAll('nav')].find(n => (n.getAttribute('epub:type') || '').includes('toc')) || nd.querySelector('nav');
      nav && nav.querySelectorAll('a[href]').forEach(a => {
        const p = resolvePath(np, a.getAttribute('href').split('#')[0]);
        if (!(p in titles)) titles[p] = a.textContent.replace(/\s+/g, ' ').trim();
      });
    }
    if (!Object.keys(titles).length && ncxItem) {
      const cp = resolvePath(rootPath, ncxItem.href);
      const nx = xml(await rd(cp));
      G(nx, 'navPoint').forEach(np => {
        const lab = G(np, 'text')[0]?.textContent.trim();
        const src = G(np, 'content')[0]?.getAttribute('src');
        if (lab && src) { const p = resolvePath(cp, src.split('#')[0]); if (!(p in titles)) titles[p] = lab.replace(/\s+/g, ' '); }
      });
    }
  } catch (e) { console.warn('toc', e); }

  const chapters = spineItems.map((m, i) => {
    const size = zip.file(m.path)?._data?.uncompressedSize || 3000;
    return { title: titles[m.path] || '', path: m.path, words: Math.max(1, Math.round(size * 0.09)) };
  });
  chapters.forEach((c, i) => { if (!c.title) c.title = 'Section ' + (i + 1); });

  const meta = {
    title: G(opf, 'title')[0]?.textContent.trim() || '',
    author: G(opf, 'creator').map(c => c.textContent.trim()).filter(Boolean).join(', '),
    desc: stripTags(G(opf, 'description')[0]?.textContent || ''),
    cover: null,
  };
  try {
    const mc = G(opf, 'meta').find(m => m.getAttribute('name') === 'cover');
    const cid = Object.keys(man).find(id => /cover-image/.test(man[id].props)) || mc?.getAttribute('content');
    if (cid && man[cid]) {
      const cp = resolvePath(rootPath, man[cid].href), cf = zip.file(cp);
      if (cf) meta.cover = new Blob([await cf.async('uint8array')], { type: man[cid].type || mimeOf(cp) });
    }
  } catch (e) { }

  const urls = [];
  const P = {
    meta, chapters,
    revoke() { urls.splice(0).forEach(u => URL.revokeObjectURL(u)); },
    async load(i) {
      P.revoke();
      const ch = chapters[i];
      const doc = new DOMParser().parseFromString(await rd(ch.path), 'text/html');
      const body = doc.body;
      body.querySelectorAll('svg').forEach(s => {
        const im = s.querySelector('image');
        if (im) { const n = doc.createElement('img'); n.setAttribute('src', im.getAttribute('xlink:href') || im.getAttribute('href') || ''); s.replaceWith(n); } else s.remove();
      });
      sanitize(body);
      for (const img of body.querySelectorAll('img')) {
        const src = img.getAttribute('src') || '';
        if (/^data:/i.test(src)) continue;
        const p = resolvePath(ch.path, src.split('#')[0].split('?')[0]);
        const f = zip.file(p);
        if (f) {
          const url = URL.createObjectURL(new Blob([await f.async('uint8array')], { type: mimeOf(p) }));
          urls.push(url); img.setAttribute('src', url);
        } else img.remove();
        img.removeAttribute('srcset');
      }
      body.querySelectorAll('a[href]').forEach(a => {
        const h = a.getAttribute('href');
        if (/^(https?:|mailto:)/i.test(h)) { a.setAttribute('target', '_blank'); return; }
        const [f, frag] = h.split('#');
        const p = f ? resolvePath(ch.path, f) : ch.path;
        if (p in idxOf) { a.setAttribute('data-ch', idxOf[p]); if (frag) a.setAttribute('data-frag', frag); a.setAttribute('href', '#'); }
        else a.removeAttribute('href');
      });
      const hd = body.querySelector('h1,h2,h3');
      const found = hd ? hd.textContent.replace(/\s+/g, ' ').trim() : '';
      if (found && /^Section \d+$/.test(ch.title) && found.length < 80) ch.title = found;
      return { html: body.innerHTML };
    },
  };
  return P;
}

/* ---- PDF: text mode (reflowed from the page text) ---- */
function pdfTextParser(pdf, rec, perGroup = 8) {
  const n = pdf.numPages, chapters = [];
  for (let s = 1; s <= n; s += perGroup) {
    const e = Math.min(n, s + perGroup - 1);
    chapters.push({ title: s === e ? `Page ${s}` : `Pages ${s}–${e}`, from: s, to: e, words: (e - s + 1) * 320 });
  }
  const pageHtml = async num => {
    const page = await pdf.getPage(num);
    const tc = await page.getTextContent();
    const lines = []; let cur = null;
    for (const it of tc.items) {
      if (!it.str && !it.hasEOL) continue;
      const y = it.transform[5], h = it.height || Math.abs(it.transform[3]) || 10;
      if (!cur || Math.abs(cur.y - y) > h * 0.5) { cur = { y, h, t: '' }; lines.push(cur); }
      cur.t += it.str;
      if (it.hasEOL) cur = null;
    }
    page.cleanup();
    const L = lines.filter(l => l.t.trim());
    if (!L.length) return '';
    const gaps = []; for (let i = 1; i < L.length; i++) { const d = L[i - 1].y - L[i].y; if (d > 0) gaps.push(d); }
    gaps.sort((a, b) => a - b);
    const med = gaps[gaps.length >> 1] || 12;
    const paras = []; let p = L[0].t.trim();
    for (let i = 1; i < L.length; i++) {
      const gap = L[i - 1].y - L[i].y, t = L[i].t.trim();
      if (gap > med * 1.6 || gap < 0 && Math.abs(gap) > med * 3) { paras.push(p); p = t; }
      else if (/[A-Za-z]-$/.test(p) && /^[a-z]/.test(t)) p = p.slice(0, -1) + t;
      else p += ' ' + t;
    }
    paras.push(p);
    return paras.map(x => `<p>${esc(x.replace(/\s+/g, ' '))}</p>`).join('');
  };
  return {
    meta: {}, chapters, revoke() { },
    async load(i) {
      const c = chapters[i]; let html = '';
      for (let p = c.from; p <= c.to; p++) html += `<div class="pgm">Page ${p}</div>` + await pageHtml(p);
      if (stripTags(html).replace(/Page \d+/g, '').trim().length < 20) html += '<p class="mute">No selectable text on these pages. This looks like a scanned PDF, so use “View the original PDF pages”.</p>';
      c.words = Math.max(1, countWords(stripTags(html)));
      return { html };
    },
  };
}
