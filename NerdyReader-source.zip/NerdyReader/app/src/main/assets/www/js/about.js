'use strict';
/* ===== NerdyReader · About =====
   EDIT HERE. Same content and layout as the About page in NeuroOrbitSynapse.
   Photo: put raghu.jpg (or .png/.webp) next to index.html in assets/www/.
   My books: put the PDFs in assets/www/books/ using the file names below. */
const AB_PHOTO = ['raghu.jpg', 'raghu.png', 'raghu.jpeg', 'raghu.webp'];
const AB_SKILLS = ['Front-end development', 'Scrum', 'Kanban', 'Jira', 'Azure tools', 'Systems thinking', 'Building trading tools (QuantReloaded)', 'Video editing: After Effects, Blender', 'Testing ideas before using them'];
const AB_FE = ['HTML5', 'CSS3 (custom properties, grid, flexbox)', 'JavaScript (ES6+, no framework)', 'pdf.js for PDF pages', 'JSZip for EPUB and DOCX', 'IndexedDB for the private offline library', 'Android WebView shell (one small Java file)', 'GitHub Actions to build the APK'];
const AB_BOOKS = [
  ['The False Green', 'Trading psychology: why a green screen can lie to you, and what it does to decisions.', 'the-false-green.pdf'],
  ['Who\u2019s Trading Your Account? The Second Trader', 'The other trader inside you, the one who takes over when emotion kicks in.', 'who-is-trading-your-account.pdf'],
  ['The Eight Power and Trading Paradoxes', 'The contradictions every trader has to live with.', 'eight-power-and-trading-paradoxes.pdf'],
  ['The Inner Citadel Trade', 'Building the inside of a trader so the outside can follow.', 'inner-citadel-trade.pdf'],
  ['The Blind Candle', 'Reading price and your own mind when the picture is incomplete.', 'the-blind-candle.pdf'],
];
const AB_STORY = [
  ['2018', 'First steps in the markets', 'I started trading in 2018. In those early days I lost money, mostly because I did not yet understand how markets actually behave.'],
  ['2020 to 2023', 'Away from the screen, closer to the truth', 'I stepped back and worked freelance and regular jobs: video editing, After Effects, Blender. I also took an entry-level role at Fyers, answering calls from traders. Listening to so many of them taught me how markets really behave, and how human psychology shows up in trading: gaps in knowledge, technical problems, and the same emotional mistakes again and again. Later I left Fyers.'],
  ['A hard stretch', 'Habits that became hurdles', 'This was also a heavy period personally. I went through depression and difficult life events, and fell into drinking and smoking. In time I saw that these habits distracted me from the goals I wanted and had become hurdles. I decided to quit, but I kept failing to control the urges. That is what sent me into books on neuroscience, and on trading, because I needed to make money and I never wanted to work under a boss.'],
  ['2023 to 2024', 'Trading again, more lessons', 'I returned to trading while editing videos for creators on Instagram and YouTube. I made small amounts of money, explored trading again, and took more losses along the way.'],
  ['The turning point', 'Quitting alcohol, and asking why', 'One day, full of hatred for the habit and the mental hangover that came with it, I quit alcohol. Then I focused on the real question: why could I not quit before? I took working on myself seriously. I studied characters from Breaking Bad, The Mentalist, The Big Bang Theory, Batman and Money Heist, tried to borrow their habits, read more on habits, neuroscience and trading, learned to think in systems, and built my own tools, including the QuantReloaded dashboard.'],
  ['Today', 'Sober, and still building', 'I have been completely sober for almost a year now. Smoking still triggers me sometimes, and I know I will quit that too. NerdyReader is where I read about all of it: the books on habits, the mind and the markets that got me here.'],
];
const AB_WHY = [
  ['book', 'Reads what you own', 'PDFs, EPUBs, text and Word files from your phone, in one calm place. No store, no sign-up, no catalogue to scroll.'],
  ['wifi', 'Offline by design', 'Every book is copied into the app. There is no internet permission at all, so nothing can leak out and nothing needs a signal.'],
  ['target', 'Remembers your place', 'Chapter, page and scroll position are saved as you read, so Resume always lands where you stopped.'],
  ['heart', 'Easy on the eyes', 'Light, Sepia and Night themes, serif or sans, and text size and spacing you control. Built for long sessions.'],
];
const AB_PRIV = [
  'Your books, bookmarks and progress stay on this phone, inside the app.',
  'There is no account, no sign-up and no server behind it.',
  'The app has no internet permission, so it cannot send anything anywhere.',
  'Uninstalling or clearing the app’s storage removes the library, so keep your original files.',
];

function abImg(el) {
  const i = +el.dataset.i + 1;
  if (i < AB_PHOTO.length) { el.dataset.i = i; el.src = AB_PHOTO[i]; } else el.style.display = 'none';
}
function abCard(i, t, p) {
  return `<div class="card gstep"><div class="row"><span class="gico">${ic(i, 16)}</span><b>${esc(t)}</b></div><p class="sm mute" style="margin:8px 0 0">${esc(p)}</p></div>`;
}
const abSec = (title, inner, open = false) => `<details class="gsec" ${open ? 'open' : ''}><summary><b>${esc(title)}</b>${ic('down', 18)}</summary><div class="abin">${inner}</div></details>`;

function vAbout() {
  return `<h1 class="pgt">About</h1><p class="sub">The person behind NerdyReader, and why it exists.</p>
  <section class="abhero card">
    <div class="abph"><span class="abav">R</span><img src="${AB_PHOTO[0]}" data-i="0" alt="Raghu" onerror="abImg(this)" onload="this.classList.add('ok')"></div>
    <div><div class="serif abname">Raghu</div>
    <div class="mute sm">Trader, author and builder. I never follow random advice: I test it, from every angle, before it touches my trading.</div>
    <div class="row wrap gap" style="margin-top:12px"><a class="btn pri" href="https://www.instagram.com/nerdyintruder/" target="_blank" rel="noopener">${ic('heart', 14)} @NerdyIntruder</a><button class="btn" data-act="abcopy">${ic('copy', 14)} Copy handle</button></div></div>
  </section>
  ${abSec('Who I am', `<p class="sm">I am an active retail trader. I trade equity and F&amp;O, mostly intraday, on NSE and BSE. I also trade crypto (BTC and ETH) and Nasdaq perpetual contracts on Delta Exchange. Trading is the centre of my work and my thinking, and the hardest part of it has never been the chart. It is the person looking at the chart.</p><p class="sm">I do not copy what I am told. Every idea, indicator and tool gets tested first: what works for me, what does not, and why. I look at it from my own point of view and from several others, and I only deploy it in my trading after it has survived the test. That is also how I built this app.</p><p class="sm">I write about trading psychology, discipline and performance as @NerdyIntruder. NerdyReader is where I keep the books that shaped that work.</p>`, true)}
  ${abSec('Skills', `<div class="row wrap gap6">${AB_SKILLS.map(x => `<span class="chip on">${esc(x)}</span>`).join('')}</div><p class="sm mute" style="margin-top:10px">I have the skills for a software career and I did try to get there. Personal problems kept holding me back and the jobs never came. That was never for lack of trying. Meanwhile I went fully into trading, and I have not looked back.</p>`)}
  ${abSec('Front-end skills', `<p class="sm mute">I build the whole front end myself. This reader is plain HTML, CSS and JavaScript inside a tiny Android shell.</p><div class="row wrap gap6" style="margin-top:8px">${AB_FE.map(x => `<span class="chip on">${esc(x)}</span>`).join('')}</div><p class="sm mute" style="margin-top:10px">No frameworks, no tracking, no server. Your data stays on your device.</p>`)}
  ${abSec('My story', `<div class="abtl">${AB_STORY.map(x => `<div class="abstep"><span class="abdot"></span><div class="xs mute">${esc(x[0])}</div><b>${esc(x[1])}</b><p class="sm" style="margin:4px 0 0">${esc(x[2])}</p></div>`).join('')}</div>`)}
  ${abSec('My books', `<p class="xs mute" style="margin:0 0 8px">If you are interested, have a look at my work. Tap <b>Add to library</b> to read a title here.</p><div class="grid2">${AB_BOOKS.map((b, i) => `<div class="card gstep"><div class="row"><span class="gico">${ic('book', 16)}</span><b>${esc(b[0])}</b></div><p class="sm mute" style="margin:8px 0">${esc(b[1])}</p><button class="btn sm" data-act="ab-book" data-i="${i}">${ic('plus', 13)} Add to library</button></div>`).join('')}</div><div class="card gstep" style="margin-top:12px"><div class="row"><span class="gico">${ic('edit', 16)}</span><b>In progress</b></div><p class="sm mute" style="margin:8px 0 0">A book on the full-time trader’s life beyond the chart, and a shorter one on distraction and noise. Both are written from the inside.</p></div>`)}
  ${abSec('Why NerdyReader', `<div class="grid2">${AB_WHY.map(b => abCard(b[0], b[1], b[2])).join('')}</div>`)}
  ${abSec('How it is built', `<p class="sm">A small Android app that shows a local web app. PDFs are drawn with pdf.js, EPUB and Word files are unpacked with JSZip, and your library lives in the app’s own database. No framework, no tracking, no ads, no network.</p><p class="sm mute">Version 1.0 · built with ♥ for personal use.</p>`)}
  ${abSec('Your data and privacy', `<div class="col gap6">${AB_PRIV.map(x => `<div class="sm row top gap6"><span class="accol">${ic('check', 14)}</span><span>${esc(x)}</span></div>`).join('')}</div><div class="card inset" style="margin-top:12px"><div class="kv"><span>Books in library</span><b>${S.books.size}</b></div><div class="kv"><span>Storage used</span><b id="usage">…</b></div><button class="btn danger" data-act="wipe" style="margin-top:10px">${ic('trash', 15)} Clear library and settings</button></div>`)}
  <div class="card tc"><div class="serif" style="font-size:20px">Read deep. Think clear.</div><div class="mute sm" style="margin-top:6px">Made with <span class="heart">&#10084;</span> by Raghu · <a href="https://www.instagram.com/nerdyintruder/" target="_blank" rel="noopener">@NerdyIntruder</a></div></div>`;
}

async function abMount() {
  const u = $('#usage');
  if (!u) return;
  try { const e = await navigator.storage.estimate(); u.textContent = sizeStr(e.usage || 0); } catch (err) { u.textContent = '—'; }
}

async function abAddBook(i) {
  const b = AB_BOOKS[i];
  try {
    const r = await fetch('books/' + b[2]);
    if (!r.ok) throw new Error('missing');
    const blob = await r.blob();
    const f = new File([blob], b[2], { type: 'application/pdf' });
    const res = await importMany([f]);
    if (res[0]) go('book', { id: res[0].id });
  } catch (e) {
    toast('Put “' + b[2] + '” in app/src/main/assets/www/books/ and rebuild, or add it with Add books.', 5200);
  }
}
