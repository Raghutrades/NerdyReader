'use strict';
/* ===== NerdyReader · read aloud =====
   Android app : uses the phone's own text-to-speech engine through NerdyBridge (offline if a voice is installed)
   Browser/iOS : falls back to window.speechSynthesis
   Reflow books read paragraph by paragraph (highlighted), moving to the next chapter on its own.
   PDF page view reads the text of each page and scrolls along.                                   */
const RATES = [0.8, 1, 1.25, 1.5, 1.75, 2];
const TT = { on: false, paused: false, gen: 0, k: 0, cmd: null, rate: +localStorage.getItem('nr-rate') || 1, pend: null, uid: 0, wake: null };

const ttsAvailable = () => !!(AB && AB.ttsSpeak) || 'speechSynthesis' in window;

/* engine callbacks from Android */
function ttsNative(ev, id) {
  if (ev === 'unavailable') { toast('No text-to-speech engine found on this phone'); ttsStop(); return; }
  if (TT.pend && String(TT.pend.id) === String(id)) { const r = TT.pend.res; TT.pend = null; r(ev); }
}
function ttsEngineStop() {
  try { AB && AB.ttsStop ? AB.ttsStop() : window.speechSynthesis && speechSynthesis.cancel(); } catch (e) { }
  if (TT.pend) { const r = TT.pend.res; TT.pend = null; r('cancel'); }
}
/* speak one chunk, resolve when finished / cancelled */
function ttsSay(text) {
  return new Promise(res => {
    const id = ++TT.uid;
    TT.pend = { id, res };
    if (AB && AB.ttsSpeak) AB.ttsSpeak(text, TT.rate, String(id));
    else {
      const u = new SpeechSynthesisUtterance(text);
      u.rate = TT.rate;
      u.onend = () => ttsNative('done', id);
      u.onerror = () => ttsNative('error', id);
      speechSynthesis.cancel(); speechSynthesis.speak(u);
    }
  });
}
function chunkText(t, max = 3200) {
  t = t.replace(/\s+/g, ' ').trim();
  if (t.length <= max) return t ? [t] : [];
  const out = []; let cur = '';
  for (const s of t.split(/(?<=[.!?…])\s+/)) {
    if ((cur + ' ' + s).length > max && cur) { out.push(cur); cur = s; } else cur = cur ? cur + ' ' + s : s;
    while (cur.length > max) { out.push(cur.slice(0, max)); cur = cur.slice(max); }
  }
  if (cur) out.push(cur);
  return out;
}
/* speak a paragraph; returns 'done' | 'cancel' | 'error' */
async function ttsParagraph(text, gen) {
  for (const c of chunkText(text)) {
    if (!TT.on || gen !== TT.gen) return 'cancel';
    const r = await ttsSay(c);
    if (r !== 'done') return r;
  }
  return 'done';
}

/* ---------- UI ---------- */
function ttsBar() {
  const bar = $('#tts');
  bar.hidden = !TT.on;
  if (!TT.on) { $('#rlisten').classList.remove('on'); return; }
  $('#rlisten').classList.add('on');
  const [a, b, c, d, e] = $$('button', bar);
  a.innerHTML = ic('skipp', 22); c.innerHTML = ic('skipn', 22); e.innerHTML = ic('x', 22);
  b.innerHTML = TT.paused ? icFill('play', 26) : icFill('pause', 26);
  d.textContent = TT.rate + 'x';
}
function ttsMark(el) {
  $$('#rart .tts-now').forEach(x => x.classList.remove('tts-now'));
  if (!el) return;
  el.classList.add('tts-now');
  const sc = $('#rtext'), r = el.getBoundingClientRect(), v = sc.getBoundingClientRect();
  if (r.top < v.top + 80 || r.bottom > v.bottom - 170) sc.scrollTo({ top: sc.scrollTop + r.top - v.top - 110, behavior: 'smooth' });
}

/* ---------- controls ---------- */
function ttsToggle() {
  if (!RD) return;
  if (TT.on) { ttsStop(); return; }
  if (!ttsAvailable()) { toast('Text-to-speech is not available here'); return; }
  ttsStart();
}
function ttsPlayPause() {
  if (!TT.on) return;
  TT.paused = !TT.paused;
  if (TT.paused) { TT.cmd = 'pause'; ttsEngineStop(); }
  else { TT.cmd = null; const w = TT.wake; TT.wake = null; w && w(); }
  ttsBar();
}
function ttsSkip(d) {
  if (!TT.on) return;
  TT.cmd = d > 0 ? 'next' : 'prev';
  if (TT.paused) { TT.paused = false; const w = TT.wake; TT.wake = null; w && w(); ttsBar(); }
  ttsEngineStop();
}
function ttsCycleRate() {
  const i = RATES.indexOf(TT.rate);
  TT.rate = RATES[(i + 1) % RATES.length];
  localStorage.setItem('nr-rate', TT.rate);
  ttsBar();
  if (TT.on && !TT.paused) { TT.cmd = 'again'; ttsEngineStop(); }
}
function ttsStop(quiet) {
  const was = TT.on;
  TT.on = false; TT.paused = false; TT.gen++; TT.cmd = null;
  ttsEngineStop();
  const w = TT.wake; TT.wake = null; w && w();
  if (document.getElementById('rart')) ttsMark(null);
  ttsBar();
  if (was && !quiet) toast('Stopped listening');
}

async function ttsStart() {
  TT.on = true; TT.paused = false; TT.cmd = null;
  const gen = ++TT.gen;
  ttsBar();
  toast('Listening · tap the bar to pause or skip', 2200);
  try { RD.kind === 'reflow' ? await ttsReflow(gen) : await ttsPages(gen); }
  catch (e) { console.warn('tts', e); }
  if (gen === TT.gen && TT.on) { TT.on = false; ttsMark(null); ttsBar(); }
}

/* handle pause / skip commands after each utterance. returns the index delta, or null to stop */
async function ttsAfter(gen, result) {
  if (!TT.on || gen !== TT.gen) return null;
  if (result === 'error') { toast('Text-to-speech failed. Check your phone’s speech settings.', 4000); ttsStop(true); return null; }
  let cmd = TT.cmd; TT.cmd = null;
  if (cmd === 'pause' || TT.paused) {
    await new Promise(r => { TT.wake = r; });
    if (!TT.on || gen !== TT.gen) return null;
    cmd = TT.cmd; TT.cmd = null;
    return cmd === 'next' ? 1 : cmd === 'prev' ? -1 : 0;
  }
  if (cmd === 'again') return 0;
  if (cmd === 'next') return 1;
  if (cmd === 'prev') return -1;
  return result === 'done' ? 1 : 0;
}

function firstVisibleIndex(els) {
  const sc = $('#rtext'), top = sc.getBoundingClientRect().top + 90;
  const i = els.findIndex(e => e.getBoundingClientRect().bottom > top);
  return i < 0 ? 0 : i;
}
const TT_SEL = '#rart > p, #rart > h1, #rart > h2, #rart > h3, #rart > h4, #rart > ul > li, #rart > ol > li, #rart > blockquote, #rart > div:not(.rend):not(.pgm), #rart > table, #rart > section > p';
const ttsEls = () => $$(TT_SEL).filter(e => (e.innerText || '').trim().length > 1);

async function ttsReflow(gen) {
  let first = true;
  while (TT.on && gen === TT.gen && RD) {
    const els = ttsEls();
    let k = first ? firstVisibleIndex(els) : 0; first = false;
    while (k < els.length) {
      if (!TT.on || gen !== TT.gen || !RD) return;
      ttsMark(els[k]);
      const r = await ttsParagraph(els[k].innerText, gen);
      const d = await ttsAfter(gen, r);
      if (d === null) return;
      k = Math.max(0, k + d);
      if (k < 0) k = 0;
    }
    if (RD.ch >= RD.n - 1) { toast('Finished listening'); return; }
    await rdShowChapter(RD.ch + 1, 0);
  }
}

async function ttsPages(gen) {
  let page = RD.page, empty = 0;
  let paras = [], k = 0, loaded = -1;
  while (TT.on && gen === TT.gen && RD && page <= RD.np) {
    if (loaded !== page) {
      paras = await pdfPageParas(RD.pdf, page); loaded = page; k = 0;
      if (!paras.length) {
        if (++empty >= 3) { toast('No selectable text here. This looks like a scanned PDF.', 4500); return; }
        page++; continue;
      }
      empty = 0;
      if (RD.page !== page) pdfGoPage(page);
    }
    if (k >= paras.length) { page++; continue; }
    const r = await ttsParagraph(paras[k], gen);
    const d = await ttsAfter(gen, r);
    if (d === null) return;
    k += d;
    if (k < 0) { page = Math.max(1, page - 1); loaded = -1; if (page === 1 && d < 0) k = 0; }
  }
  if (RD && page > RD.np) toast('Finished listening');
}
