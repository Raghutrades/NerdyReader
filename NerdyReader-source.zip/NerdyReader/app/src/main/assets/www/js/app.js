'use strict';
/* ===== NerdyReader · events and boot ===== */
function openDrawer() { renderDrawer(); $('#drawer').classList.add('on'); $('#scrim').classList.add('on'); }
function closeDrawer() { const was = $('#drawer').classList.contains('on'); $('#drawer').classList.remove('on'); $('#scrim').classList.remove('on'); return was; }

function navTo(v) {
  closeDrawer();
  navStack.length = 0;
  S.view = v; S.params = {};
  render();
  $('#main').scrollTop = 0;
}

function editSheet(b) {
  Sheet.open(`<label class="lbl">TITLE</label><input id="et" class="inp" value="${esc(b.title)}"><label class="lbl">AUTHOR</label><input id="ea" class="inp" value="${esc(b.author)}" placeholder="Unknown author"><button class="btn pri big wide" data-act="edit-save" data-id="${b.id}" style="margin-top:16px">Save changes</button>`, { title: 'Edit details' });
}

async function openAt(id, markId) {
  const b = S.books.get(id), m = (b?.bookmarks || []).find(x => x.id === markId);
  if (!b) return;
  openReader(id, m ? (m.page ? { page: m.page, r: m.r } : { ch: m.ch, r: m.r }) : null);
}

/* files shared to the app / "Open with" (Android hands them over through the bridge) */
async function nrIncoming() {
  if (!AB) return;
  let list = [];
  try { list = JSON.parse(AB.takePending() || '[]'); } catch (e) { }
  if (!list.length) return;
  const files = [];
  for (const it of list) {
    try {
      const r = await fetch(location.origin + '/shared/' + it.id);
      const blob = await r.blob();
      files.push(new File([blob], it.name || 'book', { type: it.mime || '' }));
    } catch (e) { toast('Could not read ' + (it.name || 'the file')); }
  }
  const done = await importMany(files);
  if (done.length === 1) openReader(done[0].id);
}
window.nrIncoming = nrIncoming;

window.nrBack = () => {
  if (Sheet.isOpen()) { Sheet.close(); return true; }
  if (closeDrawer()) return true;
  if (RD && Book.on && Book.ovOpen()) { Book.closeGrid(); return true; }
  if (RD) { closeReader(); return true; }
  if (navStack.length) { goBack(); return true; }
  if (S.view !== 'home') { navTo('home'); return true; }
  return false;
};
window.nrPause = () => { if (RD) rdFlush(); Music.suspend(); };
window.nrResume = () => { Music.resume(); };

/* ---------- click delegation ---------- */
document.addEventListener('click', async e => {
  const el = e.target.closest('[data-act]');
  if (!el) return;
  const a = el.dataset.act, v = el.dataset.v, id = el.dataset.id;
  if (el.tagName === 'A' && !el.getAttribute('href')) e.preventDefault();
  switch (a) {
    case 'menu': openDrawer(); break;
    case 'menu-close': closeDrawer(); break;
    case 'nav': navTo(v); break;
    case 'add': closeDrawer(); pickFiles(); break;
    case 'lib-tab': S.lib.tab = v; S.lib.fmt = 'all'; closeDrawer(); if (S.view === 'library') render(); else go('library'); break;
    case 'lib-fmt': S.lib.fmt = v; if (S.view === 'library') render(); else { S.lib.tab = 'all'; go('library'); } break;
    case 'shelf-tab': S.shelf.tab = v; render(); break;
    case 'open-book': go('book', { id }); break;
    case 'read': openReader(id); break;
    case 'read-at': openAt(id, el.dataset.bm); break;
    case 'save': { const b = S.books.get(id); b.saved = !b.saved; saveBook(b, true); render(); toast(b.saved ? 'Saved to My shelf' : 'Removed from Saved'); break; }
    case 'edit': editSheet(S.books.get(id)); break;
    case 'edit-save': {
      const b = S.books.get(id), t = $('#et').value.trim();
      if (t) b.title = t; b.author = $('#ea').value.trim();
      saveBook(b, true); Sheet.close(); render(); break;
    }
    case 'remove': {
      const b = S.books.get(id);
      if (await confirmBox(`Remove “${shortStr(b.title, 40)}” from NerdyReader? Your original file is not touched.`, 'Remove', true)) {
        await DB.delBook(id); S.books.delete(id); toast('Removed'); if (!goBack()) navTo('library');
      }
      break;
    }
    case 'help': { const h = HELP[v]; closeDrawer(); Sheet.open(h[1], { title: h[0] }); break; }
    case 'abcopy': try { await navigator.clipboard.writeText('@NerdyIntruder'); } catch (err) { } toast('Handle copied'); break;
    case 'ab-book': abAddBook(+el.dataset.i); break;
    case 'wipe':
      if (await confirmBox('This deletes every book, bookmark and setting inside NerdyReader. Your original files are not touched.', 'Delete everything', true)) {
        await DB.clearAll(); localStorage.clear(); S.books.clear(); toast('Library cleared'); setTimeout(() => location.reload(), 500);
      }
      break;
    case 'sheet-close': Sheet.close(); break;
    /* reader */
    case 'r-back': closeReader(); break;
    case 'r-toc': if (Book.on && el.closest('.rmid')) Book.overview(); else openToc(); break;
    case 'r-aa': openAa(); break;
    case 'r-bm': toggleMark(); break;
    case 'r-prev': rdStep(-1); break;
    case 'r-next': rdStep(1); break;
    case 'set': {
      ST[el.dataset.k] = v; saveST(); applyReaderStyle();
      $$('[data-act=set]', $('#sheet')).filter(x => x.dataset.k === el.dataset.k).forEach(x => x.classList.toggle('on', x === el));
      break;
    }
    case 'size': { ST.size = clamp(ST.size + +el.dataset.d, 14, 36); saveST(); applyReaderStyle(); $('#szr').value = ST.size; $('#szl').textContent = 'TEXT SIZE · ' + ST.size + ' PX'; break; }
    case 'zoom': { const z = Math.round((RD.zoom + +el.dataset.d) * 100) / 100; pdfSetZoom(z); $('#zmr').value = Math.round(RD.zoom * 100); $('#zml').textContent = 'ZOOM · ' + Math.round(RD.zoom * 100) + '%'; break; }
    case 'zoom-fit': pdfSetZoom(1); $('#zmr').value = 100; $('#zml').textContent = 'ZOOM · 100%'; break;
    case 'pdf-mode': switchPdfMode(); break;
    case 'toc-tab':
      $$('[data-act=toc-tab]').forEach(x => x.classList.toggle('on', x === el));
      $('#tocbody').hidden = v !== 'toc'; $('#marksbody').hidden = v !== 'marks'; break;
    case 'go-ch': Sheet.close(); rdShowChapter(+el.dataset.i, 0); break;
    case 'go-page': { const n = parseInt($('#gopage').value, 10); if (n >= 1 && n <= RD.np) { Sheet.close(); pdfGoPage(n); } else toast('Enter a page from 1 to ' + RD.np); break; }
    case 'go-out': {
      const n = RD.outline[+el.dataset.i]; Sheet.close();
      try {
        let dest = n.dest; if (typeof dest === 'string') dest = await RD.pdf.getDestination(dest);
        const ref = dest && dest[0]; const pg = typeof ref === 'object' ? (await RD.pdf.getPageIndex(ref)) + 1 : (ref | 0) + 1;
        pdfGoPage(pg);
      } catch (err) { toast('Could not jump there'); }
      break;
    }
    case 'go-mark': {
      const m = RD.b.bookmarks.find(x => x.id === id); Sheet.close();
      if (m.page && RD.kind === 'pages') pdfScrollTo(m.page, m.r); else if (m.ch != null && RD.kind === 'reflow') rdShowChapter(m.ch, m.r);
      break;
    }
    case 'tool-go': Tools.preset(v); break;
    case 'tool-book': Tools.presetBook(v, id); break;
    case 'del-mark': { RD.b.bookmarks = RD.b.bookmarks.filter(x => x.id !== id); saveBook(RD.b, true); el.closest('.tocrow').remove(); $('#rbm').classList.toggle('on', !!rdFindMark()); break; }
    default: if (ACT[a]) await ACT[a](el, e);
  }
});

document.addEventListener('change', e => {
  if (e.target.id === 'sortsel') { S.lib.sort = e.target.value; render(); }
});
document.addEventListener('input', e => {
  if (e.target.id === 'q') { S.q = e.target.value; $('#sres').innerHTML = searchResults(S.q); }
});
document.addEventListener('submit', e => {
  if (e.target.dataset.act === 'home-search') { e.preventDefault(); S.q = $('#hq').value; go('search'); }
});
$('#picker').addEventListener('change', e => { importMany(e.target.files); });
window.addEventListener('unhandledrejection', e => { console.warn(e.reason); });
document.addEventListener('visibilitychange', () => { if (document.hidden && RD) rdFlush(); });

/* ---------- boot ---------- */
(async function boot() {
  applyTheme();
  $('[data-act=menu]').innerHTML = ic('menu', 24);
  $('.logo').innerHTML = `<span class="lg">${ic('book', 22)}</span><span>Nerdy<b>Reader</b></span>`;
  $('.pillbtn').innerHTML = ic('plus', 18) + '<span>Add</span>';
  $('#musicbtn').innerHTML = '<span class="eq"><i></i><i></i><i></i><i></i></span>';
  $('[data-act=r-back]').innerHTML = ic('left', 22);
  $('[data-act=r-toc]').innerHTML = ic('list', 22);
  $('[data-act=r-prev]').innerHTML = ic('left', 22);
  $('[data-act=r-next]').innerHTML = ic('right', 22);
  try {
    await DB.open();
    await loadLibrary();
  } catch (e) { toast('Storage is not available: ' + e.message, 8000); }
  bindReaderEvents();
  render();
  try { navigator.storage && navigator.storage.persist && navigator.storage.persist(); } catch (e) { }
  nrIncoming();
  Music.boot();
  Splash.run();
})();
