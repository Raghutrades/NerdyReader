'use strict';
/* ===== NerdyReader · the page curl =====
   A real fold, not a card flip. One corner of the page follows your finger (point P, starting at the
   corner C). The crease is the perpendicular bisector of C→P:
     - the part of the page on the spine side of the crease stays flat           (front)
     - the part beyond it is mirrored across the crease and shown face-down        (flap, the page's back)
     - the page underneath is revealed beyond the crease, with a soft shadow       (under)
   Everything is plain geometry (half-plane clipping + one affine matrix), so it is cheap enough to run
   every frame in a WebView. Coordinates are in px, origin = top-left of the page that is turning. */
const Curl = {
  clip(poly, M, n, pos) {                         // keep the half-plane (x-M)·n >= 0  (pos)  or  <= 0
    const out = [], sg = pos ? 1 : -1, f = p => ((p[0] - M[0]) * n[0] + (p[1] - M[1]) * n[1]) * sg;
    for (let i = 0; i < poly.length; i++) {
      const a = poly[i], b = poly[(i + 1) % poly.length], fa = f(a), fb = f(b);
      if (fa >= 0) out.push(a);
      if ((fa >= 0) !== (fb >= 0)) { const t = fa / (fa - fb); out.push([a[0] + (b[0] - a[0]) * t, a[1] + (b[1] - a[1]) * t]); }
    }
    return out;
  },
  css(poly) {
    if (poly.length < 3) return 'polygon(0px 0px,0px 0px,0px 0px)';
    return 'polygon(' + poly.map(p => p[0].toFixed(1) + 'px ' + p[1].toFixed(1) + 'px').join(',') + ')';
  },
  /* where the corner is while a turn plays by itself: it swings over the top of the page like a hand would */
  arcPoint(p, W, H, cy) {
    const lift = Math.min(W, H) * 0.34, s = Math.sin(Math.PI * p);
    return [W * Math.cos(Math.PI * p), cy + (cy > H / 2 ? -1 : 1) * lift * s];
  },
  pOf(P, W) { return Math.acos(clamp(P[0] / W, -1, 1)) / Math.PI; },
  /* the paper cannot stretch: keep P within reach of the spine, so the crease never cuts the binding */
  limit(P, W, H, cy) {
    let x = P[0], y = P[1];
    const c = (sx, sy, R) => { const dx = x - sx, dy = y - sy, d = Math.hypot(dx, dy); if (d > R) { x = sx + dx * R / d; y = sy + dy * R / d; } };
    for (let i = 0; i < 2; i++) { c(0, cy, W); c(0, H - cy, Math.hypot(W, H - 2 * cy)); }
    return [x, y];
  },

  build(bk, L) {
    const cu = mk('bkcurl');
    cu.style.cssText = `left:${L.two ? L.pw : 0}px;width:${L.pw}px;height:${L.ph}px;display:none`;
    const under = mk('cu-under'), gU = mk('cu-gu'), front = mk('cu-front'), flapW = mk('cu-flapw'), flapC = mk('cu-flapc'), flap = mk('cu-flap'), gF = mk('cu-gf');
    flap.style.width = L.pw + 'px'; flap.style.height = L.ph + 'px';
    under.appendChild(gU); flapC.append(flap, gF); flapW.appendChild(flapC);
    cu.append(under, front, flapW); bk.appendChild(cu);
    return { cu, under, gU, front, flapW, flapC, flap, gF };
  },
  mount(e) {                                      // the two faces of the turning leaf live inside the curl layers
    const k = e.curl;
    if (e.ff.parentNode !== k.front) k.front.appendChild(e.ff);
    if (e.fb.parentNode !== k.flap) k.flap.appendChild(e.fb);
  },
  flat(e) {
    const k = e.curl; k.front.style.clipPath = 'none'; k.under.style.display = 'none'; k.flapW.style.display = 'none';
  },
  hide(e) { const k = e.curl; if (k) { k.cu.style.display = 'none'; this.flat(e); } },

  /* P: where the corner is now.  C: where it started.  fade: 0..1 opacity of the flap (single-page mode fades it out) */
  set(e, L, P, C, fade = 1, fx = true) {
    const W = L.pw, H = L.ph, k = e.curl;
    const dx = P[0] - C[0], dy = P[1] - C[1], len = Math.hypot(dx, dy);
    if (len < 1.5) return this.flat(e);
    const n = [dx / len, dy / len], M = [(P[0] + C[0]) / 2, (P[1] + C[1]) / 2];
    const rect = [[0, 0], [W, 0], [W, H], [0, H]];
    const pos = this.clip(rect, M, n, true), neg = this.clip(rect, M, n, false);
    const refl = neg.map(q => { const d = (q[0] - M[0]) * n[0] + (q[1] - M[1]) * n[1]; return [q[0] - 2 * d * n[0], q[1] - 2 * d * n[1]]; });
    k.front.style.clipPath = this.css(pos);
    k.under.style.display = 'block'; k.under.style.clipPath = this.css(neg);
    k.flapW.style.display = 'block'; k.flapW.style.opacity = fade.toFixed(3);
    k.flapC.style.clipPath = this.css(refl);
    // flap = the page's back, mirrored across the crease:  x' = A·(mirrorX(x)) + t
    const A00 = 1 - 2 * n[0] * n[0], A01 = -2 * n[0] * n[1], A11 = 1 - 2 * n[1] * n[1], md = 2 * (M[0] * n[0] + M[1] * n[1]);
    k.flap.style.transform = `matrix(${-A00},${-A01},${A01},${A11},${A00 * W + md * n[0]},${A01 * W + md * n[1]})`;
    // shading follows the crease
    const th = Math.atan2(n[1], n[0]) * 180 / Math.PI, G = Math.max(W, H) * 3, str = clamp(len / (W * 0.4), 0.2, 1);
    k.gU.style.cssText = `width:110px;height:${G}px;transform:translate(${M[0]}px,${M[1]}px) rotate(${th}deg) translate(-110px,${-G / 2}px);opacity:${str.toFixed(2)}`;
    k.gF.style.cssText = `width:130px;height:${G}px;transform:translate(${M[0]}px,${M[1]}px) rotate(${th}deg) translate(0,${-G / 2}px);opacity:${str.toFixed(2)}`;
    k.flapW.style.filter = fx ? 'drop-shadow(-3px 4px 6px rgba(0,0,0,.34))' : 'none';
  },
};
