package com.nerdyintruder.nerdyreader;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.ActivityNotFoundException;
import android.content.ClipData;
import android.content.Intent;
import android.database.Cursor;
import android.graphics.Color;
import android.net.Uri;
import android.os.Bundle;
import android.provider.OpenableColumns;
import android.view.View;
import android.view.WindowManager;
import android.webkit.JavascriptInterface;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;

import androidx.webkit.WebViewAssetLoader;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.InputStream;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

/**
 * NerdyReader shell. The whole reader (library, PDF / EPUB / text rendering, About page)
 * is a local web app in assets/www, served from a virtual https origin so it never needs
 * the network. This class only does what a web page cannot:
 *   - show the system file picker,
 *   - receive files from "Open with" / "Share",
 *   - tint the system bars and keep the screen awake while reading.
 */
public class MainActivity extends Activity {

    private static final int REQ_PICK = 4411;
    private static final String HOST = "appassets.androidplatform.net";

    private WebView web;
    private ValueCallback<Uri[]> pickCallback;
    private final Map<String, Uri> shared = new ConcurrentHashMap<>();
    private final List<JSONObject> pending = new ArrayList<>();

    @SuppressLint({"SetJavaScriptEnabled", "AddJavascriptInterface"})
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        web = new WebView(this);
        web.setBackgroundColor(Color.parseColor("#FDF6F3"));
        setContentView(web);

        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setAllowFileAccess(false);
        s.setAllowContentAccess(false);
        s.setSupportZoom(false);
        s.setBuiltInZoomControls(false);
        s.setMediaPlaybackRequiresUserGesture(true);
        s.setTextZoom(100); // the app does its own text sizing

        final WebViewAssetLoader loader = new WebViewAssetLoader.Builder()
                .setDomain(HOST)
                .addPathHandler("/assets/", new WebViewAssetLoader.AssetsPathHandler(this))
                .addPathHandler("/shared/", path -> {
                    Uri uri = shared.get(path);
                    if (uri == null) return null;
                    try {
                        InputStream in = getContentResolver().openInputStream(uri);
                        if (in == null) return null;
                        return new WebResourceResponse("application/octet-stream", null, in);
                    } catch (Exception e) {
                        return null;
                    }
                })
                .build();

        web.setWebViewClient(new WebViewClient() {
            @Override
            public WebResourceResponse shouldInterceptRequest(WebView view, WebResourceRequest request) {
                return loader.shouldInterceptRequest(request.getUrl());
            }

            @Override
            public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                Uri u = request.getUrl();
                if (HOST.equals(u.getHost())) return false;
                try {
                    startActivity(new Intent(Intent.ACTION_VIEW, u));
                } catch (ActivityNotFoundException ignored) {
                }
                return true;
            }
        });

        web.setWebChromeClient(new WebChromeClient() {
            @Override
            public boolean onShowFileChooser(WebView view, ValueCallback<Uri[]> cb,
                                             FileChooserParams params) {
                if (pickCallback != null) pickCallback.onReceiveValue(null);
                pickCallback = cb;
                Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT);
                i.addCategory(Intent.CATEGORY_OPENABLE);
                i.setType("*/*");
                i.putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true);
                i.putExtra(Intent.EXTRA_MIME_TYPES, new String[]{
                        "application/pdf",
                        "application/epub+zip",
                        "text/*",
                        "application/xhtml+xml",
                        "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
                        "application/octet-stream"
                });
                try {
                    startActivityForResult(i, REQ_PICK);
                } catch (Exception e) {
                    pickCallback = null;
                    cb.onReceiveValue(null);
                    return false;
                }
                return true;
            }
        });

        web.addJavascriptInterface(new Bridge(), "NerdyBridge");

        collect(getIntent());
        web.loadUrl("https://" + HOST + "/assets/www/index.html");
    }

    @Override
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        setIntent(intent);
        collect(intent);
        web.evaluateJavascript("window.nrIncoming&&window.nrIncoming()", null);
    }

    @Override
    protected void onActivityResult(int req, int res, Intent data) {
        super.onActivityResult(req, res, data);
        if (req != REQ_PICK || pickCallback == null) return;
        Uri[] out = null;
        if (res == RESULT_OK && data != null) {
            ClipData clip = data.getClipData();
            if (clip != null) {
                out = new Uri[clip.getItemCount()];
                for (int i = 0; i < out.length; i++) out[i] = clip.getItemAt(i).getUri();
            } else if (data.getData() != null) {
                out = new Uri[]{data.getData()};
            }
        }
        pickCallback.onReceiveValue(out);
        pickCallback = null;
    }

    @Override
    public void onBackPressed() {
        web.evaluateJavascript("(window.nrBack&&window.nrBack())?'1':'0'", v -> {
            if (!"\"1\"".equals(v)) finish();
        });
    }

    @Override
    protected void onPause() {
        super.onPause();
        web.evaluateJavascript("window.nrPause&&window.nrPause()", null);
    }

    /** Pull file URIs out of VIEW / SEND intents and queue them for the page. */
    private void collect(Intent intent) {
        if (intent == null) return;
        String action = intent.getAction();
        List<Uri> uris = new ArrayList<>();
        if (Intent.ACTION_VIEW.equals(action) && intent.getData() != null) {
            uris.add(intent.getData());
        } else if (Intent.ACTION_SEND.equals(action)) {
            Uri u = intent.getParcelableExtra(Intent.EXTRA_STREAM);
            if (u != null) uris.add(u);
        } else if (Intent.ACTION_SEND_MULTIPLE.equals(action)) {
            ArrayList<Uri> l = intent.getParcelableArrayListExtra(Intent.EXTRA_STREAM);
            if (l != null) uris.addAll(l);
        }
        for (Uri u : uris) {
            try {
                String id = UUID.randomUUID().toString().replace("-", "");
                shared.put(id, u);
                JSONObject o = new JSONObject();
                o.put("id", id);
                o.put("name", displayName(u));
                String t = getContentResolver().getType(u);
                o.put("mime", t == null ? "" : t);
                synchronized (pending) {
                    pending.add(o);
                }
            } catch (Exception ignored) {
            }
        }
        // Don't re-import the same file when the activity is recreated.
        if (!uris.isEmpty()) intent.setAction(Intent.ACTION_MAIN);
    }

    private String displayName(Uri u) {
        String name = null;
        if ("content".equals(u.getScheme())) {
            try (Cursor c = getContentResolver().query(u, null, null, null, null)) {
                if (c != null && c.moveToFirst()) {
                    int ix = c.getColumnIndex(OpenableColumns.DISPLAY_NAME);
                    if (ix >= 0) name = c.getString(ix);
                }
            } catch (Exception ignored) {
            }
        }
        if (name == null || name.isEmpty()) {
            String p = u.getLastPathSegment();
            name = p == null ? "book" : p.substring(p.lastIndexOf('/') + 1);
        }
        return name;
    }

    /** Methods the web app can call as window.NerdyBridge.xxx() */
    private class Bridge {
        @JavascriptInterface
        public String takePending() {
            synchronized (pending) {
                if (pending.isEmpty()) return "";
                JSONArray a = new JSONArray();
                for (JSONObject o : pending) a.put(o);
                pending.clear();
                return a.toString();
            }
        }

        @JavascriptInterface
        public void setBars(final String color, final boolean darkIcons) {
            runOnUiThread(() -> {
                try {
                    int c = Color.parseColor(color);
                    getWindow().setStatusBarColor(c);
                    getWindow().setNavigationBarColor(c);
                    int f = web.getSystemUiVisibility();
                    if (darkIcons) {
                        f |= View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR | View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR;
                    } else {
                        f &= ~(View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR | View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR);
                    }
                    web.setSystemUiVisibility(f);
                } catch (Exception ignored) {
                }
            });
        }

        @JavascriptInterface
        public void keepScreenOn(final boolean on) {
            runOnUiThread(() -> {
                if (on) getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
                else getWindow().clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
            });
        }

        @JavascriptInterface
        public void toast(final String msg) {
            runOnUiThread(() -> Toast.makeText(MainActivity.this, msg, Toast.LENGTH_SHORT).show());
        }

        @JavascriptInterface
        public void exit() {
            runOnUiThread(MainActivity.this::finish);
        }
    }
}
