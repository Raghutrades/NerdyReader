# NerdyReader

An offline reader for **PDF, EPUB, TXT, Markdown, HTML and Word (.docx)** files on Android, styled after the BDeBooks screens, with an About page like the one in NeuroOrbitSynapse. Personal use. No internet permission, no account, no tracking.

## Get the APK (phone only, no computer)
1. Create a GitHub repo, e.g. `NerdyReader`.
2. **Add file → Create new file**, name it `.github/workflows/build-apk.yml` (typing the slashes makes the folders) and paste the contents of that file from this project. Commit.
3. **Add file → Upload files** and upload `NerdyReader-source.zip` (the zip you downloaded, as-is). Commit.
4. Open the **Actions** tab. The *Build NerdyReader APK* run takes ~3–5 minutes.
5. Download from **Releases → NerdyReader (latest build) → NerdyReader.apk** (or the run's *Artifacts*). Open it on your phone and allow "install unknown apps" for your browser.

If you have a computer, just push the unzipped folder instead. The workflow handles both.

Every build is signed with the key in `keystore/`, so a new APK installs over the old one and **keeps your library**.

## Using it
- **Add books** (top right, or the menu) opens the system file picker. Files are copied into the app, so they open offline even if you delete the original.
- In any file manager: long-press a book → **Open with → NerdyReader** (or Share → NerdyReader).
- Reader: tap the page to hide the bars; **Aa** = size, font, spacing, margins, alignment and page colour; the headphones button reads aloud; middle of the bottom bar = contents and bookmarks.
- PDFs open as original pages (pinch to zoom). **Aa → Read as reflowable text** reflows them with your font. Scanned PDFs have no text, so use page view.

## New in 1.4: calmer interface, marking tools, full-screen reading, welcome film
- **Interface size**: the app screens now scale to your phone (Themes & sound → Comfort: Auto / Small / Medium / Large). Cleaner type, flatter cards, slimmer menus. The book itself is not scaled.
- **Mark up books**: tap the pen in the reader. PDF pages get a highlighter (a level swipe snaps straight), pen, underline, eraser, 7 colours, 3 sizes, undo and redo. Other books: select text and tap a colour to highlight; tap a highlight to remove it.
- **Look up a word**: long-press a word (or switch to tap in Aa / Comfort). The meaning opens in the browser, because the app has no internet permission. Save words to the vocabulary list in the Quotes tab.
- **Full-screen reading**: status and navigation bars are hidden while a book is open (swipe from an edge to peek). Reading time is only counted while a book is open and you are touching it.
- **Zoom** badge fades away by itself.
- **Welcome film**: night sky, aurora, fireflies, a glowing book that opens, a burst of sparkles, the title in a sweep of light, and a short launch melody made on the phone (switch off in Comfort).

## New in 1.3: habit tracking, quotes, real page curl
- **Reading stats** (new *Stats* tab): time, pages and sittings are logged automatically while you read. Month **calendar** (tap a day for the books and times), **streak** and best streak, daily goal ring, last 7 days, 6-month heatmap, *when you read* chart, all-time totals, most-read books, badges. Goals and a log export are on the same screen.
- **Quotes** (new *Quotes* tab and a card on Home): every book you add is scanned in the background and its best lines are kept. Home shows them one after another, a different book each time, with title, chapter and page, changing every 8 s to 1 min (or manually). Heart, copy, open at that page. Save your own: select text while reading (Scroll view) or **Aa → Save a quote from this page** (PDF).
- **Page curl**: the page lifts from the corner you touch and folds over, with the back of the sheet, a shadow and the page underneath. Drag it, tap the edges, or swipe. Styles: Curl, Flip, Fade, None; speed, shadows and sound are in **Aa**.
- **Zoom in Book view**, with one page or two: pinch, double-tap the middle, or use the slider. PDF pages are redrawn sharp. Drag to move around.
- Also: *first page alone / paired* for two-page view, dim and warm-light sliders, paper texture, tap-edge switch, 4 new themes (Sand, Forest, Ember, Aurora) and 3 page colours, grid/list library, star ratings, mark finished / start over, Surprise me.

## New in 1.2: Book view
Reads like a real book. Open any book and it shows as an open book with **two pages side by side** (one page on a narrow screen), and pages that **turn with a swish**:
- Turn by **tapping the left or right edge**, **swiping**, or **dragging the page** with your finger. Tap the middle to show or hide the bars.
- PDFs show their **original pages** as spreads (page 1 sits alone on the right, like a cover). EPUB, Word, text and Markdown are cut into real pages.
- **Pinch in with two fingers**, or tap the page counter at the bottom, to see **all pages** as a grid of numbers (the current page is circled) or as small pictures.
- **Aa** has *Reading view* (Scroll or Book), *Pages shown* (Auto, Two, One), the *page-turn sound* and a separate text size for book view. Listening (read aloud) switches back to scroll view so it can read along.

## New in 1.1
- **Welcome animation** (a book opening, sparkles) and **calm music** made live on the phone: Calm Garden, Happy Morning, Deep Focus, Soft Rain, Sleepy Library. The music button is in the top bar.
- **Themes** under **Menu → Themes & sound**: six bright ones (Sunrise, Meadow, Ocean, Lavender, Blossom, Sunny) plus two dark ones, **Midnight** (soft dark violet) and **Black** (pure black for OLED). The reader also has Night and Black page colours.
- **Read aloud** with the phone's own voice: speed, voice, sleep timer, the current sentence is highlighted and the next chapter carries on by itself.
- **Convert** any book (PDF text, EPUB, Word, TXT, Markdown, HTML) to PDF, Word, EPUB, text, Markdown or a web page, or **save as audio** (.wav) to play anywhere. Text only, pictures are not carried over. Hindi and other non-Latin PDFs are saved as page pictures so every letter shows correctly.

## Your photo and books
Upload them to the repo **next to the zip** (repo root). The build copies them into the app:
- your photo named `raghu.jpg` (or `.png`, `.webp`) goes on the About page,
- any `.pdf` / `.epub` files go into the About page's book shelf. The names in `about.js` (for example `the-false-green.pdf`) are what its *Add to library* buttons look for. Any other book is simply added with **Add books** in the app.

## Make it yours
- **About page:** `app/src/main/assets/www/js/about.js` (text, skills, story, books).
- **Your photo:** add `raghu.jpg` to `app/src/main/assets/www/`.
- **Your books:** put PDFs in `app/src/main/assets/www/books/` with the names in `about.js`; *About → My books → Add to library* imports them.
- **Colours and themes:** `css/extra.css` (one block per theme) and `js/theme.js`.
- **Music:** `js/music.js` (the `MOODS` table at the top).
- **Version:** `app/build.gradle` (`versionCode`, `versionName`).

## Layout
```
app/src/main/java/.../MainActivity.java   WebView shell: file picker, Open with, bars, text-to-speech, Save as
app/src/main/assets/www/                  the whole app (HTML, CSS, JS)
  js/parsers.js   EPUB, TXT, MD, HTML, DOCX, PDF-text
  js/reader.js    reflow reader + PDF page viewer
  js/views.js     home, library, search, shelf, book page
  js/theme.js     themes and reading styles
  js/music.js     the generated calm music
  js/track.js     reading log, streaks, calendar and the Stats screen
  js/quotes.js    quote finder, Home quote card, Quotes screen
  js/curl.js      the page-curl geometry
  js/ann.js       pen / highlighter / eraser and text highlights
  js/dict.js      look-up and saved words
  js/splash.js    welcome animation
  js/convert.js   book to PDF / Word / EPUB / text / Markdown / HTML
  js/listen.js    read aloud and save as audio
  lib/            pdf.js 3.11 and JSZip 3.10 (bundled, no CDN)
keystore/         fixed signing key (personal use)
```
Not supported yet: MOBI/AZW, DRM books. Audio files are .wav (large); choose only the chapters you need.
