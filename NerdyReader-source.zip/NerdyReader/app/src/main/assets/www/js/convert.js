'use strict';
/* ===== NerdyReader · convert a book into another format =====
   Everything runs on the phone. Any readable book (PDF text, EPUB, Word, TXT, Markdown, HTML)
   is first turned into one simple "document" (chapters made of headings, paragraphs, list items…),
   and each writer below turns that document into a file.
   Text only: pictures are left out. */

/* messages coming back from the Android side (read-aloud events, "file saved", audio progress) */
const NATIVE = {};
window.nrNative = ev => { try { NATIVE[ev.e] && NATIVE[ev.e](ev); } catch (e) { console.warn(e); } };

/* ---------- 1. HTML  ->  blocks ---------- */
const BLOCK_RE = /^(P|DIV|H[1-6]|UL|OL|LI|BLOCKQUOTE|PRE|TABLE|HR|SECTION|ARTICLE|ASIDE|FIGURE|FIGCAPTION|HEADER|FOOTER|MAIN|NAV|DL|DT|DD|TR|TBODY|THEAD)$/;
function runPush(acc, r) {
  const l = acc[acc.length - 1];
  if (l && l.b === r.b && l.i === r.i && l.t !== '\n' && r.t !== '\n') l.t += r.t; else acc.push({ t: r.t, b: !!r.b, i: !!r.i });
}
function collectRuns(node, st, acc, skipLists) {
  for (const n of node.childNodes) {
    if (n.nodeType === 3) {
      const t = n.nodeValue.replace(/[\s\u00a0]+/g, ' ');
      if (t) runPush(acc, { t, b: st.b, i: st.i });
    } else if (n.nodeType === 1) {
      const tag = n.tagName;
      if (tag === 'BR') runPush(acc, { t: '\n', b: false, i: false });
      else if (/^(SCRIPT|STYLE|IMG|SVG|NOSCRIPT|AUDIO|VIDEO|CANVAS)$/.test(tag)) continue;
      else if (skipLists && /^(UL|OL)$/.test(tag)) continue;
      else collectRuns(n, { b: st.b || /^(B|STRONG)$/.test(tag), i: st.i || /^(I|EM|CITE)$/.test(tag) }, acc, skipLists);
    }
  }
}
/* trim, collapse doubled spaces, drop empty pieces */
function finishRuns(runs) {
  const out = [];
  for (const r of runs) {
    let t = r.t;
    if (t !== '\n') {
      const prev = out[out.length - 1];
      if (!prev || prev.t === '\n' || /\s$/.test(prev.t)) t = t.replace(/^\s+/, '');
    }
    if (t) out.push({ t, b: r.b, i: r.i });
  }
  while (out.length && out[out.length - 1].t !== '\n' && /^\s*$/.test(out[out.length - 1].t)) out.pop();
  while (out.length && out[out.length - 1].t === '\n') out.pop();
  if (out.length) out[out.length - 1].t = out[out.length - 1].t.replace(/\s+$/, '');
  return out.filter(r => r.t);
}
const runsText = runs => runs.map(r => r.t).join('');

function htmlToBlocks(html) {
  const doc = new DOMParser().parseFromString('<!doctype html><html><body>' + html + '</body></html>', 'text/html');
  const out = [];
  const hasBlock = el => [...el.children].some(c => BLOCK_RE.test(c.tagName));
  const para = (runs, k = 'p') => { runs = finishRuns(runs); if (runs.length && runsText(runs).trim()) out.push({ k, runs }); };
  function walkList(list, depth) {
    const ordered = list.tagName === 'OL';
    let idx = 0;
    for (const li of list.children) {
      if (li.tagName !== 'LI') continue;
      idx++;
      const acc = []; collectRuns(li, { b: false, i: false }, acc, true);
      const runs = finishRuns(acc);
      if (runs.length) out.push({ k: 'li', depth, n: ordered ? idx : 0, runs });
      for (const sub of li.children) if (/^(UL|OL)$/.test(sub.tagName)) walkList(sub, depth + 1);
    }
  }
  function walk(el) {
    let pend = [];
    const flush = () => { if (pend.length) { para(pend); pend = []; } };
    for (const n of el.childNodes) {
      if (n.nodeType === 3) { collectRuns({ childNodes: [n] }, { b: false, i: false }, pend); continue; }
      if (n.nodeType !== 1) continue;
      const tag = n.tagName;
      if (!BLOCK_RE.test(tag)) { collectRuns({ childNodes: [n] }, { b: false, i: false }, pend); continue; }
      flush();
      if (n.classList.contains('pgm') || (n.classList.contains('mute') && /^No selectable text/.test(n.textContent))) continue;
      if (/^H[1-6]$/.test(tag)) { const acc = []; collectRuns(n, { b: false, i: false }, acc); const runs = finishRuns(acc); if (runs.length) out.push({ k: 'h', lv: +tag[1], runs }); }
      else if (tag === 'UL' || tag === 'OL') walkList(n, 0);
      else if (tag === 'PRE') { const t = n.textContent.replace(/\r\n?/g, '\n').replace(/\n+$/, ''); if (t.trim()) out.push({ k: 'pre', text: t }); }
      else if (tag === 'HR') out.push({ k: 'hr' });
      else if (tag === 'BLOCKQUOTE') {
        if (hasBlock(n)) { const before = out.length; walk(n); for (let i = before; i < out.length; i++) if (out[i].k === 'p') out[i].k = 'q'; }
        else { const acc = []; collectRuns(n, { b: false, i: false }, acc); para(acc, 'q'); }
      }
      else if (tag === 'TABLE') {
        for (const tr of n.querySelectorAll('tr')) {
          const cells = [...tr.children].filter(c => /^(TD|TH)$/.test(c.tagName)).map(c => { const a = []; collectRuns(c, { b: false, i: false }, a); return runsText(finishRuns(a)).replace(/\n/g, ' '); });
          if (cells.some(Boolean)) out.push({ k: 'p', runs: [{ t: cells.join('  |  '), b: false, i: false }] });
        }
      }
      else if (hasBlock(n)) walk(n);
      else { const acc = []; collectRuns(n, { b: false, i: false }, acc); para(acc); }
    }
    flush();
  }
  walk(doc.body);
  return out;
}

/* ---------- 2. a book  ->  document ---------- */
async function openParser(blob, fmt, base) {
  if (fmt === 'pdf') {
    const pdf = await pdfjsLib.getDocument({ data: new Uint8Array(await blob.arrayBuffer()) }).promise;
    const P = pdfTextParser(pdf, { title: base }, 8); P._pdf = pdf; return P;
  }
  if (fmt === 'epub') return parseEpub(blob);
  if (fmt === 'docx') return parseDocx(blob);
  const txt = await decodeText(await blob.arrayBuffer());
  return fmt === 'md' ? parseMd(txt, { title: base }) : fmt === 'html' ? parseHtml(txt, { title: base }) : parseTxt(txt, { title: base });
}
async function buildDoc(blob, fmt, base, onProg) {
  const P = await openParser(blob, fmt, base), meta = P.meta || {}, n = P.chapters.length, chapters = [];
  for (let i = 0; i < n; i++) {
    onProg && onProg(0.02 + 0.5 * i / n, `Reading part ${i + 1} of ${n}…`);
    const { html } = await P.load(i);
    const blocks = htmlToBlocks(html);
    if (blocks.length) chapters.push({ title: P.chapters[i].title, blocks });
    if (i % 2 === 1) await sleep(0);
  }
  try { P.revoke && P.revoke(); } catch (e) { }
  try { P._pdf && P._pdf.destroy(); } catch (e) { }
  const title0 = (meta.title || base || '').trim().toLowerCase();       // the title page already says the title
  const fb = chapters[0] && chapters[0].blocks[0];
  if (fb && fb.k === 'h' && title0 && runsText(fb.runs).trim().toLowerCase() === title0) { chapters[0].blocks.shift(); if (!chapters[0].blocks.length) chapters.shift(); }
  const words = chapters.reduce((a, c) => a + c.blocks.reduce((b, x) => b + countWords(x.runs ? runsText(x.runs) : x.text || ''), 0), 0);
  return { title: (meta.title || base || 'Untitled').trim(), author: (meta.author || '').trim(), src: fmt, chapters, words };
}
/* the blocks of one chapter, with a heading added when the source did not have one */
function chapterBlocks(ch, doc, ci) {
  const b = ch.blocks.slice();
  const multi = doc.chapters.length > 1 && doc.src !== 'pdf';
  if (multi && ch.title && !(b[0] && b[0].k === 'h')) b.unshift({ k: 'h', lv: 2, runs: [{ t: ch.title, b: false, i: false }] });
  if (multi && ci > 0 && b[0]) b[0] = Object.assign({}, b[0], { pb: true });
  return b;
}
const chapterLabel = (ch, i) => (ch.blocks[0] && ch.blocks[0].k === 'h' ? runsText(ch.blocks[0].runs) : ch.title) || ('Part ' + (i + 1));
const safeName = s => (s || 'book').replace(/[\\/:*?"<>|\n\r\t]+/g, ' ').replace(/\s+/g, ' ').trim().slice(0, 80) || 'book';
const xmlSafe = s => String(s).replace(/[\u0000-\u0008\u000B\u000C\u000E-\u001F\uFFFE\uFFFF]/g, '');
const xe = s => xmlSafe(s).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;');

/* ---------- 3a. TXT ---------- */
function toTXT(doc) {
  const o = [];
  if (doc.title) { o.push(doc.title); if (doc.author) o.push('by ' + doc.author); o.push('', ''); }
  doc.chapters.forEach((ch, ci) => {
    if (ci) o.push('', '');
    chapterBlocks(ch, doc, ci).forEach(b => {
      if (b.k === 'h') o.push('', runsText(b.runs), '');
      else if (b.k === 'li') o.push('  '.repeat(b.depth) + (b.n ? b.n + '. ' : '• ') + runsText(b.runs), '');
      else if (b.k === 'q') o.push('    ' + runsText(b.runs).replace(/\n/g, '\n    '), '');
      else if (b.k === 'pre') o.push(b.text, '');
      else if (b.k === 'hr') o.push('* * *', '');
      else o.push(runsText(b.runs), '');
    });
  });
  const t = o.join('\n').replace(/\n{4,}/g, '\n\n\n').replace(/^\n+/, '').replace(/\n+$/, '') + '\n';
  return { blob: new Blob([t], { type: 'text/plain;charset=utf-8' }), mime: 'text/plain', ext: 'txt' };
}

/* ---------- 3b. Markdown ---------- */
const mdEsc = s => s.replace(/([\\`*_])/g, '\\$1');
function mdRuns(runs) {
  return runs.map(r => {
    if (r.t === '\n') return '  \n';
    const t = mdEsc(r.t), m = t.match(/^(\s*)(.*?)(\s*)$/s);
    if (!m[2]) return t;
    const w = r.b && r.i ? '***' : r.b ? '**' : r.i ? '*' : '';
    return m[1] + w + m[2] + w + m[3];
  }).join('');
}
function toMD(doc) {
  const o = [];
  const first = doc.chapters[0] && doc.chapters[0].blocks[0];
  if (doc.title && !(first && first.k === 'h' && runsText(first.runs).trim().toLowerCase() === doc.title.toLowerCase())) { o.push('# ' + mdEsc(doc.title)); if (doc.author) o.push('', '*by ' + mdEsc(doc.author) + '*'); o.push(''); }
  doc.chapters.forEach((ch, ci) => {
    chapterBlocks(ch, doc, ci).forEach(b => {
      if (b.k === 'h') o.push('#'.repeat(clamp(b.lv, 1, 6)) + ' ' + mdRuns(b.runs), '');
      else if (b.k === 'li') o.push('  '.repeat(b.depth) + (b.n ? b.n + '. ' : '- ') + mdRuns(b.runs));
      else if (b.k === 'q') o.push(mdRuns(b.runs).split('\n').map(l => '> ' + l).join('\n'), '');
      else if (b.k === 'pre') o.push('```', b.text, '```', '');
      else if (b.k === 'hr') o.push('---', '');
      else { let t = mdRuns(b.runs); if (/^(#{1,6}\s|>|[-+]\s|\d+\.\s)/.test(t)) t = '\\' + t; o.push(t, ''); }
      if (b.k === 'li') { /* keep list items tight; blank line added when the list ends */ }
    });
  });
  // a blank line after the last item of every list
  const txt = o.join('\n').replace(/((?:^|\n)\s*(?:- |\d+\. )[^\n]*)\n(?!\s*(?:- |\d+\. )|\n)/g, '$1\n\n').replace(/\n{3,}/g, '\n\n').trim() + '\n';
  return { blob: new Blob([txt], { type: 'text/markdown;charset=utf-8' }), mime: 'text/markdown', ext: 'md' };
}

/* ---------- 3c. HTML and the XHTML inside EPUB ---------- */
function htmlRuns(runs, xhtml) {
  return runs.map(r => {
    if (r.t === '\n') return xhtml ? '<br/>' : '<br>';
    let t = xe(r.t);
    if (r.i) t = '<i>' + t + '</i>';
    if (r.b) t = '<b>' + t + '</b>';
    return t;
  }).join('');
}
function htmlBlocks(blocks, xhtml, idFor) {
  const o = []; let first = true;
  blocks.forEach(b => {
    const id = first && idFor ? ` id="${idFor}"` : ''; first = false;
    if (b.k === 'h') { const l = clamp(b.lv, 1, 6); o.push(`<h${l}${id}>${htmlRuns(b.runs, xhtml)}</h${l}>`); }
    else if (b.k === 'li') o.push(`<p class="li" style="margin-left:${1.4 + b.depth * 1.4}em;text-indent:-1.1em"${id}>${b.n ? b.n + '.' : '•'}&#160;${htmlRuns(b.runs, xhtml)}</p>`);
    else if (b.k === 'q') o.push(`<blockquote${id}><p>${htmlRuns(b.runs, xhtml)}</p></blockquote>`);
    else if (b.k === 'pre') o.push(`<pre${id}>${xe(b.text)}</pre>`);
    else if (b.k === 'hr') o.push(`<hr${xhtml ? '/' : ''}>`);
    else o.push(`<p${id}>${htmlRuns(b.runs, xhtml)}</p>`);
  });
  return o.join('\n');
}
const BOOK_CSS = `body{max-width:42em;margin:0 auto;padding:1.4em 1.1em 4em;font-family:Georgia,'Times New Roman',serif;font-size:1.08em;line-height:1.7;color:#2a2420;background:#fffdf8}
h1,h2,h3,h4{font-family:'Helvetica Neue',Arial,sans-serif;line-height:1.25;margin:1.6em 0 .6em}h1{font-size:1.7em}h2{font-size:1.4em}h3{font-size:1.15em}
p{margin:0 0 .9em}.by{color:#7a6e66;margin-top:-.4em}blockquote{margin:1em 0;padding:.1em 1em;border-left:3px solid #e3d6c8;color:#6b5f57}
pre{white-space:pre-wrap;background:#f4efe8;padding:.8em;border-radius:6px;font-size:.85em}hr{border:0;border-top:1px solid #e3d6c8;margin:1.8em 0}nav li{margin:.3em 0}`;

function toHTML(doc) {
  const toc = doc.chapters.length > 1 && doc.src !== 'pdf';
  let body = `<h1>${xe(doc.title)}</h1>` + (doc.author ? `<p class="by">by ${xe(doc.author)}</p>` : '');
  if (toc) body += '\n<nav><h2>Contents</h2><ol>' + doc.chapters.map((c, i) => `<li><a href="#c${i + 1}">${xe(chapterLabel(c, i))}</a></li>`).join('') + '</ol></nav>';
  doc.chapters.forEach((ch, ci) => { body += '\n<section>\n' + htmlBlocks(chapterBlocks(ch, doc, ci), false, 'c' + (ci + 1)) + '\n</section>'; });
  const html = `<!doctype html>\n<html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>${xe(doc.title)}</title>${doc.author ? `<meta name="author" content="${xe(doc.author)}">` : ''}<style>${BOOK_CSS}</style></head><body>\n${body}\n</body></html>\n`;
  return { blob: new Blob([html], { type: 'text/html;charset=utf-8' }), mime: 'text/html', ext: 'html' };
}

/* ---------- 3d. EPUB ---------- */
async function toEPUB(doc, onProg) {
  const zip = new JSZip(), id = 'urn:uuid:' + ([1e7] + -1e3 + -4e3 + -8e3 + -1e11).replace(/[018]/g, c => (c ^ crypto.getRandomValues(new Uint8Array(1))[0] & 15 >> c / 4).toString(16));
  zip.file('mimetype', 'application/epub+zip', { compression: 'STORE' });
  zip.file('META-INF/container.xml', '<?xml version="1.0" encoding="UTF-8"?>\n<container version="1.0" xmlns="urn:oasis:names:tc:opendocument:xmlns:container"><rootfiles><rootfile full-path="OEBPS/content.opf" media-type="application/oebps-package+xml"/></rootfiles></container>');
  zip.file('OEBPS/style.css', BOOK_CSS.replace('background:#fffdf8', 'background:transparent'));
  const page = (title, inner) => `<?xml version="1.0" encoding="UTF-8"?>\n<!DOCTYPE html>\n<html xmlns="http://www.w3.org/1999/xhtml" xmlns:epub="http://www.idpf.org/2007/ops" lang="en" xml:lang="en"><head><meta charset="utf-8"/><title>${xe(title)}</title><link rel="stylesheet" type="text/css" href="style.css"/></head><body>\n${inner}\n</body></html>`;
  const items = [{ id: 'title', href: 'title.xhtml', label: doc.title }];
  zip.file('OEBPS/title.xhtml', page(doc.title, `<h1>${xe(doc.title)}</h1>` + (doc.author ? `<p class="by">by ${xe(doc.author)}</p>` : '')));
  doc.chapters.forEach((ch, ci) => {
    const href = `c${ci + 1}.xhtml`, label = chapterLabel(ch, ci);
    items.push({ id: 'c' + (ci + 1), href, label });
    zip.file('OEBPS/' + href, page(label, htmlBlocks(chapterBlocks(ch, doc, ci), true)));
  });
  const navItems = items.slice(1).length ? items.slice(1) : items;
  zip.file('OEBPS/nav.xhtml', page('Contents', `<nav epub:type="toc" id="toc"><h1>Contents</h1><ol>${navItems.map(i => `<li><a href="${i.href}">${xe(i.label)}</a></li>`).join('')}</ol></nav>`));
  zip.file('OEBPS/toc.ncx', `<?xml version="1.0" encoding="UTF-8"?>\n<ncx xmlns="http://www.daisy.org/z3986/2005/ncx/" version="2005-1"><head><meta name="dtb:uid" content="${id}"/></head><docTitle><text>${xe(doc.title)}</text></docTitle><navMap>${navItems.map((i, n) => `<navPoint id="n${n + 1}" playOrder="${n + 1}"><navLabel><text>${xe(i.label)}</text></navLabel><content src="${i.href}"/></navPoint>`).join('')}</navMap></ncx>`);
  zip.file('OEBPS/content.opf', `<?xml version="1.0" encoding="UTF-8"?>\n<package xmlns="http://www.idpf.org/2007/opf" version="3.0" unique-identifier="bid"><metadata xmlns:dc="http://purl.org/dc/elements/1.1/"><dc:identifier id="bid">${id}</dc:identifier><dc:title>${xe(doc.title)}</dc:title><dc:language>en</dc:language>${doc.author ? `<dc:creator>${xe(doc.author)}</dc:creator>` : ''}<meta property="dcterms:modified">${new Date().toISOString().replace(/\.\d+Z$/, 'Z')}</meta></metadata><manifest><item id="nav" href="nav.xhtml" media-type="application/xhtml+xml" properties="nav"/><item id="ncx" href="toc.ncx" media-type="application/x-dtbncx+xml"/><item id="css" href="style.css" media-type="text/css"/>${items.map(i => `<item id="${i.id}" href="${i.href}" media-type="application/xhtml+xml"/>`).join('')}</manifest><spine toc="ncx">${items.map(i => `<itemref idref="${i.id}"/>`).join('')}</spine></package>`);
  const blob = await zip.generateAsync({ type: 'blob', mimeType: 'application/epub+zip', compression: 'DEFLATE' }, m => onProg && onProg(0.6 + 0.35 * m.percent / 100, 'Packing the e-book…'));
  return { blob, mime: 'application/epub+zip', ext: 'epub' };
}

/* ---------- 3e. Word (.docx) ---------- */
async function toDOCX(doc, onProg) {
  const W = 'xmlns:w="http://schemas.openxmlformats.org/wordprocessingml/2006/main"';
  const rPr = r => (r.b || r.i) ? `<w:rPr>${r.b ? '<w:b/>' : ''}${r.i ? '<w:i/>' : ''}</w:rPr>` : '';
  const wRuns = runs => runs.map(r => {
    const parts = r.t.split('\n');
    return `<w:r>${rPr(r)}${parts.map((p, i) => (i ? '<w:br/>' : '') + (p ? `<w:t xml:space="preserve">${xe(p)}</w:t>` : '')).join('')}</w:r>`;
  }).join('');
  const P = (style, inner, extra = '') => `<w:p><w:pPr>${style ? `<w:pStyle w:val="${style}"/>` : ''}${extra}</w:pPr>${inner}</w:p>`;
  const body = [];
  if (doc.title) { body.push(P('Title', wRuns([{ t: doc.title }]))); if (doc.author) body.push(P('Subtitle', wRuns([{ t: doc.author }]))); }
  doc.chapters.forEach((ch, ci) => {
    chapterBlocks(ch, doc, ci).forEach(b => {
      const pb = b.pb ? '<w:pageBreakBefore/>' : '';
      if (b.k === 'h') body.push(P('Heading' + clamp(b.lv, 1, 4), wRuns(b.runs.map(r => ({ t: r.t }))), pb));
      else if (b.k === 'li') body.push(P('', `<w:r><w:t>${b.n ? b.n + '.' : '•'}</w:t></w:r><w:r><w:tab/></w:r>` + wRuns(b.runs), `${pb}<w:spacing w:after="60"/><w:ind w:left="${720 + b.depth * 360}" w:hanging="360"/>`));
      else if (b.k === 'q') body.push(P('Quote', wRuns(b.runs), pb));
      else if (b.k === 'pre') body.push(P('Code', wRuns([{ t: b.text }]), pb));
      else if (b.k === 'hr') body.push(P('', '', '<w:pBdr><w:bottom w:val="single" w:sz="6" w:space="1" w:color="999999"/></w:pBdr>'));
      else body.push(P('', wRuns(b.runs), pb));
    });
  });
  const sect = '<w:sectPr><w:pgSz w:w="11906" w:h="16838"/><w:pgMar w:top="1440" w:right="1300" w:bottom="1300" w:left="1300" w:header="708" w:footer="708" w:gutter="0"/></w:sectPr>';
  const hs = (id, name, sz, before) => `<w:style w:type="paragraph" w:styleId="${id}"><w:name w:val="${name}"/><w:basedOn w:val="Normal"/><w:next w:val="Normal"/><w:qFormat/><w:pPr><w:keepNext/><w:spacing w:before="${before}" w:after="120"/></w:pPr><w:rPr><w:rFonts w:ascii="Calibri" w:hAnsi="Calibri" w:cs="Calibri"/><w:b/><w:sz w:val="${sz}"/></w:rPr></w:style>`;
  const styles = `<?xml version="1.0" encoding="UTF-8" standalone="yes"?>\n<w:styles ${W}><w:docDefaults><w:rPrDefault><w:rPr><w:rFonts w:ascii="Cambria" w:hAnsi="Cambria" w:cs="Cambria" w:eastAsia="Cambria"/><w:sz w:val="23"/><w:szCs w:val="23"/><w:lang w:val="en-US"/></w:rPr></w:rPrDefault><w:pPrDefault><w:pPr><w:spacing w:after="140" w:line="300" w:lineRule="auto"/></w:pPr></w:pPrDefault></w:docDefaults>
<w:style w:type="paragraph" w:default="1" w:styleId="Normal"><w:name w:val="Normal"/><w:qFormat/></w:style>
<w:style w:type="paragraph" w:styleId="Title"><w:name w:val="Title"/><w:basedOn w:val="Normal"/><w:next w:val="Normal"/><w:qFormat/><w:pPr><w:spacing w:before="240" w:after="120"/></w:pPr><w:rPr><w:rFonts w:ascii="Calibri" w:hAnsi="Calibri"/><w:b/><w:sz w:val="52"/></w:rPr></w:style>
<w:style w:type="paragraph" w:styleId="Subtitle"><w:name w:val="Subtitle"/><w:basedOn w:val="Normal"/><w:next w:val="Normal"/><w:qFormat/><w:pPr><w:spacing w:after="360"/></w:pPr><w:rPr><w:i/><w:color w:val="7A6E66"/><w:sz w:val="28"/></w:rPr></w:style>
${hs('Heading1', 'heading 1', 40, 360)}${hs('Heading2', 'heading 2', 32, 320)}${hs('Heading3', 'heading 3', 27, 240)}${hs('Heading4', 'heading 4', 24, 200)}
<w:style w:type="paragraph" w:styleId="Quote"><w:name w:val="Quote"/><w:basedOn w:val="Normal"/><w:qFormat/><w:pPr><w:ind w:left="720" w:right="360"/></w:pPr><w:rPr><w:i/><w:color w:val="5E534C"/></w:rPr></w:style>
<w:style w:type="paragraph" w:styleId="Code"><w:name w:val="Code"/><w:basedOn w:val="Normal"/><w:pPr><w:spacing w:after="120" w:line="240" w:lineRule="auto"/></w:pPr><w:rPr><w:rFonts w:ascii="Courier New" w:hAnsi="Courier New" w:cs="Courier New"/><w:sz w:val="19"/></w:rPr></w:style></w:styles>`;
  const zip = new JSZip();
  zip.file('[Content_Types].xml', '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>\n<Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types"><Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/><Default Extension="xml" ContentType="application/xml"/><Override PartName="/word/document.xml" ContentType="application/vnd.openxmlformats-officedocument.wordprocessingml.document.main+xml"/><Override PartName="/word/styles.xml" ContentType="application/vnd.openxmlformats-officedocument.wordprocessingml.styles+xml"/><Override PartName="/docProps/core.xml" ContentType="application/vnd.openxmlformats-package.core-properties+xml"/></Types>');
  zip.file('_rels/.rels', '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>\n<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="word/document.xml"/><Relationship Id="rId2" Type="http://schemas.openxmlformats.org/package/2006/relationships/metadata/core-properties" Target="docProps/core.xml"/></Relationships>');
  zip.file('word/_rels/document.xml.rels', '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>\n<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/styles" Target="styles.xml"/></Relationships>');
  zip.file('word/styles.xml', styles);
  zip.file('word/document.xml', `<?xml version="1.0" encoding="UTF-8" standalone="yes"?>\n<w:document ${W}><w:body>${body.join('')}${sect}</w:body></w:document>`);
  zip.file('docProps/core.xml', `<?xml version="1.0" encoding="UTF-8" standalone="yes"?>\n<cp:coreProperties xmlns:cp="http://schemas.openxmlformats.org/package/2006/metadata/core-properties" xmlns:dc="http://purl.org/dc/elements/1.1/" xmlns:dcterms="http://purl.org/dc/terms/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"><dc:title>${xe(doc.title)}</dc:title><dc:creator>${xe(doc.author || 'NerdyReader')}</dc:creator><dcterms:created xsi:type="dcterms:W3CDTF">${new Date().toISOString().replace(/\.\d+Z$/, 'Z')}</dcterms:created></cp:coreProperties>`);
  const blob = await zip.generateAsync({ type: 'blob', mimeType: 'application/vnd.openxmlformats-officedocument.wordprocessingml.document', compression: 'DEFLATE' }, m => onProg && onProg(0.6 + 0.35 * m.percent / 100, 'Packing the Word file…'));
  return { blob, mime: 'application/vnd.openxmlformats-officedocument.wordprocessingml.document', ext: 'docx' };
}

/* ---------- 3f. PDF ---------- */
/* Standard Helvetica widths (per 1000 em) for ASCII 32..126, so lines wrap exactly like the viewer draws them */
const HW = [278,278,355,556,556,889,667,191,333,333,389,584,278,333,278,278,556,556,556,556,556,556,556,556,556,556,278,278,584,584,584,556,1015,667,667,722,722,667,611,778,722,278,500,667,556,833,722,778,667,778,722,667,611,722,667,944,667,667,611,278,278,278,469,556,333,556,556,500,556,556,278,556,556,222,222,500,222,833,556,556,556,556,333,500,278,556,500,722,500,500,500,334,260,334,584];
const HB = [278,333,474,556,556,889,722,238,333,333,389,584,278,333,278,278,556,556,556,556,556,556,556,556,556,556,333,333,584,584,584,611,975,722,722,722,722,667,611,778,722,278,556,722,611,833,722,778,667,778,722,667,611,722,667,944,667,667,611,333,278,333,584,556,333,556,611,556,611,556,333,611,611,278,278,556,278,889,611,611,611,611,389,556,333,611,556,778,556,556,500,389,280,389,584];
const HX = { 0x2018: 222, 0x2019: 222, 0x201C: 333, 0x201D: 333, 0x2022: 350, 0x2013: 556, 0x2014: 1000, 0x2026: 1000, 0xA0: 278, 0xA9: 737, 0xAE: 737, 0x2122: 1000, 0xB0: 400, 0xB7: 278, 0xD7: 584, 0xF7: 584, 0xA1: 333, 0xBF: 611, 0x20AC: 556, 0x201A: 222, 0x201E: 333, 0x2020: 556, 0x2021: 556, 0x2030: 1000, 0xDF: 611, 0xE6: 889, 0xC6: 1000, 0x152: 1000, 0x153: 944 };
const WIN = { 0x20AC: 0x80, 0x201A: 0x82, 0x192: 0x83, 0x201E: 0x84, 0x2026: 0x85, 0x2020: 0x86, 0x2021: 0x87, 0x2C6: 0x88, 0x2030: 0x89, 0x160: 0x8A, 0x2039: 0x8B, 0x152: 0x8C, 0x17D: 0x8E, 0x2018: 0x91, 0x2019: 0x92, 0x201C: 0x93, 0x201D: 0x94, 0x2022: 0x95, 0x2013: 0x96, 0x2014: 0x97, 0x2DC: 0x98, 0x2122: 0x99, 0x161: 0x9A, 0x203A: 0x9B, 0x153: 0x9C, 0x17E: 0x9E, 0x178: 0x9F };
const PDF_SWAP = { '\u00A0': ' ', '\u2002': ' ', '\u2003': ' ', '\u2009': ' ', '\u200A': ' ', '\u202F': ' ', '\u2010': '-', '\u2011': '-', '\u2012': '-', '\u2212': '-', '\u2032': "'", '\u2033': '"', '\u2192': '->', '\u2190': '<-', '\u2264': '<=', '\u2265': '>=', '\u2248': '~', '\u00AD': '', '\u200B': '', '\u200C': '', '\u200D': '', '\uFEFF': '', '\t': '    ', '\r': '' };

/* what code does the Latin-1 / WinAnsi font use for this character? -1 = cannot draw it */
function winCode(ch) {
  const c = ch.codePointAt(0);
  if (c >= 0x20 && c < 0x7F) return c;
  if (c >= 0xA0 && c <= 0xFF) return c;
  return WIN[c] !== undefined ? WIN[c] : -1;
}
function pdfPrep(s) { return s.replace(/[\u00A0\u2002\u2003\u2009\u200A\u202F\u2010-\u2012\u2212\u2032\u2033\u2192\u2190\u2264\u2265\u2248\u00AD\u200B-\u200D\uFEFF\t\r]/g, c => PDF_SWAP[c]); }
function charW(ch, bold, mono) {
  if (mono) return 600;
  const c = ch.codePointAt(0), T = bold ? HB : HW;
  if (c >= 32 && c <= 126) return T[c - 32];
  if (HX[c]) return HX[c];
  const b = ch.normalize('NFD')[0].codePointAt(0);
  return b >= 32 && b <= 126 ? T[b - 32] : 556;
}
const strW = (s, bold, size, mono) => { let w = 0; for (const ch of s) w += charW(ch, bold, mono); return w * size / 1000; };

/* decide between a real-text PDF and a picture-per-page PDF (needed for Hindi, Arabic, Chinese …) */
function pdfNeedsPictures(doc) {
  let total = 0, bad = 0;
  const scan = s => { for (const ch of pdfPrep(s)) { if (/\s/.test(ch)) continue; total++; if (winCode(ch) < 0) bad++; } };
  doc.chapters.forEach(c => c.blocks.forEach(b => scan(b.runs ? runsText(b.runs) : b.text || '')));
  scan(doc.title + ' ' + doc.author);
  return bad >= 3 && bad / Math.max(1, total) > 0.004;
}

/* shared page layout. `m` supplies measure(text, style) and the page metrics, so the same code
   lays out text pages (Helvetica) and picture pages (any script). */
function layoutDoc(doc, m) {
  const pages = [[]]; let y = m.top;
  const cur = () => pages[pages.length - 1];
  const newPage = () => { pages.push([]); y = m.top; };
  const room = need => { if (y + need > m.bottom) newPage(); };
  const tokens = (runs, baseBold) => {                      // words with their style
    const out = [];
    runs.forEach(r => {
      if (r.t === '\n') { out.push({ nl: true }); return; }
      r.t.split(/(\s+)/).forEach(w => { if (!w) return; if (/^\s+$/.test(w)) { out.push({ sp: true, st: (r.b || baseBold ? 1 : 0) + (r.i ? 2 : 0) }); } else out.push({ w, st: (r.b || baseBold ? 1 : 0) + (r.i ? 2 : 0) }); });
    });
    return out;
  };
  /* wrap tokens into lines no wider than `width`; each line is a list of {text, st} segments */
  const wrap = (toks, width, size, mono) => {
    const lines = []; let line = [], x = 0;
    const endLine = () => { lines.push(line); line = []; x = 0; };
    const put = (text, st, w) => {
      const l = line[line.length - 1];
      if (l && l.st === st) l.text += text; else line.push({ text, st, x });
      x += w;
    };
    let gap = null;
    for (const t of toks) {
      if (t.nl) { endLine(); gap = null; continue; }
      if (t.sp) { gap = t; continue; }
      let word = t.w;
      const sw = line.length && gap ? m.measure(' ', t.st, size, mono) : 0;
      let ww = m.measure(word, t.st, size, mono);
      if (line.length && x + sw + ww > width) { endLine(); }
      else if (line.length && sw) put(' ', t.st, sw);
      gap = null;
      while (ww > width && word.length > 1) {              // a word wider than the line: break it
        let n = 1; while (n < word.length && m.measure(word.slice(0, n + 1), t.st, size, mono) <= width) n++;
        put(word.slice(0, n), t.st, m.measure(word.slice(0, n), t.st, size, mono)); endLine();
        word = word.slice(n); ww = m.measure(word, t.st, size, mono);
      }
      put(word, t.st, ww);
    }
    if (line.length) lines.push(line);
    return lines;
  };
  const emit = (lines, x0, size, lead, mono, extra) => {
    lines.forEach(ln => {
      room(lead); const baseline = y + size * 0.82;
      let x = x0;
      ln.forEach(seg => { cur().push({ x, y: baseline, text: seg.text, st: seg.st, size, mono, color: extra && extra.color }); x += m.measure(seg.text, seg.st, size, mono); });
      y += lead;
    });
  };
  const head = { 1: [m.s(20), m.s(26)], 2: [m.s(16), m.s(22)], 3: [m.s(13.5), m.s(19)], 4: [m.s(12), m.s(17)] };
  const L = m.left, Wd = m.right - m.left;
  // title
  if (doc.title) {
    const [sz, ld] = [m.s(26), m.s(33)];
    emit(wrap(tokens([{ t: doc.title, b: true }], true), Wd, sz), L, sz, ld, false); y += m.s(4);
    if (doc.author) { emit(wrap(tokens([{ t: 'by ' + doc.author, i: true }]), Wd, m.s(13)), L, m.s(13), m.s(19), false, { color: 0.4 }); }
    y += m.s(18);
  }
  doc.chapters.forEach((ch, ci) => {
    chapterBlocks(ch, doc, ci).forEach((b, bi) => {
      if (b.pb && (y > m.top + 2)) newPage();
      if (b.k === 'h') {
        const [sz, ld] = head[clamp(b.lv, 1, 4)];
        y += (y > m.top ? m.s(12) : 0); room(ld * 2.4);
        emit(wrap(tokens(b.runs, true), Wd, sz), L, sz, ld, false); y += m.s(5);
      } else if (b.k === 'li') {
        const ind = m.s(18 + b.depth * 16), sz = m.s(11), ld = m.s(16);
        const lines = wrap(tokens(b.runs), Wd - ind, sz);
        room(ld); const bullet = b.n ? b.n + '.' : '•';
        cur().push({ x: L + ind - m.measure(bullet + ' ', 0, sz) - m.s(2), y: y + sz * 0.82, text: bullet, st: 0, size: sz });
        emit(lines, L + ind, sz, ld, false); y += m.s(3);
      } else if (b.k === 'q') {
        const ind = m.s(22), sz = m.s(11), ld = m.s(16);
        const runs = b.runs.map(r => Object.assign({}, r, { i: true }));
        emit(wrap(tokens(runs), Wd - ind - m.s(10), sz), L + ind, sz, ld, false, { color: 0.3 }); y += m.s(7);
      } else if (b.k === 'pre') {
        const sz = m.s(9.2), ld = m.s(12.2), cw = m.measure('M', 0, sz, true);
        const maxc = Math.max(10, Math.floor(Wd / cw));
        const lines = []; b.text.split('\n').forEach(l => { l = l.replace(/\t/g, '    '); if (!l) lines.push([]); for (let i = 0; i < l.length; i += maxc) lines.push([{ text: l.slice(i, i + maxc), st: 0 }]); });
        emit(lines, L, sz, ld, true); y += m.s(7);
      } else if (b.k === 'hr') {
        room(m.s(16)); cur().push({ rule: true, x: L, x2: L + Wd, y: y + m.s(6) }); y += m.s(16);
      } else {
        const sz = m.s(11), ld = m.s(16);
        emit(wrap(tokens(b.runs), Wd, sz), L, sz, ld, false); y += m.s(7);
      }
    });
  });
  return pages;
}

const PDF_BYTES = { enc: s => { const u = new Uint8Array(s.length); for (let i = 0; i < s.length; i++) u[i] = s.charCodeAt(i) & 255; return u; } };
class PdfBuilder {
  constructor() { this.parts = []; this.len = 0; this.off = []; }
  str(s) { const u = PDF_BYTES.enc(s); this.parts.push(u); this.len += u.length; }
  bin(u) { this.parts.push(u); this.len += u.length; }
  obj(n, body) { this.off[n] = this.len; this.str(`${n} 0 obj\n${body}\nendobj\n`); }
  objStream(n, dict, data) { this.off[n] = this.len; this.str(`${n} 0 obj\n<< ${dict} /Length ${data.length} >>\nstream\n`); this.bin(data); this.str('\nendstream\nendobj\n'); }
  finish(root, info) {
    const total = this.off.length, xr = this.len;
    let t = `xref\n0 ${total}\n0000000000 65535 f \n`;
    for (let i = 1; i < total; i++) t += String(this.off[i]).padStart(10, '0') + ' 00000 n \n';
    t += `trailer\n<< /Size ${total} /Root ${root} 0 R /Info ${info} 0 R >>\nstartxref\n${xr}\n%%EOF\n`;
    this.str(t);
    return new Blob(this.parts, { type: 'application/pdf' });
  }
}
const pdfUtf16 = s => '<FEFF' + [...s].map(c => { const cp = c.codePointAt(0); if (cp > 0xFFFF) { const v = cp - 0x10000; return (0xD800 + (v >> 10)).toString(16).padStart(4, '0') + (0xDC00 + (v & 1023)).toString(16).padStart(4, '0'); } return cp.toString(16).padStart(4, '0'); }).join('') + '>';
const PW = 595.28, PH = 841.89;

async function pdfText(doc, onProg) {
  const prep = s => { let o = ''; for (const ch of pdfPrep(s)) o += winCode(ch) >= 0 || /\s/.test(ch) ? ch : '?'; return o; };
  const clean = JSON.parse(JSON.stringify(doc), (k, v) => (k === 't' || k === 'text' || k === 'title' || k === 'author') && typeof v === 'string' ? prep(v) : v);
  const m = {
    left: 64, right: PW - 64, top: 62, bottom: PH - 72, s: v => v,
    measure: (t, st, size, mono) => strW(t, !!(st & 1), size, mono) * 1.012,     // 1.2% safety margin so lines never touch the margin
  };
  const pages = layoutDoc(clean, m);
  const pb = new PdfBuilder();
  pb.str('%PDF-1.4\n%\xE2\xE3\xCF\xD3\n');
  pb.off[0] = 0;
  const fonts = ['Helvetica', 'Helvetica-Bold', 'Helvetica-Oblique', 'Helvetica-BoldOblique', 'Courier'];
  pb.obj(1, '<< /Type /Catalog /Pages 2 0 R >>');
  const kids = pages.map((_, i) => `${9 + i * 2} 0 R`).join(' ');
  pb.obj(2, `<< /Type /Pages /Kids [${kids}] /Count ${pages.length} >>`);
  fonts.forEach((f, i) => pb.obj(3 + i, `<< /Type /Font /Subtype /Type1 /BaseFont /${f} /Encoding /WinAnsiEncoding >>`));
  pb.obj(8, `<< /Title ${pdfUtf16(doc.title || 'Document')} /Author ${pdfUtf16(doc.author || '')} /Producer ${pdfUtf16('NerdyReader')} >>`);
  const esc = s => s.replace(/[\\()]/g, '\\$&').replace(/[\x00-\x1f]/g, ' ');
  const fnt = (st, mono) => mono ? 'F5' : ['F1', 'F2', 'F3', 'F4'][st & 3];
  pages.forEach((pg, i) => {
    let c = '';
    pg.forEach(it => {
      if (it.rule) { c += `0.75 G 0.6 w ${it.x.toFixed(2)} ${(PH - it.y).toFixed(2)} m ${it.x2.toFixed(2)} ${(PH - it.y).toFixed(2)} l S 0 G\n`; return; }
      let bytes = '';
      for (const ch of it.text) { const k = winCode(ch); bytes += String.fromCharCode(k >= 0 ? k : 63); }
      if (it.color) c += `${it.color} g `;
      c += `BT /${fnt(it.st, it.mono)} ${it.size} Tf ${it.x.toFixed(2)} ${(PH - it.y).toFixed(2)} Td (${esc(bytes)}) Tj ET`;
      c += it.color ? ' 0 g\n' : '\n';
    });
    const num = String(i + 1), nw = strW(num, false, 9);
    c += `0.5 g BT /F1 9 Tf ${((PW - nw) / 2).toFixed(2)} 34 Td (${num}) Tj ET 0 g\n`;
    pb.obj(9 + i * 2, `<< /Type /Page /Parent 2 0 R /MediaBox [0 0 ${PW} ${PH}] /Resources << /Font << /F1 3 0 R /F2 4 0 R /F3 5 0 R /F4 6 0 R /F5 7 0 R >> >> /Contents ${10 + i * 2} 0 R >>`);
    pb.objStream(10 + i * 2, '', PDF_BYTES.enc(c));
    if (i % 20 === 19) onProg && onProg(0.55 + 0.4 * i / pages.length, `Typesetting page ${i + 1} of ${pages.length}…`);
  });
  return { blob: pb.finish(1, 8), mime: 'application/pdf', ext: 'pdf', pages: pages.length };
}

/* picture-per-page PDF: the text is drawn with the phone's own fonts, so any language works */
async function pdfPictures(doc, onProg) {
  const S = 1000 / PW, FAM = '"Noto Sans","Noto Sans Devanagari","Noto Sans Arabic","Noto Sans CJK SC","Noto Serif",Roboto,"Droid Sans",sans-serif';
  const cv = document.createElement('canvas'); cv.width = 1000; cv.height = Math.round(PH * S);
  const g = cv.getContext('2d');
  const fontOf = (st, size, mono) => `${st & 2 ? 'italic ' : ''}${st & 1 ? 'bold ' : ''}${size}px ${mono ? 'monospace' : FAM}`;
  const m = {
    left: 64 * S, right: (PW - 64) * S, top: 62 * S, bottom: (PH - 72) * S, s: v => v * S * 1.02,
    measure: (t, st, size, mono) => { g.font = fontOf(st, size, mono); return g.measureText(t).width; },
  };
  const pages = layoutDoc(doc, m);
  const pb = new PdfBuilder();
  pb.str('%PDF-1.4\n%\xE2\xE3\xCF\xD3\n'); pb.off[0] = 0;
  pb.obj(1, '<< /Type /Catalog /Pages 2 0 R >>');
  pb.obj(2, `<< /Type /Pages /Kids [${pages.map((_, i) => `${4 + i * 3} 0 R`).join(' ')}] /Count ${pages.length} >>`);
  pb.obj(3, `<< /Title ${pdfUtf16(doc.title || 'Document')} /Author ${pdfUtf16(doc.author || '')} /Producer ${pdfUtf16('NerdyReader')} >>`);
  for (let i = 0; i < pages.length; i++) {
    g.fillStyle = '#fff'; g.fillRect(0, 0, cv.width, cv.height); g.textBaseline = 'alphabetic';
    pages[i].forEach(it => {
      if (it.rule) { g.strokeStyle = '#bbb'; g.lineWidth = 1.5; g.beginPath(); g.moveTo(it.x, it.y); g.lineTo(it.x2, it.y); g.stroke(); return; }
      g.fillStyle = it.color ? '#666' : '#1b1612'; g.font = fontOf(it.st, it.size, it.mono); g.fillText(it.text, it.x, it.y);
    });
    g.fillStyle = '#888'; g.font = `${9 * S}px ${FAM}`; const n = String(i + 1); g.fillText(n, (cv.width - g.measureText(n).width) / 2, (PH - 30) * S);
    const jpg = new Uint8Array(await (await new Promise(r => cv.toBlob(r, 'image/jpeg', 0.82))).arrayBuffer());
    const base = 4 + i * 3;
    pb.obj(base, `<< /Type /Page /Parent 2 0 R /MediaBox [0 0 ${PW} ${PH}] /Resources << /XObject << /Im0 ${base + 1} 0 R >> >> /Contents ${base + 2} 0 R >>`);
    pb.objStream(base + 1, `/Type /XObject /Subtype /Image /Width ${cv.width} /Height ${cv.height} /ColorSpace /DeviceRGB /BitsPerComponent 8 /Filter /DCTDecode`, jpg);
    pb.objStream(base + 2, '', PDF_BYTES.enc(`q ${PW} 0 0 ${PH} 0 0 cm /Im0 Do Q`));
    onProg && onProg(0.55 + 0.4 * (i + 1) / pages.length, `Drawing page ${i + 1} of ${pages.length}…`);
    if (i % 3 === 2) await sleep(0);
  }
  return { blob: pb.finish(1, 3), mime: 'application/pdf', ext: 'pdf', pages: pages.length, pictures: true };
}
const toPDF = (doc, onProg) => pdfNeedsPictures(doc) ? pdfPictures(doc, onProg) : pdfText(doc, onProg);

const WRITERS = { txt: async d => toTXT(d), md: async d => toMD(d), html: async d => toHTML(d), epub: toEPUB, docx: toDOCX, pdf: toPDF };

/* ---------- 4. saving a file through the Android "save as" dialog ---------- */
const b64 = u8 => { let s = ''; for (let i = 0; i < u8.length; i += 0x6000) s += String.fromCharCode.apply(null, u8.subarray(i, i + 0x6000)); return btoa(s); };
let saveWait = null;
NATIVE.saved = ev => { const w = saveWait; saveWait = null; w && w(ev); };
async function saveBlob(blob, name, mime, onProg) {
  if (AB && AB.saveBegin) {
    AB.saveBegin(name, mime);
    const CH = 3 * 1024 * 1024;                     // a multiple of 3 so every piece is clean base64
    for (let off = 0; off < blob.size; off += CH) {
      AB.saveChunk(b64(new Uint8Array(await blob.slice(off, off + CH).arrayBuffer())));
      onProg && onProg(0.95 + 0.04 * Math.min(1, (off + CH) / blob.size), 'Preparing the file…');
    }
    return new Promise(res => { saveWait = res; AB.saveEnd(); });
  }
  const a = document.createElement('a'); a.href = URL.createObjectURL(blob); a.download = name; document.body.appendChild(a); a.click();
  setTimeout(() => { URL.revokeObjectURL(a.href); a.remove(); }, 4000);
  return { ok: true, name };
}

/* ---------- 5. the Convert & listen screen ---------- */
const CV = { src: null, fmt: 'pdf', busy: false };
const CV_FMTS = [['pdf', 'PDF', 'document'], ['docx', 'Word', '.docx'], ['epub', 'EPUB', 'e-book'], ['txt', 'Text', '.txt'], ['md', 'Markdown', '.md'], ['html', 'Web page', '.html'], ['audio', 'Audio', 'spoken .wav']];
const audioOK = () => !!(AB && AB.ttsAvailable);

function vTools() {
  const books = sortBooks(bookList(), 'title');
  const src = CV.src, sb = src && src.kind === 'book' ? S.books.get(src.id) : null;
  const srcLine = src ? (src.kind === 'book' && sb ? `<div class="cvsrc">${coverHTML(sb, 'sm')}<div><b>${esc(shortStr(sb.title, 44))}</b><small>${FMT[sb.format]} · ${sizeStr(sb.size)}</small></div></div>`
    : `<div class="cvsrc"><span class="gico">${ic('file', 16)}</span><div><b>${esc(shortStr(src.file.name, 44))}</b><small>${sizeStr(src.file.size)} · from your phone</small></div></div>`) : '';
  const fm = CV_FMTS.map(([k, t, s]) => `<button class="fmtb ${CV.fmt === k ? 'on' : ''}" data-act="cv-fmt" data-v="${k}" ${k === 'audio' && !audioOK() ? 'disabled' : ''}><span>${t}</span><small>${s}</small></button>`).join('');
  return `<h1 class="pgt">Convert &amp; listen</h1><p class="sub">Turn a book into another format, or into audio you can play anywhere. It all happens on your phone.</p>
  <section class="card"><h3>1 · Choose a book</h3>
    <button class="btn wide" data-act="cv-pick">${ic('folder', 18)} Choose a file from your phone</button>
    ${books.length ? `<div class="lbl">OR PICK FROM YOUR LIBRARY</div><select id="cv-lib" class="inp"><option value="">Select a book…</option>${books.map(b => `<option value="${b.id}" ${src && src.id === b.id ? 'selected' : ''}>${esc(shortStr(b.title, 50))} (${FMT[b.format]})</option>`).join('')}</select>` : ''}
    ${srcLine}</section>
  <section class="card"><h3>2 · Convert to</h3><div class="fmts">${fm}</div>
    ${CV.fmt === 'audio' ? `<div class="note">${ic('phones', 14)} Audio is read by your phone’s own voice, so it needs no internet. You’ll pick the chapters next. The file is a .wav, which is large (about 160 MB per hour), so pick what you need.</div>` : `<div class="note">Text only: pictures are not carried over. Scanned PDFs have no text to convert.</div>`}
    ${!audioOK() ? '<p class="xs mute" style="margin:10px 2px 0">Audio needs the Android app (it is switched off in a normal browser).</p>' : ''}</section>
  <button class="btn pri big wide" data-act="cv-go" ${CV.busy ? 'disabled' : ''} style="margin-top:14px">${ic('swap', 18)} ${CV.fmt === 'audio' ? 'Choose chapters' : 'Convert and save'}</button>
  <div id="cvprog" ${CV.busy ? '' : 'hidden'}><div class="pbarx"><i id="cvbar"></i></div><small class="mute" id="cvtxt">Working…</small></div>`;
}
function toolsMount() { }

const Tools = {
  /* the Home shortcut cards: 'audio' jumps straight to audio, 'convert' keeps (or resets to) a document format */
  preset(kind) { CV.fmt = kind === 'audio' ? 'audio' : (CV.fmt === 'audio' ? 'pdf' : CV.fmt); if (S.view === 'tools') render(); else go('tools'); },
  presetBook(kind, id) { CV.src = { kind: 'book', id }; this.preset(kind); },
};
function setProg(p, t) {
  const b = $('#cvbar'), x = $('#cvtxt'), w = $('#cvprog');
  if (w) w.hidden = false;
  if (b) b.style.width = Math.round(clamp(p, 0, 1) * 100) + '%';
  if (x && t) x.textContent = t;
}
ACT['cv-pick'] = () => { const p = $('#cvpicker'); p.value = ''; p.click(); };
ACT['cv-fmt'] = el => { CV.fmt = el.dataset.v; const m = $('#main'), y = m.scrollTop; render(); m.scrollTop = y; };
ACT['cv-go'] = () => convertRun();
document.addEventListener('change', e => {
  if (e.target.id === 'cvpicker' && e.target.files[0]) {
    const f = e.target.files[0];
    if (!detectFormat(f)) { toast('Can’t read “' + f.name + '”. Supported: PDF, EPUB, TXT, MD, HTML, DOCX.', 4000); return; }
    CV.src = { kind: 'file', file: f }; render();
  }
  if (e.target.id === 'cv-lib') { CV.src = e.target.value ? { kind: 'book', id: e.target.value } : null; render(); }
});

async function cvSource() {
  const src = CV.src;
  if (src.kind === 'book') {
    const b = S.books.get(src.id), blob = await DB.getFile(src.id);
    if (!blob) throw new Error('The file for this book is missing. Remove it and add it again.');
    return { blob, fmt: b.format, base: b.title, title: b.title, author: b.author };
  }
  const f = src.file;
  return { blob: f, fmt: detectFormat(f), base: cleanName(f.name) };
}

async function convertRun() {
  if (CV.busy) return;
  if (!CV.src) { toast('Choose a book first'); return; }
  CV.busy = true; const btn = $('[data-act=cv-go]'); if (btn) btn.disabled = true;
  setProg(0.01, 'Opening the book…');
  try {
    const s = await cvSource();
    const doc = await buildDoc(s.blob, s.fmt, s.base, setProg);
    if (s.title) doc.title = s.title; if (s.author) doc.author = s.author;
    if (doc.words < 5) throw new Error('No readable text found. A scanned PDF is just pictures, so there is nothing to convert.');
    if (CV.fmt === 'audio') { CV.busy = false; if (btn) btn.disabled = false; const w = $('#cvprog'); if (w) w.hidden = true; return Listen.chooseChapters(doc); }
    setProg(0.55, 'Converting…');
    const out = await WRITERS[CV.fmt](doc, setProg);
    const name = safeName(doc.title) + '.' + out.ext;
    setProg(0.95, 'Preparing the file…');
    const r = await saveBlob(out.blob, name, out.mime, setProg);
    if (r.ok) toast(`Saved “${shortStr(r.name || name, 34)}”${out.pictures ? ' (pages are pictures, to keep your language)' : ''}`, 4200);
    else toast('Not saved. You can try again.');
  } catch (e) { console.error(e); toast(e.message || 'Could not convert this file', 6000); }
  CV.busy = false;
  if (S.view === 'tools') { const b2 = $('[data-act=cv-go]'); if (b2) b2.disabled = false; const w = $('#cvprog'); if (w) w.hidden = true; }
}
