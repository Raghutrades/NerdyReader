'use strict';
/* ===== NerdyReader · read aloud and "save as audio" =====
   The voice is Android's own text-to-speech engine (works offline once a voice is installed).
   Reading aloud: the page is split into small pieces that are queued a few at a time; the piece being
   spoken is highlighted and scrolled into view, and the next chapter continues by itself.
   Save as audio: the same voice writes a .wav file you can play in any music player. */

const LS_WINDOW = 10;       // how many pieces are queued ahead
const Listen = {
  ready: false, _p: null, _res: null, voices: [],
  prefs: Object.assign({ rate: 1, voice: '', sleep: 0 }, (() => { try { return JSON.parse(localStorage.getItem('nr-tts')) || {}; } catch (e) { return {}; } })()),
  seq: 0, playing: false, items: [], queued: 0, cur: -1, hi: null, sleepT: null, exporting: false,

  save() { try { localStorage.setItem('nr-tts', JSON.stringify(this.prefs)); } catch (e) { } },
  init() {
    if (!AB || !AB.ttsInit) return Promise.resolve(false);
    if (this.ready) return Promise.resolve(true);
    if (this._p) return this._p;
    this._p = new Promise(res => { this._res = res; AB.ttsInit(); setTimeout(() => { if (this._res === res) { this._res = null; this._p = null; res(false); } }, 9000); });
    return this._p;
  },
  loadVoices() { try { this.voices = JSON.parse(AB.ttsVoices() || '[]'); } catch (e) { this.voices = []; } },

  /* ----- reading the current chapter aloud ----- */
  collect() {
    const items = [], els = $$('#rart > *').filter(e => !e.classList.contains('rend'));
    els.forEach(el => {
      const t = el.textContent.replace(/\s+/g, ' ').trim();
      if (!t || !/[\p{L}\p{N}]/u.test(t)) return;
      let rest = t;
      while (rest.length) {
        if (rest.length <= 700) { items.push({ el, text: rest }); break; }
        let cut = Math.max(rest.lastIndexOf('. ', 650), rest.lastIndexOf('? ', 650), rest.lastIndexOf('! ', 650), rest.lastIndexOf('; ', 650), rest.lastIndexOf(', ', 650));
        if (cut < 200) cut = rest.lastIndexOf(' ', 650);
        if (cut < 100) cut = 650;
        items.push({ el, text: rest.slice(0, cut + 1).trim() }); rest = rest.slice(cut + 1).trim();
      }
    });
    return items;
  },
  firstVisible(items) {
    const top = $('#rtext').getBoundingClientRect().top + 70;
    const i = items.findIndex(it => it.el.getBoundingClientRect().bottom > top);
    return i < 0 ? 0 : i;
  },
  async start(from) {
    if (!RD) return;
    if (RD.kind !== 'reflow') { toast('Switch to text mode (Aa) to listen'); return; }
    if (!(await this.init())) { toast('No text-to-speech voice found. Install one in Android Settings → Text-to-speech.', 6000); return; }
    this.loadVoices();
    this.items = this.collect();
    if (!this.items.length) { toast('Nothing to read on this page'); return; }
    this.seq++; AB.ttsStop(); this.resumeAt = null;
    this.queued = typeof from === 'number' ? clamp(from, 0, this.items.length - 1) : this.firstVisible(this.items);
    this.cur = this.queued - 1;
    this.playing = true;
    Music.setDuck(0.3); AB.keepScreenOn(true);
    this.fill(); this.armSleep(); this.ui();
  },
  fill() {
    while (this.playing && this.queued < this.items.length && this.queued - this.cur <= LS_WINDOW) {
      AB.ttsSpeak(`${this.seq}:${this.queued}`, this.items[this.queued].text, this.prefs.rate, this.prefs.voice || '');
      this.queued++;
    }
  },
  mark(i) {
    if (this.hi) this.hi.classList.remove('tts-now');
    const it = this.items[i]; if (!it) return;
    this.hi = it.el; it.el.classList.add('tts-now');
    try { it.el.scrollIntoView({ block: 'center', behavior: 'smooth' }); } catch (e) { it.el.scrollIntoView(); }
  },
  pause() { if (!this.playing) return; this.resumeAt = Math.max(0, this.cur); this.playing = false; this.seq++; AB.ttsStop(); this.ui(); Music.setDuck(1); },
  stop(quiet) {
    const was = this.playing; this.playing = false; this.seq++; this.resumeAt = null;
    try { AB && AB.ttsStop && AB.ttsStop(); } catch (e) { }
    if (this.hi) { this.hi.classList.remove('tts-now'); this.hi = null; }
    clearTimeout(this.sleepT); this.sleepT = null;
    Music.setDuck(1);
    if (RD && !quiet) AB && AB.keepScreenOn(true); else if (!RD) AB && AB.keepScreenOn(false);
    this.ui();
    if (was && !quiet) toast('Stopped reading');
  },
  toggle() { if (this.playing) this.pause(); else this.start(typeof this.resumeAt === 'number' ? this.resumeAt : undefined); },
  jump(d) { if (!this.playing) { this.start(); return; } this.start(clamp(this.cur + d, 0, this.items.length - 1)); },
  armSleep() {
    clearTimeout(this.sleepT); this.sleepT = null;
    if (this.prefs.sleep) this.sleepT = setTimeout(() => { this.stop(true); toast('Sleep timer finished. Sweet dreams!', 4000); }, this.prefs.sleep * 60000);
  },
  async finishedChapter() {
    const s = RD;
    if (!s || s.kind !== 'reflow' || s.ch >= s.n - 1) { this.stop(true); toast('Finished the book'); return; }
    await rdStep(1);
    await sleep(500);
    if (RD === s && this.playing) this.start(0);
  },

  /* ----- sheet and little floating bar ----- */
  panel() {
    const r = this.prefs.rate, pdfPages = RD && RD.kind === 'pages';
    const vopts = this.voices.length ? `<option value="">Phone default</option>` + this.voices.map(v => `<option value="${esc(v.name)}" ${this.prefs.voice === v.name ? 'selected' : ''}>${esc(v.label)}</option>`).join('') : '<option value="">Phone default</option>';
    if (pdfPages) return `<p class="sm">This PDF is showing its original pages. Switch to text mode so the voice can read it.</p><button class="btn pri wide" data-act="pdf-mode">Read as reflowable text</button>`;
    return `<div class="lctl"><button class="lbtn" data-act="ls-prev" aria-label="Back">${ic('skipp', 22)}</button><button class="lplay" data-act="ls-toggle" aria-label="Play or pause">${ic(this.playing ? 'pause' : 'play', 30)}</button><button class="lbtn" data-act="ls-next" aria-label="Next">${ic('skipn', 22)}</button></div>
    <p class="xs mute tc" style="margin:0">${this.playing ? 'Reading aloud…' : 'Starts from the top of the page you are on'}</p>
    <div class="lbl" id="lsl">SPEED · ${r.toFixed(2).replace(/0$/, '')}×</div><div class="slr"><input type="range" id="ls-rate" min="50" max="200" step="5" value="${Math.round(r * 100)}"></div>
    <div class="lbl">VOICE</div><select id="ls-voice" class="inp">${vopts}</select>
    <div class="lbl">SLEEP TIMER</div><div class="seg3">${[[0, 'Off'], [15, '15 min'], [30, '30 min'], [60, '60 min']].map(([v, t]) => `<button class="${this.prefs.sleep === v ? 'on' : ''}" data-act="ls-sleep" data-v="${v}">${ic('moon', 14)} ${t}</button>`).join('')}</div>
    <button class="btn wide" data-act="ls-save" style="margin-top:16px">${ic('dl', 16)} Save this chapter as audio</button>
    <p class="xs mute" style="margin:10px 2px 0">Tip: Android may stop reading after a long time with the screen off. For long listening, save as audio and play it in any music player.</p>`;
  },
  async sheet() {
    if (!audioOK()) { toast('Read aloud works in the Android app'); return; }
    if (Book.on && RD && RD.kind === 'reflow') { Sheet.close(); toast('Switching to scroll view so it can read along'); await Book.exit(); }
    Sheet.close();
    await sleep(60);
    if (!this.ready) { await this.init(); }
    this.loadVoices();
    Sheet.open(`<div id="lspanel">${this.panel()}</div>`, { title: 'Listen' });
  },
  ui() {
    const p = $('#lspanel'); if (p) p.innerHTML = this.panel();
    const b = $('#ttsbar');
    if (this.exporting) { b.hidden = false; b.innerHTML = `<span id="exmsg">Making audio… ${Math.round((this.exP || 0) * 100)}%</span><button data-act="ls-cancel" aria-label="Cancel">${ic('x', 18)}</button>`; return; }
    if (this.playing) { b.hidden = false; b.innerHTML = `<span>${ic('phones', 16)} Reading aloud</span><button data-act="ls-toggle" aria-label="Pause">${ic('pause', 18)}</button><button data-act="ls-stop" aria-label="Stop">${ic('stop', 16)}</button>`; }
    else { b.hidden = !(typeof this.resumeAt === 'number' && RD); b.innerHTML = `<span>Paused</span><button data-act="ls-toggle" aria-label="Play">${ic('play', 18)}</button><button data-act="ls-stop" aria-label="Stop">${ic('stop', 16)}</button>`; }
  },

  /* ----- save as audio ----- */
  estimate(words) {
    const sec = words / (165 * this.prefs.rate) * 60, mb = sec * 44100 / 1e6;
    const h = Math.floor(sec / 3600), m = Math.round((sec % 3600) / 60);
    return { text: sec < 60 ? 'under a minute' : (h ? h + ' h ' : '') + m + ' min', size: mb >= 1000 ? (mb / 1000).toFixed(1) + ' GB' : mb < 1 ? 'under 1 MB' : Math.round(mb) + ' MB' };
  },
  docText(chapters, doc) {
    const out = [];
    chapters.forEach(ch => {
      const idx = doc.chapters.indexOf(ch), blocks = chapterBlocks(ch, doc, idx);
      blocks.forEach(b => {
        if (b.k === 'hr') return;
        const t = (b.runs ? runsText(b.runs) : b.text || '').replace(/\s+/g, ' ').trim();
        if (t && /[\p{L}\p{N}]/u.test(t)) out.push(b.k === 'h' ? t.replace(/[.!?:]*$/, '.') : t);
      });
      out.push('');
    });
    return out.join('\n').replace(/\n{3,}/g, '\n\n').trim();
  },
  async chooseChapters(doc) {
    if (!(await this.init())) { toast('No text-to-speech voice found. Install one in Android Settings → Text-to-speech.', 6000); return; }
    this.loadVoices(); this.doc = doc;
    const wc = ch => ch.blocks.reduce((a, b) => a + countWords(b.runs ? runsText(b.runs) : b.text || ''), 0);
    this.counts = doc.chapters.map(wc);
    const rows = doc.chapters.map((ch, i) => `<label class="chrow"><input type="checkbox" class="chk" data-i="${i}" checked><span>${esc(shortStr(chapterLabel(ch, i), 46))}</span><small>${this.counts[i]} words</small></label>`).join('');
    const vopts = '<option value="">Phone default</option>' + this.voices.map(v => `<option value="${esc(v.name)}" ${this.prefs.voice === v.name ? 'selected' : ''}>${esc(v.label)}</option>`).join('');
    Sheet.open(`<p class="sm mute" style="margin:0 0 8px">${esc(shortStr(doc.title, 60))}</p>
      <div class="row gap"><button class="btn sm" data-act="ls-all" data-v="1">Select all</button><button class="btn sm" data-act="ls-all" data-v="0">Select none</button></div>
      <div style="max-height:34vh;overflow:auto;margin:8px 0">${rows}</div>
      <div class="lbl" id="lsl">SPEED · ${this.prefs.rate.toFixed(2).replace(/0$/, '')}×</div><input type="range" id="ls-rate" min="50" max="200" step="5" value="${Math.round(this.prefs.rate * 100)}" style="width:100%">
      <div class="lbl">VOICE</div><select id="ls-voice" class="inp">${vopts}</select>
      <div class="note" id="lsest"></div>
      <button class="btn pri big wide" data-act="ls-ex-go" style="margin-top:14px">${ic('dl', 18)} Make the audio file</button>`, { title: 'Choose chapters', onMount: () => this.refreshEst() });
  },
  selected() { return $$('.chk').filter(c => c.checked).map(c => +c.dataset.i); },
  refreshEst() {
    const sel = this.selected(), words = sel.reduce((a, i) => a + this.counts[i], 0), e = this.estimate(words), n = $('#lsest');
    if (n) n.innerHTML = sel.length ? `About <b>${e.text}</b> of audio, roughly <b>${e.size}</b> on your phone. It can take a while, so keep NerdyReader open.` : 'Pick at least one chapter.';
  },
  async exportAudio(name, text) {
    if (this.exporting) { toast('Already making an audio file'); return; }
    if (!text || text.length < 20) { toast('Nothing to read aloud here'); return; }
    this.exporting = true; this.exP = 0; Sheet.close();
    if (this.playing) this.stop(true);
    Music.setDuck(0.0001);
    AB.keepScreenOn(true);
    setProg(0.01, 'Starting the voice…'); this.ui();
    toast('Making audio… keep the app open', 3500);
    const r = await new Promise(res => { this._exDone = res; AB.ttsExport(name, text, this.prefs.rate, this.prefs.voice || ''); });
    this.exporting = false; Music.setDuck(1); if (!RD) AB.keepScreenOn(false);
    this.ui();
    const w = $('#cvprog'); if (w) w.hidden = true;
    if (r.ok) toast(`Saved “${shortStr(r.name || name, 32)}”`, 4200);
    else toast(r.error || 'Audio was not saved', 5000);
  },
};

/* ----- events from Android ----- */
NATIVE.ready = ev => { Listen.ready = !!ev.ok; Listen._p = null; const r = Listen._res; Listen._res = null; r && r(!!ev.ok); };
NATIVE.tts = ev => {
  const [sq, ix] = String(ev.id).split(':').map(Number);
  if (sq !== Listen.seq || !Listen.playing) return;
  if (ev.k === 'start') { Listen.cur = ix; Listen.mark(ix); Listen.fill(); }
  else if (ev.k === 'done') {
    Listen.cur = ix; Listen.fill();
    if (ix >= Listen.items.length - 1) Listen.finishedChapter();
  } else if (ev.k === 'error') { Listen.stop(true); toast('The voice had a problem. Try another voice in Listen.', 5000); }
};
NATIVE.exp = ev => { Listen.exP = ev.p; setProg(ev.p, ev.msg || 'Making audio…'); const m = $('#exmsg'); if (m) m.textContent = 'Making audio… ' + Math.round(ev.p * 100) + '%'; };
const _savedBase = NATIVE.saved;
NATIVE.saved = ev => {                                        // audio file or document finished saving
  if (Listen._exDone) { const d = Listen._exDone; Listen._exDone = null; d(ev); return; }
  _savedBase && _savedBase(ev);
};

/* ----- actions ----- */
ACT['r-listen'] = () => Listen.sheet();
ACT['ls-toggle'] = () => Listen.toggle();
ACT['ls-stop'] = () => Listen.stop();
ACT['ls-cancel'] = () => { try { AB.ttsExportCancel(); } catch (e) { } toast('Cancelling…'); };
ACT['ls-prev'] = () => Listen.jump(-1);
ACT['ls-next'] = () => Listen.jump(+1);
ACT['ls-sleep'] = el => { Listen.prefs.sleep = +el.dataset.v; Listen.save(); Listen.armSleep(); Listen.ui(); };
ACT['ls-save'] = async () => {
  if (!RD || RD.kind !== 'reflow') { toast('Switch to text mode to save audio'); return; }
  if (!(await Listen.init())) { toast('No text-to-speech voice found. Install one in Android Settings → Text-to-speech.', 6000); return; }
  const { html } = await RD.P.load(RD.ch);
  const blocks = htmlToBlocks(html), ch = { title: RD.P.chapters[RD.ch].title, blocks };
  const doc = { title: RD.b.title, author: RD.b.author, src: RD.b.format, chapters: [ch] };
  const label = chapterLabel(ch, RD.ch);
  const words = ch.blocks.reduce((a, b) => a + countWords(b.runs ? runsText(b.runs) : b.text || ''), 0), e = Listen.estimate(words);
  if (!(await confirmBox(`Save “${shortStr(label, 40)}” as audio? About ${e.text}, roughly ${e.size}. You’ll pick where to save it, and need to keep the app open while it is made.`, 'Make audio'))) return;
  Listen.exportAudio(safeName(RD.b.title + ' - ' + label), Listen.docText([ch], doc));
};
ACT['ls-all'] = el => { $$('.chk').forEach(c => { c.checked = el.dataset.v === '1'; }); Listen.refreshEst(); };
ACT['ls-ex-go'] = () => {
  const sel = Listen.selected(); if (!sel.length) { toast('Pick at least one chapter'); return; }
  const doc = Listen.doc, name = safeName(doc.title) + (sel.length === doc.chapters.length ? '' : ' (selected chapters)');
  Listen.exportAudio(name, Listen.docText(sel.map(i => doc.chapters[i]), doc));
};
document.addEventListener('input', e => {
  if (e.target.id === 'ls-rate') { Listen.prefs.rate = +e.target.value / 100; Listen.save(); const l = $('#lsl'); if (l) l.textContent = 'SPEED · ' + Listen.prefs.rate.toFixed(2).replace(/0$/, '') + '×'; if (Listen.doc) Listen.refreshEst(); }
});
document.addEventListener('change', e => {
  if (e.target.id === 'ls-rate' && Listen.playing) Listen.start(Math.max(0, Listen.cur));
  if (e.target.id === 'ls-voice') { Listen.prefs.voice = e.target.value; Listen.save(); if (Listen.playing) Listen.start(Math.max(0, Listen.cur)); }
  if (e.target.classList && e.target.classList.contains('chk')) Listen.refreshEst();
});
